# Copyright (c) 2019, NVIDIA CORPORATION. All rights reserved.
import os
from setuptools import find_packages, setup, find_namespace_packages
import pkutils


setup(
    name="fl_startup",
    version="0.4.0",
    description="Provisioning Tool for Federated Learning Application Runtime Environment",
    url="https://developer.nvidia.com/clara",
    # packages=find_namespace_packages(
    #     where=".",
    #     include=[
    #         "fl_startup",
    #     ],
    #     exclude=[
    #         "additional",
    #     ],
    # ),
    # package_dir={"": "."},
    # packages=['mypkg'],
    #   package_dir={'mypkg': 'src/mypkg'},
    #   package_data={'mypkg': ['data/*.dat']},
    packages=["fl_startup"],
    package_dir={"fl_startup": "fl_startup"},
    # find_packages(exclude=("packages", "participant", "ui")),
    zip_safe=False,
    classifiers=[
        "Programming Language :: Python :: 3",
        "License :: OSI Approved :: MIT License",
        "Operating System :: OS Independent",
    ],
    python_requires=">=3.6",
    install_requires=["cryptography", "rich", "pyyaml", "tenseal==0.3.0", "numpy"],
    package_data={
        "fl_startup": [
            "fl_startup/depot/*",
            "fl_startup/project.yml",
            "fl_startup/authz_config.json",
        ]
    },
    entry_points={
        "console_scripts": [
            "provision=fl_startup.provision:main",
        ],
    },
)
