import datetime
import os
import pickle

from cryptography import x509
from cryptography.exceptions import InvalidSignature
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import padding
from cryptography.hazmat.primitives.asymmetric import rsa
from cryptography.x509.oid import NameOID


def generate_pri_key():
    pri_key = rsa.generate_private_key(
        public_exponent=65537,
        key_size=2048,
        backend=default_backend()
    )
    return pri_key


def generate_cert(issuer, subject, subject_pub_key, signing_pri_key, valid_days=360, ca=False):
    builder = x509.CertificateBuilder(
    ).subject_name(
        subject
    ).issuer_name(
        issuer
    ).public_key(
        subject_pub_key
    ).serial_number(
        x509.random_serial_number()
    ).not_valid_before(
        datetime.datetime.utcnow()
    ).not_valid_after(
        # Our certificate will be valid for 360 days
        datetime.datetime.utcnow() + datetime.timedelta(days=valid_days)
    # Sign our certificate with our private key
    )
    if ca:
        builder = builder.\
            add_extension(x509.SubjectKeyIdentifier.from_public_key(subject_pub_key), critical=False).\
            add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(subject_pub_key), critical=False).\
            add_extension(x509.BasicConstraints(ca=True, path_length=None), critical=False)
    cert = builder.sign(signing_pri_key, hashes.SHA256(), default_backend())
    return cert

def x509_name(cn_name, org_name=None):
    name = [x509.NameAttribute(NameOID.COMMON_NAME, cn_name)]
    if org_name is not None:
        name.append(x509.NameAttribute(NameOID.ORGANIZATION_NAME, org_name))
    return x509.Name(name)

def generate_cert_pair(subject_name, root_cert_pair=None):
    pri_key = generate_pri_key()
    subject = x509_name(subject_name)
    if root_cert_pair:
        issuer = root_cert_pair['cert'].subject
        cert = generate_cert(issuer, subject, pri_key.public_key(), root_cert_pair['pri'])
    else:
        issuer = subject
        cert = generate_cert(issuer, subject, pri_key.public_key(), pri_key, ca=True)
    return {"pri": pri_key, "cert": cert}


def serialize_cert_pair(cert_pair):
    pri_key = cert_pair["pri"]
    serialized_pri_key = \
        pri_key.private_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PrivateFormat.TraditionalOpenSSL,
            encryption_algorithm=serialization.NoEncryption()
        )
    cert = cert_pair["cert"]
    serialized_cert = cert.public_bytes(serialization.Encoding.PEM)
    return {"s_pri": serialized_pri_key, "s_cert": serialized_cert}


def deserialize_cert_pair(s_cert_pair):
    s_pri_key = s_cert_pair["s_pri"]
    pri_key = serialization.load_pem_private_key(
        s_pri_key, password=None, backend=default_backend()
    )
    s_cert = s_cert_pair["s_cert"]
    cert = x509.load_pem_x509_certificate(s_cert, default_backend())
    return {"pri": pri_key, "cert": cert}

def sign_all(content_folder, root_cert_pair):
    private_key = root_cert_pair['pri']
    signatures = dict()
    for f in os.listdir(content_folder):
        path = os.path.join(content_folder, f)
        if os.path.isfile(path):
            signature = private_key.sign(
                data=open(path, 'rb').read(),
                padding=padding.PSS(
                    mgf=padding.MGF1(hashes.SHA256()),
                    salt_length=padding.PSS.MAX_LENGTH
                ),
                algorithm=hashes.SHA256()
            )
            signatures[f] = signature
    return signatures

