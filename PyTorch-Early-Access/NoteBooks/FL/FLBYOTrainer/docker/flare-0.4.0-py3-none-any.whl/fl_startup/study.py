import logging
import os
import pathlib
import pickle

import yaml

from participant import Admin, Client, Server
from utils import HEContext, SimpleCert


class Study:
    def __init__(self, audit_full_path, info_table, project_full_path, dst_dir, authz_config_full_path):
        self.wheel_name = 'clara_hci-4.0.0-py3-none-any.whl'

        self.docker_image_name = 'nvcr.io/nvidia/clara-train-sdk'
        self.docker_image_tag = os.environ.get('DOCKER_IMAGE_TAG', 'v4.0')
        self.docker_image = ':'.join(
            [self.docker_image_name, self.docker_image_tag])
        self.docker_image = os.environ.get(
            "FL_DOCKER_IMAGE", self.docker_image)

        self.logger = logging.getLogger(self.__class__.__name__)

        self.logger.info(
            f'Build docker.sh based on container: {self.docker_image}')
        self.logger.info(
            'You may change the container image by setting FL_DOCKER_IMAGE environment variable')

        self.audit_full_path = audit_full_path
        self.info_table = info_table
        self.project_full_path = project_full_path
        self.dst_dir = dst_dir
        self.authz_config_full_path = authz_config_full_path

        # last_study is a dictionary of four keys, 'root', 'server', 'clients' and 'admins'
        # values of those keys are dictionaries, too
        # those dictionaries are key'ed with name (server name, client name, admin email)
        self.last_study = None
        self.new_study = None
        if os.path.exists(audit_full_path):
            self.last_study = pickle.load(open(audit_full_path, 'rb'))
        else:
            self.new_study = True
        self.current_study = dict()
        self.info_table.add_column("Password")
        self.info_table.add_column("Zip file name")
        self.info_table.add_column("Email of recipient (if provided)")
        self.pkg_dir = pathlib.Path(__file__).parent.absolute()
        self.he_ctx = None

    def load_project(self):
        self.project = yaml.load(
            open(self.project_full_path, 'r'), Loader=yaml.Loader)
        self.subject = self.project["name"]
        if self.last_study is not None and self.subject not in self.last_study['root']:
            self.new_study = True
        if self.new_study:
            self.cert = SimpleCert()
            self.cert.build(self.subject, signing_cert=None)
        else:
            _ = self.last_study['root'][self.subject]['cert']
            self.cert = SimpleCert(_)
        self.cert.serialize()
        if 'he' in self.project:
            if self.new_study:
                self.he_ctx = HEContext(self.project['he'])
                self.he_ctx.build()
            else:
                self.he_ctx = HEContext()
                self.he_ctx.from_pickled(
                    self.last_study['root'][self.subject]['he'])

    def make_audit_data(self):
        audit = dict()
        root_data = {'cert': self.cert.get_serialized_simple_cert()}
        if self.he_ctx:
            root_data['he'] = self.he_ctx.get_pickleable()
        root = {self.subject: root_data}
        audit['root'] = root

        server = {self.server.subject: {'cert': self.server.cert.get_serialized_simple_cert(
        ), 'pw': self.server.pw, 'config': self.server.config}}
        audit['server'] = server

        clients = dict()
        for subject, client in self.clients.items():
            clients[subject] = {'cert': client.cert.get_serialized_simple_cert(
            ), 'pw': client.pw, 'org': client.org}
        audit['clients'] = clients

        admins = dict()
        for subject, admin in self.admins.items():
            admins[subject] = {'cert': admin.cert.get_serialized_simple_cert(
            ), 'pw': admin.pw, 'org': admin.org}
        audit['admins'] = admins

        return audit

    def save_audit_data(self):
        audit = self.make_audit_data()
        pickle.dump(audit, open(self.audit_full_path, 'wb'), protocol=-1)

    def build(self):
        if not os.path.exists(self.dst_dir):
            os.makedirs(self.dst_dir)
        self.server = Server(self, self.subject, self.pkg_dir,
                             self.dst_dir, self.info_table)
        self.server.initialize(self.project)
        self.server.set_config(self.docker_image)
        self.server.manage_files(
            self.cert, self.authz_config_full_path, self.he_ctx)
        self.server.package_files()
        self.clients = dict()
        for item in self.project['fl_clients']:
            client = Client(self, self.subject, self.pkg_dir,
                            self.dst_dir, self.info_table)
            client.initialize(item)
            client.set_config(self.docker_image)
            client.manage_files(self.cert, self.he_ctx)
            client.package_files()
            self.clients[client.subject] = client

        self.admins = dict()
        for item in self.project['admin_clients']:
            admin = Admin(self, self.subject, self.pkg_dir,
                          self.dst_dir, self.info_table)
            admin.initialize(item)
            admin.set_config(self.docker_image)
            admin.manage_files(self.cert)
            admin.package_files()
            self.admins[admin.subject] = admin
