import datetime
import logging
import os
import random

import tenseal as ts
from cryptography import x509
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import hashes, serialization
from cryptography.hazmat.primitives.asymmetric import padding, rsa
from cryptography.x509.oid import NameOID


def sign_all(content_folder, signing_cert):
    private_key = signing_cert.pri_key
    signatures = dict()
    for f in os.listdir(content_folder):
        path = os.path.join(content_folder, f)
        if os.path.isfile(path):
            signature = private_key.sign(
                data=open(path, 'rb').read(),
                padding=padding.PSS(
                    mgf=padding.MGF1(hashes.SHA256()),
                    salt_length=padding.PSS.MAX_LENGTH
                ),
                algorithm=hashes.SHA256()
            )
            signatures[f] = signature
    return signatures


def generate_password():
    s = "abcdefghijklmnopqrstuvwxyz01234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    passlen = 16
    p = "".join(random.sample(s, passlen))
    return p


def sanity_check(project, filename):
    try:
        from jsonschema import validate
    except ImportError:
        pass
    assert project.get(
        "server", None), "Please set server in {} file".format(filename)
    assert project["server"].get(
        "fed_learn_port", None), "Please set fed_learn_port in {} file".format(filename)
    assert project["server"].get(
        "admin_port", None), "Please set admin_port in {} file".format(filename)

    return


def sh_replace(src_filename, mapping_dict):
    result = open(src_filename, 'rt').read()
    for k, v in mapping_dict.items():
        result = result.replace('{~~'+k+'~~}', str(v))
    return result


def foreign_key_check(authz_config, current_project):
    project_users = current_project['admin_clients']
    authorized_users = authz_config['users']
    for user in project_users:
        if user not in authorized_users:
            raise ValueError(
                f'User {user} not found in authz_config.json.  Please update the json file')
        elif project_users[user]['org'] != authorized_users[user]['org']:
            raise ValueError(
                f'User {user} org field mismatched between project.yml and authz_config.json')
    project_sites = copy.deepcopy(current_project['fl_clients'])
    project_sites.update({'server': current_project['server']})
    authorized_sites = authz_config['sites']
    for site in project_sites:
        if site not in authorized_sites:
            raise ValueError(
                f'Site {site} not found in authz_config.json.  Please update the json file')
        elif project_sites[site]['org'] != authorized_sites[site]:
            raise ValueError(
                f'Site {site} org field mismatched between project.yml and authz_config.json')


class HEContext:
    def __init__(self, he_dict=None):
        self.logger = logging.getLogger(self.__class__.__name__)
        self._context = None
        self.scheme_type_mapping = {
            'CKKS': ts.SCHEME_TYPE.CKKS, 'BFV': ts.SCHEME_TYPE.BFV}
        if he_dict is not None:
            assert he_dict['lib'] == 'tenseal', 'Currently, only TenSEAL (https://github.com/OpenMined/TenSEAL) is supported'
            config = he_dict['config']
            self.poly_modulus_degree = config['poly_modulus_degree']
            self.coeff_mod_bit_sizes = config['coeff_mod_bit_sizes']
            self.scale_bits = config['scale_bits']
            # self.key_type = config['key_type']
            _scheme = config['scheme']
            # Setup TenSEAL context
            self.scheme_type = self.scheme_type_mapping[_scheme]
            self.logger.info('Homomorphic encryption configuration')
            self.logger.info(f'lib: {he_dict["lib"]}')
            for k, v in config.items():
                self.logger.info(f'{k}: {v}')
            self.logger.info("generated key type: relin (fixed, not configurable)")
        else:
            self.logger.info('Empty HEContext initialized')

    def build(self):
        self._context = ts.context(
            self.scheme_type,
            poly_modulus_degree=self.poly_modulus_degree,
            coeff_mod_bit_sizes=self.coeff_mod_bit_sizes,
            encryption_type=ts.ENCRYPTION_TYPE.SYMMETRIC
        )
        # dynamically call different generate keys method
        # getattr(self._context, f'generate_{self.key_type}_keys')()
        self._context.generate_relin_keys()
        self._context.global_scale = 2**self.scale_bits

    def save(self, he_file, is_client=False):
        _serialized_context = \
            self._context.serialize(save_public_key=is_client,
                                    save_secret_key=is_client,
                                    save_galois_keys=False,
                                    save_relin_keys=True)
        with open(he_file, 'wb') as f:
            f.write(_serialized_context)

    def get_pickleable(self):
        return self._context.serialize(save_public_key=True,
                                       save_secret_key=True,
                                       save_galois_keys=False,
                                       save_relin_keys=True)
    def from_pickled(self, pickled_data):
        self._context = ts.context_from(pickled_data)


class SerializedSimpleCert():
    def __init__(self, pri_key, cert):
        self.pri_key = pri_key
        self._cert = cert

class SimpleCert():
    def __init__(self, ssc=None):
        if ssc is not None:
            self.pri_key = serialization.load_pem_private_key(
                ssc.pri_key, password=None, backend=default_backend()
            )
            self._cert = x509.load_pem_x509_certificate(
                ssc._cert, default_backend())
            self.pub_key = self.pri_key.public_key()
            self.subject = self._cert.subject

    def generate_pri_key(self):
        self.pri_key = rsa.generate_private_key(
            public_exponent=65537,
            key_size=2048,
            backend=default_backend()
        )
        self.pub_key = self.pri_key.public_key()

    def generate_cert(self, issuer, signing_pri_key, valid_days=360, ca=False):
        builder = x509.CertificateBuilder(
        ).subject_name(
            self.subject
        ).issuer_name(
            issuer
        ).public_key(
            self.pub_key
        ).serial_number(
            x509.random_serial_number()
        ).not_valid_before(
            datetime.datetime.utcnow()
        ).not_valid_after(
            # Our certificate will be valid for 360 days
            datetime.datetime.utcnow() + datetime.timedelta(days=valid_days)
            # Sign our certificate with our private key
        )
        if ca:
            builder = builder.\
                add_extension(x509.SubjectKeyIdentifier.from_public_key(self.pub_key), critical=False).\
                add_extension(x509.AuthorityKeyIdentifier.from_issuer_public_key(self.pub_key), critical=False).\
                add_extension(x509.BasicConstraints(
                    ca=True, path_length=None), critical=False)
        self._cert = builder.sign(
            signing_pri_key, hashes.SHA256(), default_backend())

    def x509_name(self, cn_name, org_name=None):
        name = [x509.NameAttribute(NameOID.COMMON_NAME, cn_name)]
        if org_name is not None:
            name.append(x509.NameAttribute(
                NameOID.ORGANIZATION_NAME, org_name))
        return x509.Name(name)

    def build(self, subject_name, signing_cert):
        self.generate_pri_key()
        self.subject = self.x509_name(subject_name)
        if signing_cert:
            issuer = signing_cert.subject
            self.generate_cert(issuer, signing_cert.pri_key)
        else:
            issuer = self.subject
            self.generate_cert(issuer, self.pri_key, ca=True)

    def serialize(self):
        self.serialized_pri_key = \
            self.pri_key.private_bytes(
                encoding=serialization.Encoding.PEM,
                format=serialization.PrivateFormat.TraditionalOpenSSL,
                encryption_algorithm=serialization.NoEncryption()
            )
        self.serialized_cert = self._cert.public_bytes(
            serialization.Encoding.PEM)

    def get_serialized_simple_cert(self):
        return SerializedSimpleCert(self.serialized_pri_key, self.serialized_cert)

    @classmethod
    def deserialize(self, serialized_simple_cert):
        return SimpleCert(serialized_simple_cert)
