from __future__ import absolute_import
import argparse
import copy
import json
import os
import pathlib
import pickle
import random
import shutil
import subprocess
from datetime import datetime, timezone
import yaml
from dlmed.sec.authz import validate_policy_config
from rich.console import Console
from rich.table import Table

try:
    from .cert_utils import (
        serialize_cert_pair,
        deserialize_cert_pair,
        generate_cert_pair,
        sign_all,
    )
except ImportError:
    from tools.startup_kits.cert_utils import (
        serialize_cert_pair,
        deserialize_cert_pair,
        generate_cert_pair,
        sign_all,
    )

wheel_name = "clara_hci-4.0.0-py3-none-any.whl"
ui_tool_url = "ui directory"

DOCKER_IMAGE_NAME = "nvcr.io/nvidia/clara-train-sdk"
DOCKER_IMAGE_TAG = os.environ.get("DOCKER_IMAGE_TAG", "v4.0")
DOCKER_IMAGE = ":".join([DOCKER_IMAGE_NAME, DOCKER_IMAGE_TAG])

docker_image = os.environ.get("FL_DOCKER_IMAGE", DOCKER_IMAGE)

print(f"Build docker.sh based on container: {docker_image}")
print(
    "You may change the container image by setting FL_DOCKER_IMAGE environment variable"
)


def generate_clients(current_project, client_group, key, input_project, root_cert_pair):
    clients = input_project[client_group]
    if client_group not in current_project:
        current_project[client_group] = dict()
    for client in clients:
        subject_name = client[key]
        if subject_name not in current_project[client_group]:
            client_cert_pair = generate_cert_pair(subject_name, root_cert_pair)
            serialized_cert_pair = serialize_cert_pair(client_cert_pair)
            pw = generate_password()
            serialized_cert_pair.update(client)
            serialized_cert_pair.update(
                {"timestamp": datetime.now(timezone.utc), "zip_pw": pw}
            )
            current_project[client_group][subject_name] = serialized_cert_pair


def sh_replace(template, mapping_dict):
    result = template
    for k, v in mapping_dict.items():
        result = result.replace("{~~" + k + "~~}", str(v))
    return result


def foreign_key_check(authz_config, current_project):
    project_users = current_project["admin_clients"]
    authorized_users = authz_config["users"]
    for user in project_users:
        if user not in authorized_users:
            raise ValueError(
                f"User {user} not found in authz_config.json.  Please update the json file"
            )
        elif project_users[user]["org"] != authorized_users[user]["org"]:
            raise ValueError(
                f"User {user} org field mismatched between project.yml and authz_config.json"
            )
    project_sites = copy.deepcopy(current_project["fl_clients"])
    project_sites.update({"server": current_project["server"]})
    authorized_sites = authz_config["sites"]
    for site in project_sites:
        if site not in authorized_sites:
            raise ValueError(
                f"Site {site} not found in authz_config.json.  Please update the json file"
            )
        elif project_sites[site]["org"] != authorized_sites[site]:
            raise ValueError(
                f"Site {site} org field mismatched between project.yml and authz_config.json"
            )


def save_context(he_ctx, he_file, is_client=False):
    serialized_he_ctx = he_ctx.serialize(
        save_public_key=is_client,
        save_secret_key=is_client,
        save_galois_keys=False,
        save_relin_keys=True,
    )
    with open(he_file, "wb") as f:
        f.write(serialized_he_ctx)
    role = "Client" if is_client else "Server"
    print(f"{role} tenseal context saved at {he_file}")


def package_server(
    audit_history,
    project_name,
    output_dir,
    root_cert_pair,
    table,
    authz_config_file,
    he_context,
):
    key_list = ["admin_port", "admin_storage", "min_num_clients", "max_num_clients"]
    current_project = audit_history[project_name]
    file_path = pathlib.Path(__file__).parent.absolute()
    config_server = json.load(
        open(os.path.join(file_path, "depot", "fed_server.template"), "r")
    )
    server_name = current_project["server"]["cn"]
    fed_learn_port = current_project["server"]["fed_learn_port"]
    admin_port = current_project["server"]["admin_port"]
    update_data = {k: current_project["server"][k] for k in key_list}
    config_server["servers"][0]["service"]["target"] = "{}:{}".format(
        server_name, fed_learn_port
    )
    config_server["servers"][0]["admin_host"] = server_name
    config_server["servers"][0]["admin_port"] = admin_port
    config_server["servers"][0]["name"] = project_name
    config_server["servers"][0].update(update_data)
    config_folder = current_project.get("config_folder", "")
    replacement_dict = {
        "docker_image": docker_image,
        "admin_port": admin_port,
        "fed_learn_port": fed_learn_port,
        "config_folder": config_folder,
    }
    json.dump(config_server, open("startup/fed_server.json", "w"))
    with open("startup/rootCA.pem", "wb") as f:
        f.write(current_project["ca_root"]["s_cert"])
    with open("startup/server.crt", "wb") as f:
        f.write(current_project["server"]["s_cert"])
    with open("startup/server.key", "wb") as f:
        f.write(current_project["server"]["s_pri"])
    shutil.copy("depot/start_svr_sh.template", "startup/start.sh")
    os.chmod("startup/start.sh", 0o755)
    # shutil.copy('depot/set_clara_sh.template', 'startup/set_clara.sh')
    # os.chmod("startup/set_clara.sh", 0o755)

    result = sh_replace(
        open("depot/sub_start_svr_sh.template", "rt").read(), replacement_dict
    )
    with open("startup/sub_start.sh", "w") as f:
        f.write(result)
    os.chmod("startup/sub_start.sh", 0o755)

    result = sh_replace(
        open("depot/docker_svr_sh.template", "rt").read(), replacement_dict
    )
    with open("startup/docker.sh", "w") as f:
        f.write(result)
    os.chmod("startup/docker.sh", 0o755)
    shutil.copy(os.path.join(file_path, "depot", "fs_readme.txt"), "startup/readme.txt")
    shutil.copy(os.path.join(file_path, "depot", "log.config"), "startup/log.config")
    working_files = [
        "startup/rootCA.pem",
        "startup/server.crt",
        "startup/server.key",
        "startup/fed_server.json",
        "startup/readme.txt",
        "startup/start.sh",
        "startup/docker.sh",
        "startup/sub_start.sh",
        "startup/log.config",
    ]

    authz_config = json.loads(open(authz_config_file, "rt").read())
    foreign_key_check(authz_config, current_project)

    authz_def_path = os.path.join(file_path, "depot", "authz_def.json")
    authz_def = json.loads(open(authz_def_path, "rt").read())
    authz_config.update(authz_def)
    if not current_project.get("server", {}).get("auth", True):
        super_role = {"roles": ["super"]}
        for user in authz_config["users"]:
            authz_config["users"][user].update(super_role)
        print("server.auth is set to false.  All admin users are in role 'super'")

    result = validate_policy_config(authz_config)
    if result == "":
        print(
            f"Both authz_def.json and {authz_config_file} are compliant with Authorization Policy\n"
        )
        json.dump(authz_config, open("startup/authorization.json", "wt"), indent=2)
        working_files.append("startup/authorization.json")
    else:
        raise ValueError(
            f"Warning: incorrect configuation in authz_def.json and {authz_config_file}. Reason: {result}"
        )

    if he_context:
        he_file = "startup/server_context.tenseal"
        save_context(he_context, he_file)
        working_files.append(he_file)

    signatures = sign_all("startup", root_cert_pair)
    pickle.dump(signatures, open("startup/signature.pkl", "wb"))
    run_args = [
        "zip",
        "-qr",
        "-P",
        current_project["server"]["zip_pw"],
        "{}/server.zip".format(output_dir),
    ] + [
        ".",
        "-i",
        "startup/*",
    ]  # working_files + ['startup/signature.pkl']
    subprocess.run(run_args, stdout=subprocess.DEVNULL)
    if current_project["server"].get("email"):
        # print("===> password: {} for server.zip to {}".format(current_project["server"]["zip_pw"], current_project["server"]["email"]))
        table.add_row(
            current_project["server"]["zip_pw"],
            "server.zip",
            current_project["server"]["email"],
        )
    else:
        # print("===> password: {} for server.zip".format(current_project["server"]["zip_pw"]))
        table.add_row(current_project["server"]["zip_pw"], "server.zip")
    subprocess.run(
        ["rm"] + working_files + ["startup/signature.pkl"], stdout=subprocess.DEVNULL
    )
    return True


def write_cert_pair(value):
    with open("startup/client.crt", "wb") as f:
        f.write(value["s_cert"])
    with open("startup/client.key", "wb") as f:
        f.write(value["s_pri"])


def package_fl_client(
    audit_history, project_name, output_dir, root_cert_pair, table, he_context
):
    current_project = audit_history[project_name]
    file_path = pathlib.Path(__file__).parent.absolute()
    config_folder = current_project.get("config_folder", "")
    config_client = json.load(
        open(os.path.join(file_path, "depot", "fed_client.template"), "r")
    )
    server_name = current_project["server"]["cn"]
    fed_learn_port = current_project["server"]["fed_learn_port"]
    config_client["servers"][0]["service"]["target"] = "{}:{}".format(
        server_name, fed_learn_port
    )
    config_client["servers"][0]["name"] = project_name
    json.dump(config_client, open("startup/fed_client.json", "w"))
    with open("startup/rootCA.pem", "wb") as f:
        f.write(current_project["ca_root"]["s_cert"])
    # shutil.copy(os.path.join(file_path, "depot", "set_clara_sh.template"), 'startup/set_clara.sh')
    # os.chmod("startup/set_clara.sh", 0o755)
    shutil.copy(os.path.join(file_path, "depot", "fc_readme.txt"), "startup/readme.txt")
    shutil.copy(os.path.join(file_path, "depot", "log.config"), "startup/log.config")

    working_files = [
        "startup/rootCA.pem",
        "startup/client.crt",
        "startup/client.key",
        "startup/fed_client.json",
        "startup/readme.txt",
        "startup/start.sh",
        "startup/log.config",
        "startup/docker.sh",
        "startup/sub_start.sh",
    ]
    if he_context:
        he_file = "startup/client_context.tenseal"
        save_context(he_context, he_file, is_client=True)
        working_files.append(he_file)

    for k, v in current_project["fl_clients"].items():
        write_cert_pair(v)
        replacement_dict = {"client_name": k, "config_folder": config_folder}
        result = sh_replace(
            open("depot/sub_start_cln_sh.template", "rt").read(), replacement_dict
        )
        with open("startup/sub_start.sh", "w") as f:
            f.write(result)
        os.chmod("startup/sub_start.sh", 0o755)

        result = sh_replace(
            open("depot/start_cln_sh.template", "rt").read(), replacement_dict
        )
        with open("startup/start.sh", "w") as f:
            f.write(result)
        os.chmod("startup/start.sh", 0o755)
        replacement_dict = {"docker_image": docker_image, "client_name": k}
        result = sh_replace(
            open("depot/docker_cln_sh.template", "rt").read(), replacement_dict
        )
        with open("startup/docker.sh", "w") as f:
            f.write(result)
        os.chmod("startup/docker.sh", 0o755)
        signatures = sign_all("startup", root_cert_pair)
        pickle.dump(signatures, open("startup/signature.pkl", "wb"))
        run_args = [
            "zip",
            "-qr",
            "-P",
            v["zip_pw"],
            "{}/{}.zip".format(output_dir, k),
        ] + [".", "-i", "startup/*"]
        # working_files + ['startup/signature.pkl']
        subprocess.run(run_args)
        if "email" in v:
            # print("===> password: {} for {}.zip to {}".format(v["zip_pw"], k, v["email"]))
            table.add_row(v["zip_pw"], f"{k}.zip", v["email"])
        else:
            # print("===> password: {} for {}.zip".format(v["zip_pw"], k))
            table.add_row(v["zip_pw"], f"{k}.zip")
    subprocess.run(["rm"] + working_files + ["startup/signature.pkl"])
    return True


def package_admin_client(
    audit_history, project_name, output_dir, root_cert_pair, table
):
    current_project = audit_history[project_name]
    server_name = current_project["server"]["cn"]
    admin_port = current_project["server"]["admin_port"]
    file_path = file_path = pathlib.Path(__file__).parent.absolute()
    with open("startup/rootCA.pem", "wb") as f:
        f.write(current_project["ca_root"]["s_cert"])
    replacement_dict = {
        "cn": server_name,
        "admin_port": admin_port,
        "docker_image": docker_image,
    }

    result = sh_replace(
        open("depot/docker_adm_sh.template", "rt").read(), replacement_dict
    )
    with open("startup/docker.sh", "w") as f:
        f.write(result)
    os.chmod("startup/docker.sh", 0o755)
    result = sh_replace(
        open("depot/fl_admin_sh.template", "rt").read(), replacement_dict
    )
    with open("startup/fl_admin.sh", "w") as f:
        f.write(result)
    os.chmod("startup/fl_admin.sh", 0o755)
    shutil.copy(os.path.join(file_path, "depot", wheel_name), f"startup/{wheel_name}")
    shutil.copy(os.path.join(file_path, "depot", "am_readme.txt"), "startup/readme.txt")
    working_files = [
        "startup/rootCA.pem",
        "startup/client.crt",
        "startup/client.key",
        "startup/fl_admin.sh",
        f"startup/{wheel_name}",
        "startup/readme.txt",
        "startup/docker.sh",
    ]
    for k, v in current_project["admin_clients"].items():
        write_cert_pair(v)
        signatures = sign_all("startup", root_cert_pair)
        pickle.dump(signatures, open("startup/signature.pkl", "wb"))
        run_args = [
            "zip",
            "-qr",
            "-P",
            v["zip_pw"],
            "{}/{}.zip".format(output_dir, k),
        ] + [
            ".",
            "-i",
            "startup/*",
        ]  # working_files + ['startup/signature.pkl']
        subprocess.run(run_args)
        if "email" in v:
            # print("===> password: {} for {}.zip to {}".format(v["zip_pw"], k, v["email"]))
            table.add_row(v["zip_pw"], f"{k}.zip", v["email"])
        else:
            # print("===> password: {} for {}.zip".format(v["zip_pw"], k))
            table.add_row(v["zip_pw"], f"{k}.zip")
    subprocess.run(["rm"] + working_files + ["startup/signature.pkl"])
    return True


def generate_password():
    s = "abcdefghijklmnopqrstuvwxyz01234567890ABCDEFGHIJKLMNOPQRSTUVWXYZ"
    passlen = 16
    p = "".join(random.sample(s, passlen))
    return p


def sanity_check(project, filename):
    try:
        from jsonschema import validate
    except ImportError:
        pass
    assert project.get("server", None), "Please set server in {} file".format(filename)
    assert project["server"].get(
        "fed_learn_port", None
    ), "Please set fed_learn_port in {} file".format(filename)
    assert project["server"].get(
        "admin_port", None
    ), "Please set admin_port in {} file".format(filename)

    return


def build_he_context(he_dict):
    assert (
        he_dict["lib"] == "tenseal"
    ), "Currently, only TenSEAL (https://github.com/OpenMined/TenSEAL) is supported"
    import tenseal as ts

    scheme_type_mapping = {"CKKS": ts.SCHEME_TYPE.CKKS, "BFV": ts.SCHEME_TYPE.BFV}
    config = he_dict["config"]
    poly_modulus_degree = config["poly_modulus_degree"]
    coeff_mod_bit_sizes = config["coeff_mod_bit_sizes"]
    scale_bits = config["scale_bits"]
    scheme = config["scheme"]
    # Setup TenSEAL context
    scheme_type = scheme_type_mapping[scheme]
    print("\nHomomorphic encryption configuration")
    for k, v in config.items():
        print(f"{k}: {v}")
    context = ts.context(
        scheme_type,
        poly_modulus_degree=poly_modulus_degree,
        coeff_mod_bit_sizes=coeff_mod_bit_sizes,
        encryption_type=ts.ENCRYPTION_TYPE.SYMMETRIC,
    )
    print("generated key type: relin (fixed, not configurable)")
    print("The above homomorphic encryption does not automatically enable HE training.")
    print("To enable HE training, please use HE-aware components at FL runtime.")
    context.generate_relin_keys()
    context.global_scale = 2 ** scale_bits
    # key_type = config['key_type']
    # getattr(context, f'generate_{key_type}_keys')()
    return context


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument(
        "-p", "--project_file", type=str, help="file to describe FL project"
    )
    parser.add_argument(
        "-t", "--audit", type=str, help="file to store all histories for audit purpose"
    )
    parser.add_argument(
        "-o",
        "--output_dir",
        type=str,
        default="packages",
        help="directory to store all packages",
    )
    parser.add_argument(
        "-a", "--authz_config", type=str, help="authorization configuration json file"
    )

    args = parser.parse_args()

    file_path = pathlib.Path(__file__).parent.absolute()
    current_path = os.getcwd()
    audit_file = args.audit
    if audit_file is None:
        print(f"Using the default audit file.")
        audit_fullpath = os.path.join(file_path, "audit.pkl")
    else:
        audit_fullpath = os.path.join(current_path, audit_file)
    print(f"Audit file: {audit_fullpath}\n")
    authz_config_file = args.authz_config
    if authz_config_file is None:
        print(f"Using the default authz_config.json file.")
        authz_config_file = os.path.join(file_path, "authz_config.json")
    else:
        authz_config_file = os.path.join(current_path, authz_config_file)
    print(f"Authorization configuration file: {authz_config_file}\n")

    if os.path.exists(audit_fullpath):
        audit_history = pickle.load(open(audit_fullpath, "rb"))
    else:
        audit_history = dict()

    output_dir = os.path.join(current_path, args.output_dir)

    # main project file
    project_file = args.project_file
    if project_file is None:
        print(f"Using the default project yaml file.")
        project_fullpath = os.path.join(file_path, "project.yml")
    else:
        project_fullpath = os.path.join(current_path, project_file)
    print(f"Project yaml file: {project_fullpath}.")
    project = yaml.load(open(project_fullpath, "r"), Loader=yaml.Loader)
    sanity_check(project, project_fullpath)

    os.chdir(file_path)
    project_name = project["name"]
    if project_name not in audit_history:
        root_cert_pair = generate_cert_pair(project_name)
        serialized_cert_pair = serialize_cert_pair(root_cert_pair)
        audit_history[project_name] = {"ca_root": serialized_cert_pair}
    else:
        serialized_cert_pair = audit_history[project_name]["ca_root"]
        root_cert_pair = deserialize_cert_pair(serialized_cert_pair)

    current_project = audit_history[project_name]
    if "he" in project:
        he_context = build_he_context(project["he"])
    else:
        he_context = None

    config_folder = project.get("config_folder", "")

    # CA is ready, generate packages for devices
    server = project["server"]
    subject_name = server["cn"]
    if "server" not in audit_history[project_name]:
        audit_history[project_name]["server"] = {"cn": ""}
        audit_history[project_name]["config_folder"] = config_folder
    if subject_name != audit_history[project_name]["server"]["cn"]:
        server_value = generate_cert_pair(subject_name, root_cert_pair)
        serialized_cert_pair = serialize_cert_pair(server_value)
        pw = generate_password()
        serialized_cert_pair.update(server)
        serialized_cert_pair.update(
            {"timestamp": datetime.now(timezone.utc), "zip_pw": pw}
        )
        audit_history[project_name]["server"] = serialized_cert_pair
        audit_history[project_name]["config_folder"] = config_folder
    else:
        serialized_cert_pair = audit_history[project_name]["server"]
        serialized_cert_pair.update(server)
        serialized_cert_pair.update({"timestamp": datetime.now(timezone.utc)})
        audit_history[project_name]["server"] = serialized_cert_pair
        audit_history[project_name]["config_folder"] = audit_history[project_name][
            "config_folder"
        ]

    if "fl_clients" in project:
        generate_clients(
            current_project, "fl_clients", "client_name", project, root_cert_pair
        )
    if "admin_clients" in project:
        generate_clients(
            current_project, "admin_clients", "email", project, root_cert_pair
        )

    if not os.path.exists("startup"):
        os.makedirs("startup")
    if not os.path.exists(output_dir):
        os.makedirs(output_dir)
    print(
        f"\nThis set of packages is generated for {project_name} project and server's cn is {subject_name}.\n"
    )

    console = Console()
    table = Table(show_header=True, header_style="bold magenta")
    table.add_column("Password")
    table.add_column("Zip file name")
    table.add_column("Email of recipient (if provided)")

    try:
        package_server(
            audit_history,
            project_name,
            output_dir,
            root_cert_pair,
            table,
            authz_config_file,
            he_context,
        )
        package_fl_client(
            audit_history, project_name, output_dir, root_cert_pair, table, he_context
        )
        package_admin_client(
            audit_history, project_name, output_dir, root_cert_pair, table
        )
    except FileNotFoundError as e:
        print("\n" + str(e))
        # It's likely no zip utility available in the system
        if "zip" in str(e):
            print(f"This system has no zip utility.  Please install it.")
        exit(1)

    console.print(table)
    print("\nFinished generating packages.")
    print(f"All generated zip files are inside {output_dir} folder.\n")
    audit_parent_path = pathlib.Path(audit_fullpath).parent.absolute()
    if not os.path.exists(audit_parent_path):
        os.makedirs(audit_parent_path)
    pickle.dump(audit_history, open(audit_fullpath, "wb"))

    os.rmdir("startup")


if __name__ == "__main__":
    main()
