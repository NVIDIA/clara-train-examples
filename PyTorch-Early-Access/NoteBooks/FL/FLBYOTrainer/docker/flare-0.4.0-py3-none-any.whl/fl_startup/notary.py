import argparse
import os
import pathlib

from rich.console import Console
from rich.table import Column, Table

from dlmed.sec.security_content_service import SecurityContentService, LoadResult

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('-c', '--content_folder', type=str,
                        help='folder of all content under signature check', default='.')
    args = parser.parse_args()
    file_path = pathlib.Path(__file__).parent.absolute()
    current_path = os.getcwd()
    content_folder = os.path.join(current_path, args.content_folder)

    console = Console()
    table = Table(show_header=True, header_style="bold magenta")
    table.add_column("File verified", style="dim")
    table.add_column("Verification result", justify="right")

    scs = SecurityContentService()
    scs.initialize(content_folder)
    for f in os.listdir(content_folder):
        if os.path.isfile(os.path.join(content_folder, f)):
            data, sig = scs.load_content(f)
            table.add_row(f, "Passed" if sig == LoadResult.OK else "** Failed **")
    console.print(table)

if __name__ == '__main__':
    main()
