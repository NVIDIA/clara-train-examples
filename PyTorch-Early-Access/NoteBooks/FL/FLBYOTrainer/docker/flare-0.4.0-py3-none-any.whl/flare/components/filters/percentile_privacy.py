import numpy as np

from flare.apis.filter import Filter
from flare.apis.fl_constant import FLConstants, ShareableKey, ShareableValue
from flare.apis.fl_context import FLContext
from flare.apis.shareable import Shareable


class PercentilePrivacy(Filter):
    """
    implementation of "largest percentile to share" privacy preserving policy

    Shokri and Shmatikov, Privacy-preserving deep learning, CCS '15
    """

    def __init__(self, percentile=10, gamma=0.01):
        super().__init__()

        # must be in 0..100, only update abs diff greater than percentile
        self.percentile = percentile
        # must be positive
        self.gamma = gamma  # truncate absolute value of delta W

    def process(self, shareable: Shareable, fl_ctx: FLContext) -> Shareable:
        """Compute the percentile on the abs delta_W,
        only share the params where absolute delta_W greater than
        the percentile value

        Args:
            shareable: information from client
            fl_ctx: context provided by workflow

        Returns:
            Shareable
        """

        self.logger.info("inside filter")
        assert ShareableKey.TYPE in shareable, "shareable missing TYPE key"
        assert (
            shareable[ShareableKey.TYPE] == ShareableValue.TYPE_WEIGHT_DIFF
            and shareable[ShareableKey.DATA_TYPE] == ShareableValue.DATA_TYPE_UNENCRYPTED
        ), f"Filter {self._name} handles shareable type=TYPE_WEIGHT_DIFF and data_type=DATA_TYPE_UNENCRYPTED only"

        self.logger.info("check gamma")
        if self.gamma <= 0:
            self.logger.info("no partial model: gamma: %s", self.gamma)
            return shareable  # do nothing
        if self.percentile < 0 or self.percentile > 100:
            self.logger.info("no partial model: percentile: %s", self.percentile)
            return shareable  # do nothing

        # invariant to local steps
        total_steps = shareable.get(ShareableKey.META, {}).get(FLConstants.NUM_TOTAL_STEPS, 1)

        model_diff = shareable[ShareableKey.MODEL_WEIGHTS]
        delta_w = {name: model_diff[name] / total_steps for name in model_diff}
        # abs delta
        all_abs_values = np.concatenate([np.abs(delta_w[name].ravel()) for name in delta_w])
        cutoff = np.percentile(a=all_abs_values, q=self.percentile, overwrite_input=False)
        self.logger.info(
            "Max abs delta_w: %s, Min abs delta_w: %s, Cutoff: %s, Scale: %s.",
            np.max(all_abs_values),
            np.min(all_abs_values),
            cutoff,
            total_steps,
        )

        for name in delta_w:
            diff_w = delta_w[name]
            if np.ndim(diff_w) == 0:  # single scalar, no clipping
                delta_w[name] = diff_w * total_steps
                continue
            selector = (diff_w > -cutoff) & (diff_w < cutoff)
            diff_w[selector] = 0.0
            diff_w = np.clip(diff_w, a_min=-self.gamma, a_max=self.gamma)
            delta_w[name] = diff_w * total_steps

        shareable[ShareableKey.MODEL_WEIGHTS] = delta_w
        return shareable

    def finalize(self, fl_ctx: FLContext):
        pass
