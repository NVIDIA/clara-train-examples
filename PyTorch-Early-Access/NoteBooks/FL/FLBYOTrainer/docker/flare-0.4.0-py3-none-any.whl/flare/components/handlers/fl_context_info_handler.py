from flare.apis.fl_component import FLComponent
from flare.apis.fl_context import FLContext


class FLContextInfoHandler(FLComponent):
    def handle_event(self, event_type: str, fl_ctx: FLContext):
        """
            perform the handler process based on the event_type.

        Args:
            event_type (str): event type delivered from workflow
            fl_ctx (FLContext): FL context, including peer context and other information

        Returns:

        """
        # FLContext has __str__ method, which returns a string representation of FLContext
        self.logger.debug(f"event: {event_type} FL context: {fl_ctx}")
