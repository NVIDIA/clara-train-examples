import numpy as np

from flare.apis.event_type import EventType
from flare.apis.fl_component import FLComponent
from flare.apis.fl_constant import FLConstants, ShareableKey
from flare.apis.fl_context import FLContext
from flare.utils.fl_ctx_sanity_check import server_fl_ctx_sanity_check


class IntimeModelSelectionHandler(FLComponent):
    def __init__(self, weigh_by_local_iter=False, aggregation_weights=None):
        """

        Args:
            weigh_by_local_iter: default False
            validation_metric_name: meta data name used for model selection
        """

        super().__init__()

        self.val_metric = self.best_val_metric = -np.inf
        self.weigh_by_local_iter = weigh_by_local_iter
        self.validation_metric_name = FLConstants.INITIAL_METRICS
        self.aggregation_weights = aggregation_weights if aggregation_weights is not None else {}

        self.logger.debug(f"model selection weights control: {aggregation_weights}")
        self._reset_stats()

    def handle_event(self, event_type: str, fl_ctx: FLContext):
        """
            perform the handler process based on the event_type.

        Args:
            event_type (str): event type delivered from workflow
            fl_ctx (FLContext): FL context, including peer context and other information

        Returns:

        """
        if event_type == EventType.START_RUN:
            self._startup(fl_ctx)
        elif event_type == EventType.BEFORE_ACCEPT:
            self._before_accept(fl_ctx)
        elif event_type == EventType.BEFORE_AGGREGATION:
            self._before_aggregate(fl_ctx)

    def _startup(self, fl_ctx):
        self._reset_stats()

    def _reset_stats(self):
        self.validation_mertic_weighted_sum = 0
        self.validation_metric_sum_of_weights = 0

    def _before_accept(self, fl_ctx):
        server_fl_ctx_sanity_check(fl_ctx)
        peer_ctx = fl_ctx.get_prop(FLConstants.PEER_CONTEXT)
        contribution_round = peer_ctx.get_prop(FLConstants.CURRENT_ROUND)
        client_name = peer_ctx.get_prop(FLConstants.CLIENT_NAME)

        current_round = fl_ctx.get_prop(FLConstants.CURRENT_ROUND)
        self.logger.debug(f"current_round: {current_round}")

        if current_round == 0:
            self.logger.info("skipping round 0")
            return False  # There is no aggregated model at round 0

        if contribution_round != current_round:
            self.logger.info(
                f"discarding shareable from {client_name} for round: {contribution_round}. Current round is: {current_round}"
            )
            return False

        validation_metric = (
            peer_ctx.get_prop(FLConstants.SHAREABLE, default={})
            .get(ShareableKey.META, {})
            .get(self.validation_metric_name)
        )
        if validation_metric is None:
            self.logger.info(f"validation metric not existing in {client_name}")
            return False
        else:
            self.logger.info(f"validation metric {validation_metric} from client {client_name}")

        if self.weigh_by_local_iter:
            n_iter = (
                peer_ctx.get_prop(FLConstants.SHAREABLE, default={})
                .get(ShareableKey.META, {})
                .get(FLConstants.NUM_STEPS_CURRENT_ROUND, 1.0)
            )
        else:
            n_iter = 1.0

        aggregation_weights = self.aggregation_weights.get(client_name, 1.0)
        self.logger.debug(f"aggregation weight: {aggregation_weights}")

        self.validation_mertic_weighted_sum += validation_metric * n_iter * aggregation_weights
        self.validation_metric_sum_of_weights += n_iter
        return True

    def _before_aggregate(self, fl_ctx):
        server_fl_ctx_sanity_check(fl_ctx, check_peer=False)
        if self.validation_metric_sum_of_weights == 0:
            self.logger.info("nothing accumulated")
            return False
        self.val_metric = self.validation_mertic_weighted_sum / self.validation_metric_sum_of_weights
        self.logger.info(f"weighted validation metric {self.val_metric}")
        if self.val_metric > self.best_val_metric:
            self.best_val_metric = self.val_metric
            current_round = fl_ctx.get_prop(FLConstants.CURRENT_ROUND)
            self.logger.info(f"new best validation metric at round {current_round}: {self.best_val_metric}")
            fl_ctx.set_prop(FLConstants.IS_BEST, True)
        else:
            fl_ctx.set_prop(FLConstants.IS_BEST, False)
        self._reset_stats()
        return True
