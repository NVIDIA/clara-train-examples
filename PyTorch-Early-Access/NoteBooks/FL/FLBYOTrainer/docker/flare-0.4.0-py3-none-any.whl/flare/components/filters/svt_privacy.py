import numpy as np

from flare.apis.filter import Filter
from flare.apis.fl_constant import FLConstants, ShareableKey, ShareableValue
from flare.apis.fl_context import FLContext
from flare.apis.shareable import Shareable


class SVTPrivacy(Filter):

    """
    implementation of the standard SVT differential privacy algorithm.
    """

    def __init__(self, fraction=0.1, epsilon=0.1, noise_var=0.1, gamma=1e-5, tau=1e-6):
        super().__init__()

        self.frac = fraction  # fraction of the model to upload
        self.eps_1 = epsilon
        self.eps_2 = None  # to be derived from eps_1
        self.eps_3 = noise_var
        self.gamma = gamma
        self.tau = tau

    def process(self, shareable: Shareable, fl_ctx: FLContext) -> Shareable:
        """Compute the differentially private SVT

        Args:
            shareable: information from client
            fl_ctx: context provided by workflow

        Returns:
            Shareable
        """
        # invariant to local steps
        assert ShareableKey.TYPE in shareable, "shareable missing TYPE key"
        assert (
            shareable[ShareableKey.TYPE] == ShareableValue.TYPE_WEIGHT_DIFF
            and shareable[ShareableKey.DATA_TYPE] == ShareableValue.DATA_TYPE_UNENCRYPTED
        ), f"Filter {self._name} handles shareable type=TYPE_WEIGHT_DIFF and data_type=DATA_TYPE_UNENCRYPTED only"

        model_diff = shareable[ShareableKey.MODEL_WEIGHTS]
        total_steps = shareable.get(ShareableKey.META, {}).get(FLConstants.NUM_TOTAL_STEPS, 1)

        delta_w = np.concatenate([model_diff[name].ravel() / np.float(total_steps) for name in sorted(model_diff)])
        self.logger.info(
            "Delta_w: Max abs: %s, Min abs: %s, Median abs: %s.",
            np.max(np.abs(delta_w)),
            np.min(np.abs(delta_w)),
            np.median(np.abs(delta_w)),
        )

        # precompute thresholds
        n_upload = np.minimum(np.ceil(np.float(delta_w.size) * self.frac), np.float(delta_w.size))

        # eps_1: threshold with noise
        lambda_rho = self.gamma * 2.0 / self.eps_1
        threshold = self.tau + np.random.laplace(scale=lambda_rho)
        # eps_2: query with noise
        self.eps_2 = self.eps_1 * (2.0 * n_upload) ** (2.0 / 3.0)
        lambda_nu = self.gamma * 4.0 * n_upload / self.eps_2
        self.logger.info(
            "total params: %s, epsilon: %s, "
            "perparam budget %s, threshold tau: %s + f(eps_1) = %s, "
            "clip gamma: %s",
            delta_w.size,
            self.eps_1,
            self.eps_1 / n_upload,
            self.tau,
            threshold,
            self.gamma,
        )

        # selecting weights with additive noise
        accepted, candidate_idx = [], np.arange(delta_w.size)
        _clipped_w = np.abs(np.clip(delta_w, a_min=-self.gamma, a_max=self.gamma))
        while len(accepted) < n_upload:
            nu_i = np.random.laplace(scale=lambda_nu, size=candidate_idx.shape)
            above_threshold = (_clipped_w[candidate_idx] + nu_i) >= threshold
            accepted += candidate_idx[above_threshold].tolist()
            candidate_idx = candidate_idx[~above_threshold]
            self.logger.info("selected %s responses, requested %s", len(accepted), n_upload)
        accepted = np.random.choice(accepted, size=np.int64(n_upload))
        # eps_3 return with noise
        noise = np.random.laplace(scale=self.gamma * 2.0 / self.eps_3, size=accepted.shape)
        self.logger.info("noise max: %s, median %s", np.max(np.abs(noise)), np.median(np.abs(noise)))
        delta_w[accepted] = np.clip(delta_w[accepted] + noise, a_min=-self.gamma, a_max=self.gamma)
        delta_w[candidate_idx] = 0.0

        # resume original format
        dp_w, _start = {}, 0
        for name in sorted(model_diff):
            if np.ndim(model_diff[name]) == 0:
                dp_w[name] = model_diff[name]
                _start += 1
                continue
            value = delta_w[_start : (_start + model_diff[name].size)]
            dp_w[name] = value.reshape(model_diff[name].shape) * np.float(total_steps)
            _start += model_diff[name].size
        shareable[ShareableKey.MODEL_WEIGHTS] = dp_w
        return shareable

    def finalize(self, fl_ctx: FLContext):
        pass
