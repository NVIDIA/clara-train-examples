import re
from typing import Tuple

import numpy as np

from flare.apis.aggregator import Aggregator
from flare.apis.fl_constant import FLConstants, ShareableKey, ShareableValue
from flare.apis.fl_context import FLContext
from flare.apis.shareable import Shareable
from flare.utils.fl_ctx_sanity_check import server_fl_ctx_sanity_check


class InTimeAccumulateWeightedAggregator(Aggregator):
    def __init__(self, exclude_vars=None, aggregation_weights=None):
        """Perform accumulated weighted aggregation
        It computes
          weighted_sum = sum(shareable*n_iteration*aggregation_weights) and
          sum_of_weights = sum(n_iteration)
          in accept function
        The aggregate function returns
          weighted_sum / sum_of_weights

        Args:
            exclude_vars ([type], optional): regex to match excluded vars during aggregation. Defaults to None.
            aggregation_weights ([type], optional): dictionary to map client name to its aggregation weights. Defaults to None.
        """
        super().__init__()
        self.exclude_vars = re.compile(exclude_vars) if exclude_vars else None
        self.aggregation_weights = aggregation_weights if aggregation_weights else {}
        self.reset_stats()
        self.logger.debug(f"client weights control: {self.aggregation_weights}")

    def handle_event(self, event_type: str, fl_ctx: FLContext):
        return True

    def reset_stats(self):
        self.total = dict()
        self.counts = dict()
        self.history = list()

    def accept(self, shareable: Shareable, fl_ctx: FLContext) -> Tuple[bool, bool]:
        """Store shareable and update aggregator's internal state

        Args:
            shareable: information from client
            fl_ctx: context provided by workflow

        Returns:
            The first boolean indicates if this shareable is accepted.
            The second bollean indicates if aggregate can be called.
        """
        assert (
            shareable.get(ShareableKey.TYPE, None) == ShareableValue.TYPE_WEIGHT_DIFF
        ), f"{self._name} support weight difference type shareable only"
        assert (
            shareable.get(ShareableKey.DATA_TYPE, None) == ShareableValue.DATA_TYPE_UNENCRYPTED
        ), f"{self._name} support clear datatype shareable only"

        server_fl_ctx_sanity_check(fl_ctx)
        peer_ctx = fl_ctx.get_prop(FLConstants.PEER_CONTEXT)
        contribution_round = peer_ctx.get_prop(FLConstants.CURRENT_ROUND)
        client_name = peer_ctx.get_prop(FLConstants.CLIENT_NAME)

        current_round = fl_ctx.get_prop(FLConstants.CURRENT_ROUND)
        self.logger.debug(f"current_round: {current_round}")

        if contribution_round != current_round:
            self.logger.info(
                f"discarding shareable from {client_name} at round: {contribution_round}. Current round is: {current_round}"
            )
            return False, False

        for item in self.history:
            if client_name == item["client_name"]:
                prev_round = item["round"]
                self.logger.info(
                    f"discarding shareable from {client_name} at round: {contribution_round} as {prev_round} accepted already"
                )
                return False, False

        n_iter = shareable.get(ShareableKey.META, {}).get(FLConstants.NUM_STEPS_CURRENT_ROUND, 1.0)
        float_n_iter = np.float(n_iter)

        aggregation_weights = self.aggregation_weights.get(client_name, 1.0)
        aggr_data = shareable[ShareableKey.MODEL_WEIGHTS]
        for k, v in aggr_data.items():
            if self.exclude_vars is not None and self.exclude_vars.search(k):
                continue
            weighted_value = v * aggregation_weights * float_n_iter
            current_total = self.total.get(k, None)
            if current_total is None:
                self.total[k] = weighted_value
                self.counts[k] = n_iter
            else:
                self.total[k] = current_total + weighted_value
                self.counts[k] = self.counts[k] + n_iter
        self.history.append(
            {
                "client_name": client_name,
                "round": contribution_round,
                "aggregation_weights": aggregation_weights,
                "n_iter": n_iter,
            }
        )
        self.logger.debug("End accept")

        return True, False

    def aggregate(self, fl_ctx: FLContext) -> Shareable:
        """Called when workflow determines to generate shareable to send back to clients

        Args:
            fl_ctx (FLContext): context provided by workflow

        Returns:
            Shareable: the weighted mean of accepted shareables from clients
        """

        self.logger.debug("Start aggregation")
        server_fl_ctx_sanity_check(fl_ctx, check_peer=False)
        current_round = fl_ctx.get_prop(FLConstants.CURRENT_ROUND)
        self.logger.info(f"aggregating {len(self.history)} update(s) at round {current_round}")
        self.logger.debug(f"complete history {self.history}")
        aggregated_dict = dict()
        for k, v in self.total.items():
            aggregated_dict[k] = v / self.counts[k]
        self.reset_stats()
        self.logger.debug("End aggregation")

        shareable = Shareable()
        shareable[ShareableKey.TYPE] = ShareableValue.TYPE_WEIGHT_DIFF
        shareable[ShareableKey.DATA_TYPE] = ShareableValue.DATA_TYPE_UNENCRYPTED
        shareable[ShareableKey.MODEL_WEIGHTS] = aggregated_dict
        return shareable
