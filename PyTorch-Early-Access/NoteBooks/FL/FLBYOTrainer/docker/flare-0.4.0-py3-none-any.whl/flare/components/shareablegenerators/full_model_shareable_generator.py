from flare.apis.fl_constant import ShareableKey, ShareableValue
from flare.apis.fl_context import FLContext
from flare.apis.learnable import Learnable
from flare.apis.shareable import Shareable
from flare.apis.shareable_generator import ShareableGenerator


class FullModelShareableGenerator(ShareableGenerator):
    def learnable_to_shareable(self, model: Learnable, fl_ctx: FLContext) -> Shareable:
        """Convert Learnable to Shareable

        Args:
            model (Learnable): model to be converted
            fl_ctx (FLContext): FL context

        Returns:
            Shareable: a shareable with TYPE as TYPE_WEIGHTS,
             DATA_TYPE as DATA_TYPE_UNENCRYPTED, and MODEL_WEIGHTS as actual weights_dict
        """
        shareable = Shareable()
        weights_dict = {}
        for key, value in model.items():
            weights_dict.update({key: value})
        shareable[ShareableKey.TYPE] = ShareableValue.TYPE_WEIGHTS
        shareable[ShareableKey.DATA_TYPE] = ShareableValue.DATA_TYPE_UNENCRYPTED
        shareable[ShareableKey.MODEL_WEIGHTS] = weights_dict
        return shareable

    def shareable_to_learnable(self, shareable: Shareable, fl_ctx: FLContext) -> Learnable:
        """Convert Shareable to Learnable

        Supporting TYPE == TYPE_WEIGHT_DIFF or TYPE_WEIGHTS

        Args:
            shareable (Shareable): Shareable to be converted
            fl_ctx (FLContext): FL context

        Returns:
            Model: a model
        """
        type = shareable[ShareableKey.TYPE]

        model = None
        if type == ShareableValue.TYPE_WEIGHT_DIFF:
            model = fl_ctx.get_model()

            if shareable[ShareableKey.DATA_TYPE] == ShareableValue.DATA_TYPE_UNENCRYPTED:
                model_diff = shareable[ShareableKey.MODEL_WEIGHTS]
                for v_name, v_value in model_diff.items():
                    v_value += model[v_name]
                    model[v_name] = v_value
        elif type == ShareableValue.TYPE_WEIGHTS:
            model = shareable[ShareableKey.MODEL_WEIGHTS]

        return model
