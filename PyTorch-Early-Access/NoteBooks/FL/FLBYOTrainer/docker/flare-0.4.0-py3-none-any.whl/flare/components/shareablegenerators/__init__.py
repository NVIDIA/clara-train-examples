from .full_model_shareable_generator import FullModelShareableGenerator

__all__ = [FullModelShareableGenerator]
