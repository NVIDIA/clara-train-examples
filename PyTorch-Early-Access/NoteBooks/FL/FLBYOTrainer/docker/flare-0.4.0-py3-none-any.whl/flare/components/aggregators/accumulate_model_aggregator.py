import re
from typing import Tuple

import numpy as np

from flare.apis.aggregator import Aggregator
from flare.apis.fl_constant import FLConstants, ShareableKey, ShareableValue
from flare.apis.fl_context import FLContext
from flare.apis.shareable import Shareable
from flare.utils.fl_ctx_sanity_check import server_fl_ctx_sanity_check


class AccumulateWeightedAggregator(Aggregator):
    def __init__(self, exclude_vars=None, aggregation_weights=None):
        super().__init__()
        self.exclude_vars = re.compile(exclude_vars) if exclude_vars else None
        self.aggregation_weights = aggregation_weights if aggregation_weights else {}

        self.logger.debug(f"aggregation weights control: {aggregation_weights}")

        self.accumulator = []

    def accept(self, shareable: Shareable, fl_ctx: FLContext) -> Tuple[bool, bool]:
        server_fl_ctx_sanity_check(fl_ctx)
        current_round = fl_ctx.get_prop(FLConstants.CURRENT_ROUND)
        shared_fl_context = fl_ctx.get_prop(FLConstants.PEER_CONTEXT)
        client_name = shared_fl_context.get_prop(FLConstants.CLIENT_NAME)
        contribution_round = shared_fl_context.get_prop(FLConstants.CURRENT_ROUND)
        if contribution_round == current_round:
            # shared_fl_context.set_prop("shareable", shareable)
            if not self._client_in_accumulator(client_name):
                self.accumulator.append(shared_fl_context)
                accepted = True
            else:
                self.logger.info(
                    "Discarded: Current round: {} contributions already include client: {}".format(
                        current_round, client_name
                    )
                )
                accepted = False
        else:
            self.logger.info(
                "Discarded the contribution from {} for round: {}. Current round is: {}".format(
                    client_name, contribution_round, current_round
                )
            )
            accepted = False
        return accepted, False

    def _client_in_accumulator(self, client_name):
        for item in self.accumulator:
            if client_name == item.get_prop(FLConstants.CLIENT_NAME):
                return True
        return False

    def aggregate(self, fl_ctx: FLContext) -> Shareable:
        """
        Aggregate model variables.
        This function is not thread-safe.

        :return Return True to indicates the current model is the best model so far.
        """
        server_fl_ctx_sanity_check(fl_ctx)
        current_round = fl_ctx.get_prop(FLConstants.CURRENT_ROUND)
        self.logger.info("aggregating %s updates at round %s", len(self.accumulator), current_round)

        acc_vars = [
            set(acc.get_prop(FLConstants.SHAREABLE)[ShareableKey.MODEL_WEIGHTS].keys()) for acc in self.accumulator
        ]
        acc_vars = set.union(*acc_vars)
        # update vars that are not in exclude pattern
        vars_to_aggregate = (
            [g_var for g_var in acc_vars if not self.exclude_vars.search(g_var)] if self.exclude_vars else acc_vars
        )

        clients_with_messages = []
        aggregated_model_diff = {}
        for v_name in vars_to_aggregate:
            n_local_iters, np_vars = [], []
            for item in self.accumulator:

                client_name = item.get_prop(FLConstants.CLIENT_NAME)

                data = item.get_prop(FLConstants.SHAREABLE)[ShareableKey.MODEL_WEIGHTS]
                n_iter = (
                    item.get_prop(FLConstants.SHAREABLE)
                    .get(ShareableKey.META, {})
                    .get(FLConstants.NUM_STEPS_CURRENT_ROUND, 1.0)
                )
                if v_name not in data.keys():
                    continue  # this acc doesn't have the variable from client
                float_n_iter = np.float(n_iter)
                n_local_iters.append(float_n_iter)
                aggregation_weight = self.aggregation_weights.get(client_name, 1)
                weighted_value = data[v_name] * float_n_iter * aggregation_weight
                if client_name not in clients_with_messages:
                    if client_name in self.aggregation_weights.keys():
                        self.logger.debug(f"Client {client_name} use weight {aggregation_weight} for aggregation.")
                    else:
                        self.logger.debug(
                            f"Client {client_name} not defined in the aggregation weight list. Use default value 1.0"
                        )
                    clients_with_messages.append(client_name)
                np_vars.append(weighted_value)
            if not n_local_iters:
                continue  # all acc didn't receive the variable from clients
            new_val = np.sum(np_vars, axis=0) / np.sum(n_local_iters)
            aggregated_model_diff[v_name] = new_val

        self.accumulator.clear()

        shareable = Shareable()
        shareable[ShareableKey.TYPE] = ShareableValue.TYPE_WEIGHT_DIFF
        shareable[ShareableKey.DATA_TYPE] = ShareableValue.DATA_TYPE_UNENCRYPTED
        shareable[ShareableKey.MODEL_WEIGHTS] = aggregated_model_diff
        return shareable
