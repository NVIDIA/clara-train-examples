import gc
import logging
import math
import os
import re
import shlex
import subprocess
import threading
import time
import traceback
from multiprocessing.connection import Client

from dlmed.utils.wfconf import Configurator
from dlmed.utils.pipe.file_pipe import FilePipe

from .client_status import ClientStatus, get_status_message


class ClientExecutor(object):
    def __init__(self, uid) -> None:
        pipe_path = "/tmp/fl/" + uid + "/comm"
        if not os.path.exists(pipe_path):
            os.makedirs(pipe_path)

        self.pipe = FilePipe(root_path=pipe_path, name="training")
        self.logger = logging.getLogger(self.__class__.__name__)

    def start_train(self, client, args, mmar_root, mmar_custom_folder, listen_port):
        """
        start_train method to start the FL client training.
        :param client: the FL client object.
        :param args: admin command arguments for starting the FL client training.
        :param mmar_root: the root folder of the running MMAR.
        :return:
        """
        pass

    def start_mgpu_train(self, client, args, mmar_root, gpu_number, mmar_custom_folder, listen_port):
        """
        start the FL client training using multi-GPU.
        :param client: the FL client object.
        :param args: admin command arguments for starting the FL client training.
        :param mmar_root: the root folder of the running MMAR.
        :param gpu_number: number of GPUs to run FL training
        :return:
        """
        pass

    def check_status(self, client):
        """
        check the status of the running client.
        :param client: the FL client object.
        :return: running FL client status message.
        """
        pass

    def abort_train(self, client):
        """
        To abort the running client.
        :param client: the FL client object.
        :return: N/A
        """
        pass

    def cleanup(self):
        self.pipe.clear()


class ProcessExecutor(ClientExecutor):
    def __init__(self, uid):
        ClientExecutor.__init__(self, uid)
        # self.client = client

        self.conn_client = None
        # self.pool = None

        self.listen_port = 6000

    def get_conn_client(self):
        if not self.conn_client:
            try:
                address = ("localhost", self.listen_port)
                self.conn_client = Client(address, authkey="client process secret password".encode())
            except Exception as e:
                pass

    def create_pipe(self):
        """Create pipe to communicate between child (training) and main (logic) thread."""
        pipe = FilePipe(root_path="/fl/server", name="training")

        return pipe

    def start_train(self, client, args, mmar_root, mmar_custom_folder, listen_port):
        # self.pool = multiprocessing.Pool(processes=1)
        # result = self.pool.apply_async(_start_client, (client, args, mmar_root))

        # self.conn_client, child_conn = mp.Pipe()
        # process = multiprocessing.Process(target=_start_client, args=(client, args, mmar_root, child_conn, self.pipe))
        # # process = multiprocessing.Process(target=_start_new)
        # process.start()

        self.listen_port = listen_port

        new_env = os.environ.copy()
        new_env["PYTHONPATH"] = new_env["PYTHONPATH"] + ":" + mmar_custom_folder

        self.retrieve_cross_validate_setting(client, mmar_root)

        command = (
            "python -m flare.private.fed.app.client.admin_process_train -m " + args.mmar + " -s fed_client.json "
            " --set secure_train=true print_conf=True use_gpu="
            + str(client.use_gpu)
            + " multi_gpu=False uid="
            + client.uid
            + " config_folder="
            + client.config_folder
        )
        # use os.setsid to create new process group ID
        process = subprocess.Popen(shlex.split(command, " "), preexec_fn=os.setsid, env=new_env)

        print("training child process ID: {}".format(process.pid))

        client.process = process
        client.multi_gpu = False

        client.status = ClientStatus.TRAINING_STARTED
        thread = threading.Thread(
            target=self.wait_training_process_finish, args=(client, args, mmar_root, mmar_custom_folder)
        )
        thread.start()

    def retrieve_cross_validate_setting(self, client, mmar_root):
        if client.config_folder == "":
            client_config = "config_fed_client.json"
        else:
            client_config = client.config_folder + "/config_fed_client.json"
        client_config = os.path.join(mmar_root, client_config)
        conf = Configurator(
            mmar_root=mmar_root,
            cmd_vars={},
            env_config={},
            wf_config_file_name=client_config,
            base_pkgs=[],
            module_names=[],
        )
        conf.configure()
        client.cross_site_validate = conf.wf_config_data.get('cross_validate', False)

    def start_mgpu_train(self, client, args, mmar_root, gpu_number, mmar_custom_folder, listen_port):
        self.listen_port = listen_port

        new_env = os.environ.copy()
        new_env["PYTHONPATH"] = new_env["PYTHONPATH"] + ":" + mmar_custom_folder

        self.retrieve_cross_validate_setting(client, mmar_root)

        if client.platform == "PT":
            command = (
                "python -m torch.distributed.launch --nproc_per_node="
                + str(gpu_number)
                + " --nnodes=1 --node_rank=0 "
                + '--master_addr="localhost" --master_port=1234 '
                + "-m flare.private.fed.app.client.admin_process_train -m "
                + args.mmar
                + " -s fed_client.json "
                " --set secure_train=true print_conf=True use_gpu=True multi_gpu=True uid="
                + client.uid
                + " config_folder="
                + client.config_folder
            )
            # use os.setsid to create new process group ID
            process = subprocess.Popen(shlex.split(command, " "), preexec_fn=os.setsid, env=new_env)
        else:
            command = (
                "mpirun -np "
                + str(gpu_number)
                + " -H localhost:"
                + str(gpu_number)
                + " -bind-to none -map-by slot -x NCCL_DEBUG=DEBUG -x LD_LIBRARY_PATH -x PATH "
                "-mca pml ob1 -mca btl ^openib --allow-run-as-root "
                "python3 -u -m nvmidl.apps.fed_learn.client.admin_process_train -m "
                + args.mmar
                + " -s fed_client.json --set secure_train=true multi_gpu=true uid="
                + client.uid
                + " config_folder="
                + client.config_folder
            )
            process = subprocess.Popen(shlex.split(command, " "), env=new_env)
        client.process = process
        client.multi_gpu = True
        # self.pool = multiprocessing.Pool(processes=1)
        # result = self.pool.apply_async(self.call_mpirun, (client, args, mmar_root))

        client.status = ClientStatus.TRAINING_STARTED
        thread = threading.Thread(
            target=self.wait_training_process_finish, args=(client, args, mmar_root, mmar_custom_folder)
        )
        thread.start()

    def check_status(self, client):
        self.get_conn_client()

        if self.conn_client:
            self.conn_client.send("check_status")
            status_message = self.conn_client.recv()
            print("check status from process listener......")
            return status_message
        else:
            return get_status_message(client.status)

    def abort_train(self, client):
        # if client.status == ClientStatus.CROSS_SITE_VALIDATION:
        #     # Only aborts cross site validation.
        #     client.abort()
        # elif client.status == ClientStatus.TRAINING_STARTED:
        if client.status == ClientStatus.TRAINING_STARTED or client.status == ClientStatus.CROSS_SITE_VALIDATION:
            if client.process:
                # if client.platform == 'PT' and client.multi_gpu:
                #     # kill the sub-process group directly
                #     os.killpg(os.getpgid(client.process.pid), 9)
                # else:
                #     client.process.terminate()

                # kill the sub-process group directly
                if self.conn_client:
                    self.conn_client.send("abort")
                    self.logger.debug("abort sent")

                try:
                    os.killpg(os.getpgid(client.process.pid), 9)
                    self.logger.debug("kill signal sent")
                except Exception:
                    pass
                client.process.terminate()
                self.logger.debug("terminated")

            # if self.pool:
            #     self.pool.terminate()
            if self.conn_client:
                self.conn_client.close()
            self.conn_client = None
            self.cleanup()

        self.logger.info("Client training was terminated.")

    def wait_training_process_finish(self, client, args, mmar_root, mmar_custom_folder):
        # wait for the listen_command thread to start, and send "start" message to wake up the connection.
        start = time.time()
        while True:
            self.get_conn_client()
            if self.conn_client:
                self.conn_client.send("start")
                break
            time.sleep(1.0)
            if time.time() - start > 15:
                break

        self.logger.info("waiting for process to finish")
        client.process.wait()
        returncode = client.process.returncode
        self.logger.info(f"process finished with return code {returncode}")
        client.process = None

        if self.conn_client:
            self.conn_client.close()
        self.conn_client = None

        # # result.get()
        # self.pool.close()
        # self.pool.join()
        # self.pool.terminate()

        if client.cross_site_validate and not client.train_end:
            self.launch_cross_site_validation(client, args, mmar_root, mmar_custom_folder)
        else:
            client.status = ClientStatus.TRAINING_STOPPED

    # def wait_process_complete(self, client, args, mmar_root, mmar_custom_folder):
    #     time.sleep(5)
    #     self.get_conn_client()
    #
    #     if self.conn_client:
    #         self.conn_client.send('start')
    #
    #     client.process.wait()
    #     client.process = None
    #
    #     if self.conn_client:
    #         self.conn_client.close()
    #     self.conn_client = None
    #
    #     if not client.train_end:
    #         self.launch_cross_site_validation(client, args, mmar_root, mmar_custom_folder)

    def wait_cross_validation_finish(self, client, args, mmar_root):
        client.process.wait()
        client.process = None

        client.status = ClientStatus.TRAINING_STOPPED

        if self.conn_client:
            self.conn_client.close()
        self.conn_client = None

    def launch_cross_site_validation(self, client, args, mmar_root, mmar_custom_folder):

        # self.conn_client, child_conn = mp.Pipe()
        # process = multiprocessing.Process(target=_start_cross_validation, args=(client, args, mmar_root, self.pipe, child_conn))
        # # process = multiprocessing.Process(target=_start_new)
        # process.start()

        new_env = os.environ.copy()
        new_env["PYTHONPATH"] = new_env["PYTHONPATH"] + ":" + mmar_custom_folder

        command = 'python -m flare.private.fed.app.client.admin_process_validate -m ' + \
                  args.mmar + ' -s fed_client.json ' \
                  ' --set secure_train=true print_conf=True use_gpu=' + str(client.use_gpu) + \
                  ' multi_gpu=False uid=' + client.uid + ' config_folder=' + client.config_folder
        # use os.setsid to create new process group ID
        process = subprocess.Popen(shlex.split(command, " "), preexec_fn=os.setsid, env=new_env)

        print("cross_validation child process ID: {}".format(process.pid))

        client.process = process
        client.multi_gpu = False

        client.status = ClientStatus.CROSS_SITE_VALIDATION
        thread = threading.Thread(target=self.wait_cross_validation_finish, args=(client, args, mmar_root))
        thread.start()

        # update_cross_site_validation_config(client, args, mmar_root, self.pipe)
        #
        # client.cross_validation(client_local_rank=0)

    def close(self):
        if self.conn_client:
            self.conn_client.send("bye")
            self.conn_client = None
        self.cleanup()


# class ThreadExecutor(ClientExecutor):
#     def __init__(self, client, executor):
#         self.client = client
#         self.executor = executor

#     def start_train(self, client, args, mmar_root, mmar_custom_folder, listen_port):
#         future = self.executor.submit(lambda p: _start_client(*p), [client, args, mmar_root])

#     def start_mgpu_train(self, client, args, mmar_root, gpu_number, mmar_custom_folder, listen_port):
#         self.start_train(client, args, mmar_root)

#     def check_status(self, client):
#         return get_status_message(self.client.status)

#     def abort_train(self, client):
#         self.client.train_end = True
#         self.client.fitter.train_ctx.ask_to_stop_immediately()
#         self.client.fitter.train_ctx.set_prop("early_end", True)
#         # self.client.model_manager.close()
#         # self.client.status = ClientStatus.TRAINING_STOPPED
#         return "Aborting the client..."


def listen_command(client, conn):
    # address = ('localhost', 6000)  # family is deduced to be 'AF_INET'
    # listener = Listener(address, authkey='client process secret password'.encode())
    # conn = listener.accept()

    client.stop_listen = False
    while not client.stop_listen:
        msg = conn.recv()
        if msg == "check_status":
            conn.send(get_status_message(client.status))
            continue
        if msg == "bye":
            conn.close()
            break
    # listener.close()


def create_fl_trainer(client, trainer):
    fitter = trainer.create_fitter()
    trainer.set_model_manager(client.model_manager)

    # client.fitter = fitter
    return trainer


def update_client_properties(client, trainer):
    # servers = [{t['name']: t['service']} for t in trainer.server_config]
    retry_timeout = 30
    # if trainer.client_config['retry_timeout']:
    #     retry_timeout = trainer.client_config['retry_timeout']
    client.client_args = trainer.client_config
    # client.servers = sorted(servers)[0]
    client.model_manager.federated_meta = {task_name: list() for task_name in tuple(client.servers)}
    exclude_vars = trainer.client_config.get("exclude_vars", "dummy")
    client.model_manager.exclude_vars = re.compile(exclude_vars) if exclude_vars else None
    # client.model_manager.privacy_policy = trainer.privacy
    client.model_manager.model_reader_writer = trainer.model_reader_writer
    client.model_manager.model_validator = trainer.model_validator
    # client.pool = ThreadPool(len(client.servers))
    # client.communicator.ssl_args = trainer.client_config
    # client.communicator.secure_train = trainer.secure_train
    client.communicator.model_manager = client.model_manager
    client.communicator.should_stop = False
    client.communicator.retry = int(math.ceil(float(retry_timeout) / 5))
    client.communicator.outbound_filters = trainer.outbound_filters
    client.communicator.inbound_filters = trainer.inbound_filters
    client.handlers = trainer.handlers
    client.inbound_filters = trainer.inbound_filters
    # client.secure_train = trainer.secure_train
    client.heartbeat_done = False
    # client.fl_ctx = FLContext()
    client.train_end = False
