import time

from dlmed.hci.conn import Connection
from dlmed.hci.reg import CommandModule, CommandModuleSpec, CommandSpec

from flare.security.authz import Action, FLAuthzContext
from flare.private.fed.server.admin import new_message
from flare.utils.admin_defs import Message
from flare.utils.fl_exception import FLAdminException

from .mmar_authz import MMARAuthzService
from .server_status import ServerStatus


class TrainingCommandModule(CommandModule):
    def __init__(self, allowed_commands=None):
        self.allowed_commands = allowed_commands

    def get_spec(self):
        return CommandModuleSpec(
            name="training",
            cmd_specs=[
                CommandSpec(
                    name="start",
                    description="start the FL server/client training",
                    usage="start server/client",
                    handler_func=self.start_training,
                    authz_func=self.authorize_start_training,
                    visible=True,
                ),
                CommandSpec(
                    name="start_mgpu",
                    description="start the FL client training with multi-gpu",
                    usage="start_mgpu server/client gpu_number <client-name> ",
                    handler_func=self.start_mgpu_training,
                    authz_func=self.authorize_start_mgpu_training,
                    visible=True,
                ),
                CommandSpec(
                    name="abort",
                    description="abort the FL server/client training",
                    usage="abort server/client",
                    handler_func=self.abort_training,
                    authz_func=self.authorize_start_training,
                    visible=True,
                ),
                CommandSpec(
                    name="shutdown",
                    description="shutdown the FL server/client",
                    usage="shutdown server/client",
                    handler_func=self.shutdown,
                    authz_func=self.authorize_operate,
                    visible=True,
                    confirm="auth",
                ),
                CommandSpec(
                    name="remove_client",
                    description="remove_client the FL client",
                    usage="remove_client <client-name>",
                    handler_func=self.remove_client,
                    authz_func=self.authorize_remove_client,
                    visible=True,
                    confirm="auth",
                ),
                CommandSpec(
                    name="restart",
                    description="restart the FL server/client",
                    usage="restart server/client",
                    handler_func=self.restart,
                    authz_func=self.authorize_operate,
                    visible=True,
                    confirm="auth",
                ),
                CommandSpec(
                    name="check_status",
                    description="check_status the FL server/client",
                    usage="check_status server/client",
                    handler_func=self.check_status,
                    authz_func=self.authorize_check_status,
                    visible=True,
                ),
                CommandSpec(
                    name="set_run_number",
                    description="set the FL training run number",
                    usage="set_run_number number",
                    handler_func=self.set_run_number,
                    authz_func=self.authorize_set_run_number,
                    visible=True,
                ),
                CommandSpec(
                    name="deploy",
                    description="deploy MMAR to client/server",
                    usage="deploy <mmar> server/client <client-name>",
                    handler_func=self.deploy,
                    authz_func=self.authorize_deploy,
                    visible=True,
                ),
                CommandSpec(
                    name="set_timeout",
                    description="set the admin commands timeout",
                    usage="set_timeout seconds ",
                    handler_func=self.set_timeout,
                    authz_func=self.authorize_set_timeout,
                    visible=True,
                ),
                CommandSpec(
                    name="delete_run_number",
                    description="delete the FL training run number",
                    usage="delete_run_number number",
                    handler_func=self.delete_run_number,
                    authz_func=self.authorize_set_run_number,
                    visible=True,
                    confirm="auth",
                ),
                # CommandSpec(
                #     name='set_min_clients',
                #     description='set the mininum number of clients',
                #     usage='set_min_clients number',
                #     handler_func=self.set_min_clients,
                #     authz_func=self.authorize_set_run_number,
                #     visible=True,
                #     confirm="auth",
                # ),
            ],
        )

    def authorize_start_training(self, conn: Connection, args: [str]):
        if len(args) < 2:
            conn.append_error("syntax error: missing site names")
            return False, None

        dest = args[1]
        if dest == "server":
            return True, FLAuthzContext.new_authz_context(site_names=["server"], actions=[Action.TRAIN])
        elif dest == "client":
            sai = conn.app_ctx
            if len(args) == 2:
                clients = sai.get_all_clients()
                client_names = sai.get_all_client_names()
            else:
                clients, invalid_inputs = sai.get_all_tokens_from_inputs(args[2:])
                client_names, _ = sai.get_all_client_names_from_inputs(args[2:])
                if invalid_inputs:
                    conn.append_error("There's invalid clients: {}".format(" ".join(invalid_inputs)))
                    return False, None
            conn.set_prop("target_clients", clients)
            return True, FLAuthzContext.new_authz_context(site_names=client_names, actions=[Action.TRAIN])
        else:
            # conn.append_string("unknown command. Usage: start server/client ...")
            return True, None

    def start_training(self, conn: Connection, args: [str]):
        sai = conn.app_ctx
        dest = args[1]
        if dest == "server":
            response = sai.start_server_training()
            conn.append_string(response)
            return

        if dest == "client":
            message, status, clients = sai.check_status()
            # if not ('status: training starting' in response or 'status: training started' in response):
            if status != ServerStatus.TRAINING_STARTING and status != ServerStatus.TRAINING_STARTED:
                conn.append_string("Server training has not started.")
                return

            message = new_message(conn, topic=args[0], body="")
            message.set_header("run_number", str(sai.get_run_number()))

            requests = {}
            clients = conn.get_prop("target_clients")
            for client in clients:
                requests.update({client.strip(): message})
            server = conn.server
            response = self.get_client_cmd_reply(sai, requests, server)

            conn.append_string(response)
            return

        conn.append_string("unknown command. Usage: start server/client ...")

    def authorize_start_mgpu_training(self, conn: Connection, args: [str]):
        if len(args) < 2:
            conn.append_error("syntax error: missing site names")
            return False, None

        sai = conn.app_ctx
        dest = args[1]
        if dest == "server":
            conn.append_error("FL server does not support start_mgpu command.")
            return False, None
        elif dest == "client":
            if len(args) == 3:
                clients = sai.get_all_clients()
                client_names = sai.get_all_client_names()
            else:
                clients, invalid_inputs = sai.get_all_tokens_from_inputs(args[3:])
                client_names, _ = sai.get_all_client_names_from_inputs(args[3:])
                if invalid_inputs:
                    conn.append_error("There's invalid clients: {}".format(" ".join(invalid_inputs)))
                    return False, None

            conn.set_prop("target_clients", clients)
            return True, FLAuthzContext.new_authz_context(site_names=client_names, actions=[Action.TRAIN])
        else:
            # conn.append_string("unknown command. Usage: start_mgpu server/client gpu_number <client-name> ...")
            return True, None

    def start_mgpu_training(self, conn: Connection, args: [str]):
        if len(args) < 2:
            conn.append_error("syntax error: missing site names")
            return

        sai = conn.app_ctx
        dest = args[1]
        if dest == "server":
            conn.append_error("FL server does not support start_mgpu command.")
            return

        if dest == "client":
            message, status, clients = sai.check_status()
            # if not ('status: training starting' in response or 'status: training started' in response):
            if status != ServerStatus.TRAINING_STARTING and status != ServerStatus.TRAINING_STARTED:
                conn.append_string("Server training has not started.")
                return

            if len(args) < 3:
                conn.append_error("Must provide a valid multi-gpu number.")
                conn.append_string("Usage: start_mgpu client gpu_number <client-name> ")
                return
            try:
                gpu_number = int(args[2])
                if gpu_number < 2:
                    conn.append_error("Must provide a valid multi-gpu integer number.")
                    return
            except ValueError:
                conn.append_error("Must provide a valid multi-gpu number.")
                return

            message = new_message(conn, topic=args[0], body="")
            message.set_header("run_number", str(sai.get_run_number()))
            message.set_header("gpu_number", str(gpu_number))

            requests = {}
            clients = conn.get_prop("target_clients")

            for client in clients:
                requests.update({client.strip(): message})
            server = conn.server
            response = self.get_client_cmd_reply(sai, requests, server)

            conn.append_string(response)
            return

        conn.append_string("unknown command. Usage: start_mgpu server/client gpu_number <client-name> ...")

    def get_client_cmd_reply(self, sai, requests, server):
        replies = server.send_requests(requests, timeout_secs=server.timeout)
        response = "No replies"
        if replies:
            response = ""
            for r in replies:
                response += "instance:" + sai.get_instance_name_from_token(r.client_name)
                if r.reply:
                    response += " : " + r.reply.body + "\n"
                else:
                    response += " : No replies\n"
        return response

    def abort_training(self, conn: Connection, args: [str]):
        if len(args) < 2:
            conn.append_error("syntax error: missing site names")
            return

        sai = conn.app_ctx
        message = new_message(conn, topic=args[0], body="")
        requests = {}

        dest = args[1]
        if dest == "server":
            conn.append_string("Trying to abort all clients before abort server ...")

            clients = sai.get_all_clients()
            response = self.abort_clients(clients, conn, message, requests, sai)
            conn.append_string(response)

            if "please wait" not in response:
                response = sai.stop_server_training()
                conn.append_string(response)
            else:
                conn.append_string("Please abort all clients before aborting server.")

            return

        if dest == "client":
            clients = conn.get_prop("target_clients")

            response = self.abort_clients(clients, conn, message, requests, sai)
            conn.append_string(response)
            return

        conn.append_string("unknown command. Usage: abort server/client ...")

    def abort_clients(self, clients, conn, message, requests, sai):
        for client in clients:
            client_token = client.strip()
            requests.update({client_token: message})
            sai.reset_model_for_client(client_token)
        server = conn.server
        response = self.get_client_cmd_reply(sai, requests, server)
        return response

    def authorize_check_status(self, conn: Connection, args: [str]):
        if len(args) < 2:
            conn.append_error("syntax error: missing site names")
            return False, None

        dest = args[1]
        if dest == "server":
            return True, FLAuthzContext.new_authz_context(site_names=["server"], actions=[Action.VIEW])
        elif dest == "client":
            sai = conn.app_ctx
            if len(args) == 2:
                clients = sai.get_all_clients()
                client_names = sai.get_all_client_names()
            else:
                clients, invalid_inputs = sai.get_all_tokens_from_inputs(args[2:])
                client_names, _ = sai.get_all_client_names_from_inputs(args[2:])
                if invalid_inputs:
                    conn.append_error("There's invalid clients: {}".format(" ".join(invalid_inputs)))
                    return False, None
            conn.set_prop("target_clients", clients)
            return True, FLAuthzContext.new_authz_context(site_names=client_names, actions=[Action.VIEW])
        else:
            # conn.append_string("unknown command. Usage: start server/client ...")
            return True, None

    def check_status(self, conn: Connection, args: [str]):
        if len(args) < 2:
            conn.append_error("syntax error: missing site names")
            return

        sai = conn.app_ctx
        dest = args[1]
        if dest == "server":
            submitted_clients, current_round = sai.check_aggregation()
            contribution_count = 0
            for _, v in submitted_clients.items():
                if current_round == v["last_round"]:
                    contribution_count += 1

            message, status, clients = sai.check_status()
            conn.append_string(message)

            conn.append_string("Registered clients: {} ".format(len(clients)))
            if status == ServerStatus.TRAINING_STARTING or status == ServerStatus.TRAINING_STARTED:
                conn.append_string(
                    "Total number of clients submitted models for current round: {}".format(contribution_count)
                )

            table = conn.append_table(["client name", "token", "Last Accepted Round", "Contribution Count"])
            for k, v in clients.items():
                # if v.client_id in submitted_clients:
                #     client_contrib = 'Yes'
                # else:
                #     client_contrib = ''
                client_contrib = submitted_clients.get(v.client_id, None)
                if client_contrib:
                    last_round = client_contrib["last_round"]
                    count = client_contrib["contribution_count"]
                else:
                    last_round = ""
                    count = 0
                table.add_row([v.client_id, k, str(last_round), str(count)])

            return

        if dest == "client":
            message = new_message(conn, topic=args[0], body="")

            requests = {}
            clients = conn.get_prop("target_clients")

            for client in clients:
                requests.update({client.strip(): message})
            server = conn.server
            response = self.get_client_cmd_reply(sai, requests, server)

            conn.append_string(response)
            return

        conn.append_string("unknown command. Usage: check_status server/client ...")

    def authorize_operate(self, conn: Connection, args: [str]):
        if len(args) < 2:
            conn.append_error("syntax error: missing site names")
            return False, None

        dest = args[1]
        if dest == "server":
            return True, FLAuthzContext.new_authz_context(site_names=["server"], actions=[Action.OPERATE])
        elif dest == "client":
            sai = conn.app_ctx
            if len(args) == 2:
                clients = sai.get_all_clients()
                client_names = sai.get_all_client_names()
            else:
                clients, invalid_inputs = sai.get_all_tokens_from_inputs(args[2:])
                client_names, _ = sai.get_all_client_names_from_inputs(args[2:])
                if invalid_inputs:
                    conn.append_error("There's invalid clients: {}".format(" ".join(invalid_inputs)))
                    return False, None
            conn.set_prop("target_clients", clients)
            return True, FLAuthzContext.new_authz_context(site_names=client_names, actions=[Action.OPERATE])
        else:
            # conn.append_string("unknown command. Usage: start server/client ...")
            return True, None

    def shutdown(self, conn: Connection, args: [str]):
        if len(args) < 2:
            conn.append_error("syntax error: missing site names")
            return

        dest = args[1]
        if dest == "server":
            sai = conn.app_ctx
            if sai.get_all_clients():
                conn.append_error("There are still active clients. Shutdown all clients first.")
                return

            response = sai.fl_shutdown()
            conn.append_string(response)
            conn.append_shutdown("Bye-bye")
            return

        if dest == "client":
            sai = conn.app_ctx

            clients = conn.get_prop("target_clients")

            message = new_message(conn, topic=args[0], body="")
            requests = {}
            for client in clients:
                requests.update({client.strip(): message})
                sai.remove_dead_client(client.strip())
            server = conn.server
            response = self.get_client_cmd_reply(sai, requests, server)
            conn.append_string(response)
            return

        conn.append_string("unknown command. Usage: shutdown server/client ...")

    def authorize_remove_client(self, conn: Connection, args: [str]):
        if len(args) < 2:
            conn.append_error("syntax error: missing site names")
            return False, None

        sai = conn.app_ctx
        clients, invalid_inputs = sai.get_all_tokens_from_inputs(args[1:])
        if invalid_inputs:
            conn.append_error("There's invalid clients: {}".format(" ".join(invalid_inputs)))
            return False, None

        conn.set_prop("target_clients", clients)
        return True, FLAuthzContext.new_authz_context(site_names=["server"], actions=[Action.OPERATE])

    def remove_client(self, conn: Connection, args: [str]):
        if len(args) < 2:
            conn.append_error("syntax error: missing client names")
            return

        sai = conn.app_ctx
        # clients, invalid_inputs = sai.get_all_tokens_from_inputs(args[1:])
        clients = conn.get_prop("target_clients")
        for client in clients:
            sai.remove_dead_client(client.strip())

    def restart(self, conn: Connection, args: [str]):
        if len(args) < 2:
            conn.append_error("syntax error: missing site names")
            return

        message = Message(topic=args[0], body="")
        requests = {}
        dest = args[1]
        if dest == "server":
            sai = conn.app_ctx

            conn.append_string("Trying to abort all clients before abort server ...")

            clients = sai.get_all_clients()
            response = self.restart_clients(clients, conn, message, requests, sai)
            conn.append_string(response)
            time.sleep(5)

            response = sai.fl_restart()
            conn.append_string(response)
            return

        if dest == "client":
            sai = conn.app_ctx

            clients = conn.get_prop("target_clients")

            self.restart_clients(clients, conn, message, requests, sai)
            return

        conn.append_string("unknown command. Usage: restart server/client ...")

    def restart_clients(self, clients, conn, message, requests, sai):
        for client in clients:
            requests.update({client.strip(): message})
            sai.remove_dead_client(client.strip())
        server = conn.server
        response = self.get_client_cmd_reply(sai, requests, server)
        return response

    def authorize_set_run_number(self, conn: Connection, args: [str]):
        if len(args) < 2:
            conn.append_error("syntax error: missing run number")
            return False, None

        try:
            num = int(args[1])
        except ValueError:
            conn.append_error("run number need to be an integer.")
            return False, None

        if num < 0:
            conn.append_error("run number should be >= 0.")
            return False, None

        return True, FLAuthzContext.new_authz_context(site_names=["server"], actions=[Action.TRAIN])

    def set_run_number(self, conn: Connection, args: [str]):
        num = int(args[1])
        sai = conn.app_ctx
        conn.append_string(sai.set_run_number(num))

    def delete_run_number(self, conn: Connection, args: [str]):
        num = int(args[1])
        sai = conn.app_ctx

        _, status, _ = sai.check_status()
        if status == ServerStatus.TRAINING_STARTING or status == ServerStatus.TRAINING_STARTED:
            run_number = sai.get_run_number()
            if run_number == num:
                conn.append_error("Current running run_number can not be deleted.")
                return

        conn.append_string(sai.delete_run_number(num))

        requests = {}
        message = Message(topic=args[0], body="")
        message.set_header("run_number", str(num))
        clients = sai.get_all_clients()
        for client in clients:
            requests.update({client.strip(): message})
        server = conn.server
        response = self.get_client_cmd_reply(sai, requests, server)

        conn.append_string(response)

    def authorize_deploy(self, conn: Connection, args: [str]):
        if len(args) < 3:
            conn.append_error("syntax error: missing site names")
            return False, None

        sai = conn.app_ctx
        if sai.get_run_number() == -1:
            conn.append_string("Please set a FL run number.")
            return False, None

        mmar_name = args[1]
        mmar_path = sai.get_mmar_path(mmar_name)
        dest = args[2]
        if dest == "server":
            conn.set_prop("target", "server")
            err, authz_ctx = MMARAuthzService.authorize_deploy(mmar_path, ["server"])
            if err:
                conn.append_error(err)
                return False, None
            else:
                return True, authz_ctx
        elif dest == "client":
            conn.set_prop("target", "client")
            if len(args) == 3:
                client_names = conn.app_ctx.get_all_client_names()
            else:
                client_names, invalid_inputs = conn.app_ctx.get_all_client_names_from_inputs(args[3:])
                if invalid_inputs:
                    conn.append_error("There's invalid clients: {}".format(" ".join(invalid_inputs)))
                    return False, None
            conn.set_prop("target_clients", client_names)
            err, authz_ctx = MMARAuthzService.authorize_deploy(mmar_path, client_names)
            if err:
                conn.append_error(err)
                return False, None
            else:
                return True, authz_ctx
        else:
            conn.append_string("unknown command. Usage: deploy mmar server/client ...")
            return False, None

    def deploy(self, conn: Connection, args: [str]):
        sai = conn.app_ctx
        mmar = args[1]
        dest = args[2]
        if dest == "server":
            response = sai.deploy_mmar(mmar, "mmar_server")
            conn.append_string(response)
            return

        client_names = conn.get_prop("target_clients")
        requests = {}
        for client_name in client_names:
            try:
                message = sai.deploy_mmar(mmar, "mmar_" + client_name)
                if "does not exist" in message:
                    conn.append_error(message)
                    return message

                data = sai.get_client_mmar(client_name)
            except FLAdminException as e:
                conn.append_string(e.args[0])
                return

            message = Message(topic=args[0], body=data)

            client_tokens = sai.get_all_register_tokens(client_name)
            for token in client_tokens:
                requests.update({token: message})

        server = conn.server
        response = self.get_client_cmd_reply(sai, requests, server)
        conn.append_string(response)

    def authorize_set_timeout(self, conn: Connection, args: [str]):
        if len(args) != 2:
            conn.append_error("syntax error: missing timeout")
            return False, None

        try:
            num = float(args[1])
        except ValueError:
            conn.append_error("must provide the timeout value in seconds")
            return False, None

        if num < 0:
            conn.append_error("timeout need to be >= 0")
            return False, None

        return True, FLAuthzContext.new_authz_context(site_names=["server"], actions=[Action.TRAIN])

    def set_timeout(self, conn: Connection, args: [str]):
        timeout = float(args[1])
        server = conn.server
        server.timeout = timeout
        conn.append_string("admin command timeout has been set to: {}".format(timeout))

    def set_min_clients(self, conn: Connection, args: [str]):
        if len(args) < 2:
            conn.append_error("syntax error: missing run number")
            return

        try:
            num = int(args[1])
        except ValueError:
            conn.append_error("run number need to be an integer.")
            return

        if num < 0:
            conn.append_error("run number should be >= 0.")
            return

        sai = conn.app_ctx
        sai.set_min_clients(num)
        conn.append_string("min_num_clients has been set to {}".format(num))
