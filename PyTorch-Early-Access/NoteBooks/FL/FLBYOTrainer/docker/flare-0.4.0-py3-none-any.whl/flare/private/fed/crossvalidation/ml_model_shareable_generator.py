
import os
import logging
import threading

from flare.apis.fl_constant import ShareableKey, ShareableValue
from flare.utils.fed_utils import generate_empty_shareable
from flare.apis.shareable import Shareable
from flare.utils.ml_model_registry import MLModelEntry


class MLModelShareableGenerator(object):

    def __init__(self) -> None:
        super().__init__()
        self.logger = logging.getLogger(self.__class__.__name__)
        self._update_lock = threading.Lock()

    def ml_model_entry_to_shareable(self, ml_model_entry) -> Shareable:
        if not ml_model_entry:
            self.logger.info(f"No model entry found for key {ml_model_entry.model_key}")
            return generate_empty_shareable(cookie=None)
        else:
            # Load model files
            try:
                data = {data_type: open(path, 'rb').read() for data_type, path in ml_model_entry.files.items()}
            except Exception as e:
                self.logger.info(f"Unable to load model files. Exception: {e}")
                return generate_empty_shareable(cookie=None)

            model_shareable = Shareable()
            model_shareable[ShareableKey.TYPE] = ShareableValue.TYPE_ML_MODEL
            model_shareable[ShareableKey.DATA_TYPE] = ShareableValue.DATA_TYPE_BYTES
            model_shareable[ShareableKey.MODEL_NAME] = ml_model_entry.name
            model_shareable[ShareableKey.DATA] = data
            model_shareable[ShareableKey.META] = ml_model_entry.meta.copy()

        return model_shareable

    def shareable_to_ml_model_entry(self, shareable: Shareable, save_dir) -> MLModelEntry:
        if shareable.get(ShareableKey.TYPE) != ShareableValue.TYPE_ML_MODEL:
            raise ValueError("Shareable must be of type TYPE_ML_MODEL.")

        model_name = shareable[ShareableKey.MODEL_NAME]
        self.logger.debug(f"Creating MLModelEntry from shareable for model {model_name}.")

        files = shareable.get(ShareableKey.DATA)
        ml_model_entry = MLModelEntry(model_name)

        # Save files and create MLModelEntry
        try:
            # Serialize the data
            for data_key, data in files.items():
                open(os.path.join(save_dir, model_name + '.' + data_key), 'wb').write(data)

            # Set new paths in model entry
            files_dict = {data_key: os.path.join(save_dir, model_name +'.' + data_key) for data_key, _ in files.items()}
            ml_model_entry.add_files(files_dict)
        except Exception as e:
            self.logger.info(f"Unable to convert shareable to MLModelEntry. Exception {e}")
            return None

        return ml_model_entry
