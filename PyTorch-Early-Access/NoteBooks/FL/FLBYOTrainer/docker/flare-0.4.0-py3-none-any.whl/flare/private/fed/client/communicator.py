import logging
import math
import socket
import time
from typing import List

import grpc

import flare.private.fed.protos.federated_pb2 as fed_msg
import flare.private.fed.protos.federated_pb2_grpc as fed_service
from google.protobuf.struct_pb2 import Struct
from .data_assembler import DataAssembler
from flare.apis.filter import Filter
from flare.apis.fl_constant import FLConstants
from flare.apis.fl_context import FLContext
from flare.utils.fed_utils import VERBOSE
from flare.utils.fl_exception import FLCommunicationException


class Communicator:
    def __init__(
        self,
        model_manager,
        ssl_args=None,
        secure_train=False,
        retry_timeout=30,
        outbound_filters: List[Filter] = None,
        inbound_filters: List[Filter] = None,
        client_state_processors: List[Filter] = None,
        compression=None,
    ):
        self.ssl_args = ssl_args
        self.secure_train = secure_train
        self.model_manager = model_manager

        self.verbose = VERBOSE
        self.should_stop = False
        self.heartbeat_done = False
        self.retry = int(math.ceil(float(retry_timeout) / 5))
        self.data_assembler = DataAssembler()
        self.outbound_filters = outbound_filters
        self.inbound_filters = inbound_filters
        self.client_state_processors = client_state_processors
        self.compression = compression
        #
        # #   For Tesing .....
        # from fed_learn.components.data_processor import ModelEncryptor, DataCompressor, DataDeCompressor, ModelDecryptor
        # from fed_learn.components.metadata_generator import IteratorNumberGenerator, BestMetricGenerator
        # self.outbound_filters = [IteratorNumberGenerator('n_iter'), BestMetricGenerator('best_metric'), ModelEncryptor(), DataCompressor()]
        # self.inbound_filters = [DataDeCompressor(), ModelDecryptor()]

        self.logger = logging.getLogger(self.__class__.__name__)

    def set_up_channel(self, channel_dict, token=None):
        """
        Connect client to the server.

        :param channel_dict: grpc channel parameters
        :param token: client token
        :return: an initialised grpc channel
        """
        if self.secure_train:
            with open(self.ssl_args["ssl_root_cert"], "rb") as f:
                trusted_certs = f.read()
            with open(self.ssl_args["ssl_private_key"], "rb") as f:
                private_key = f.read()
            with open(self.ssl_args["ssl_cert"], "rb") as f:
                certificate_chain = f.read()

            credentials = grpc.ssl_channel_credentials(
                certificate_chain=certificate_chain, private_key=private_key, root_certificates=trusted_certs
            )

            # make sure that all headers are in lowecase,
            # otherwise grpc throws an exception
            call_credentials = grpc.metadata_call_credentials(
                lambda context, callback: callback((("x-custom-token", token),), None)
            )
            # use this if you want standard "Authorization" header
            # call_credentials = grpc.access_token_call_credentials(
            #     "x-custom-token")
            composite_credentials = grpc.composite_channel_credentials(credentials, call_credentials)
            channel = grpc.secure_channel(
                **channel_dict, credentials=composite_credentials, compression=self.compression
            )

        else:
            channel = grpc.insecure_channel(**channel_dict, compression=self.compression)
        return channel

    def get_client_state(self, task_name, token):
        """
        Client's meta data used to authenticate and communicate.

        :return: a ClientState message.
        """
        state_message = fed_msg.ClientState(token=token)
        state_message.meta.task.name = task_name
        # if self.client_state_processors and app_ctx:
        #     for t in self.client_state_processors:
        #         state_message = t.process(state_message, app_ctx)
        return state_message

    def client_registration(self, uid, servers, task_name):
        """
        Client's meta data used to authenticate and communicate.

        :return: a ClientLogin message.
        """
        local_ip = socket.gethostbyname(socket.gethostname())
        login_message = fed_msg.ClientLogin(client_id=uid, client_ip=local_ip)
        # login_message = fed_msg.ClientLogin(
        #     client_id=None, token=None, client_ip=local_ip)
        login_message.meta.task.name = task_name

        result, retry = None, self.retry
        retry = 1500  # retry register for 2 hours (7500s)
        with self.set_up_channel(servers[task_name]) as channel:
            stub = fed_service.FederatedTrainingStub(channel)
            while retry > 0:
                try:
                    start_time = time.time()
                    result = stub.Register(login_message)
                    token = result.token
                    self.should_stop = False
                    break
                except grpc.RpcError as grpc_error:
                    self.grpc_error_handler(
                        servers[task_name], grpc_error, "client_registration", start_time, retry, verbose=self.verbose
                    )
                    excep = FLCommunicationException(grpc_error)
                    if isinstance(grpc_error, grpc.Call):
                        status_code = grpc_error.code()
                        if grpc.StatusCode.UNAUTHENTICATED == status_code:
                            raise excep
                    retry -= 1
                    time.sleep(5)
            if self.should_stop:
                raise excep
            if result is None:
                return None

        return token

    def getModel(self, servers, task_name, token):
        """
        Get registered with the remote server via channel,
        and fetch the server's model parameters.

        :param task_name: server identifier string
        :return: a CurrentModel message from server
        """
        global_model, retry = None, self.retry
        with self.set_up_channel(servers[task_name]) as channel:
            stub = fed_service.FederatedTrainingStub(channel)
            while retry > 0:
                # get the global model
                try:
                    start_time = time.time()
                    global_model = stub.GetModel(self.get_client_state(task_name, token))
                    # Clear the stopping flag
                    # if the connection to server recovered.
                    self.should_stop = False

                    end_time = time.time()
                    self.logger.info(
                        f"Received {task_name} model at round {global_model.meta.current_round}"
                        f" ({global_model.ByteSize()} Bytes). GetModel time: {end_time - start_time} seconds"
                    )

                    contribution_ctx = FLContext()
                    contribution_ctx.set_model(global_model.data)
                    contribution_ctx.set_prop(FLConstants.META, global_model.meta, private=False)
                    contribution_ctx.set_prop(FLConstants.META_DATA, global_model.meta_data, private=False)
                    # if self.inbound_filters:
                    #     for t in self.inbound_filters:
                    #         contribution_ctx = t.process(contribution_ctx, app_ctx)
                    current_model = fed_msg.CurrentModel()
                    current_model.meta.CopyFrom(contribution_ctx.get_prop(FLConstants.META))
                    current_model.meta_data.CopyFrom(contribution_ctx.get_prop(FLConstants.META_DATA))
                    current_model.data.CopyFrom(contribution_ctx.get_model())

                    return current_model
                except grpc.RpcError as grpc_error:
                    self.grpc_error_handler(
                        servers[task_name], grpc_error, "getModel", start_time, retry, verbose=self.verbose
                    )
                    excep = FLCommunicationException(grpc_error)
                    retry -= 1
                    time.sleep(5)
            if self.should_stop:
                raise excep

        # Failed to get global, return None
        return None

    def submit_cross_site_validation_results(self, uid, servers, task_name, token, metric_shareable):
        """
        Submit results of cross validation to server.

        :param client_names: List of client names
        :param client_metrics: List of dicts. Each dict is set of metric names and values.
        """
        client_state = self.get_client_state(task_name, token)
        client_state.uid = uid

        # Create a protobuf message
        validation_result_msg = fed_msg.ValidationResults()
        validation_result_msg.shareable = metric_shareable.to_bytes()
        validation_result_msg.client.CopyFrom(client_state)

        server_msg, retry = None, self.retry
        with self.set_up_channel(servers[task_name]) as channel:
            stub = fed_service.FederatedTrainingStub(channel)
            while retry > 0:
                try:
                    start_time = time.time()
                    server_msg = stub.SubmitCrossSiteValidationResults(validation_result_msg)

                    # Clear the stopping flag
                    # if the connection to server recovered.
                    self.should_stop = False

                    end_time = time.time()
                    self.logger.info(
                        f"Received comments: {server_msg.meta.task.name} {server_msg.comment}."
                        f" SubmitCrossSiteValidationResults time: {end_time - start_time} seconds"
                    )
                    break
                except grpc.RpcError as grpc_error:
                    if isinstance(grpc_error, grpc.Call):
                        self.logger.info(f"Submit Cross Site Validation Results: {grpc_error.details()}")
                    self.grpc_error_handler(
                        servers[task_name],
                        grpc_error,
                        "submit_cross_site_validation_results",
                        start_time,
                        retry,
                        verbose=self.verbose,
                    )
                    excep = FLCommunicationException(grpc_error)
                    retry -= 1
                    time.sleep(5)
            if self.should_stop:
                raise excep

    def get_validation_models(self, uid, servers, task_name, token):
        """Send a request to server to get models for cross validation.

        :param task_name: server identifier string
        :return: a CurrentModel message from server
        """
        validation_models, retry = None, self.retry
        client = self.get_client_state(task_name, token)
        client.uid = uid

        with self.set_up_channel(servers[task_name]) as channel:
            stub = fed_service.FederatedTrainingStub(channel)
            while retry > 0:
                # Get validation models from server
                try:
                    start_time = time.time()
                    validation_models = stub.GetValidationModels(client)

                    # Clear the stopping flag
                    # if the connection to server recovered.
                    self.should_stop = False

                    end_time = time.time()
                    self.logger.info(
                        f"Received {len(validation_models.models)} models for validation."
                        f" GetValidationModels time: {end_time - start_time} seconds"
                    )

                    return validation_models
                except grpc.RpcError as grpc_error:
                    self.grpc_error_handler(
                        servers[task_name], grpc_error, "get_validation_models", start_time, retry, verbose=self.verbose
                    )
                    excep = FLCommunicationException(grpc_error)
                    retry -= 1
                    time.sleep(5)
            if self.should_stop:
                raise excep

        # Failed to get validation models, return None
        return None

    def submitUpdate(self, servers, task_name, token, fl_ctx: FLContext, uid, shareable):
        client_state = self.get_client_state(task_name, token)
        client_state.uid = uid
        contrib = self.data_assembler.get_contribution_data(
            shareable, self.model_manager, task_name, client_state, self.outbound_filters, fl_ctx
        )

        server_msg, retry = None, self.retry
        with self.set_up_channel(servers[task_name]) as channel:
            stub = fed_service.FederatedTrainingStub(channel)
            while retry > 0:
                try:
                    start_time = time.time()
                    self.logger.info(f"Send {task_name} at round {contrib.client.meta.current_round}")
                    # print('send update model for round: {}'.format(contrib.client.meta.current_round))
                    server_msg = stub.SubmitUpdate(contrib)
                    # Clear the stopping flag
                    # if the connection to server recovered.
                    self.should_stop = False

                    end_time = time.time()
                    self.logger.info(
                        f"Received comments: {server_msg.meta.task.name} {server_msg.comment}."
                        f" SubmitUpdate time: {end_time - start_time} seconds"
                    )
                    # print('Received server ack: {}'.format(server_msg.comment))
                    break
                except grpc.RpcError as grpc_error:
                    if isinstance(grpc_error, grpc.Call):
                        if grpc_error.details().startswith("Contrib"):
                            self.logger.info(f"Publish model failed: {grpc_error.details()}")
                            # print('Publish model failed: {}'.format(grpc_error.details()))
                            break  # outdated contribution, no need to retry
                    self.grpc_error_handler(
                        servers[task_name], grpc_error, "submitUpdate", start_time, retry, verbose=self.verbose
                    )
                    retry -= 1
                    time.sleep(5)
        return server_msg

    def submit_best_local_model(self, uid, servers, task_name, token, model_shareable, fl_ctx):
        """
        Submit the best local model to server.

        :param task_name: server task identifier
        :param disable: Send an empty message (signals not participating.)
        :param model_dir: Directory where best models are saved.
        :param model_name: Name of saved model.
        :return: server's reply to the last message.
        """
        client_state = self.get_client_state(task_name, token)
        client_state.uid = uid
        shareable_bytes = model_shareable.to_bytes()
        s = Struct()
        for k, v in fl_ctx.get_all_public_props().items():
            s.update({k: v})

        best_model_msg = fed_msg.LocalModel()
        best_model_msg.client.CopyFrom(client_state)
        best_model_msg.data = shareable_bytes
        best_model_msg.fl_context.CopyFrom(s)

        server_msg, retry = None, self.retry
        with self.set_up_channel(servers[task_name]) as channel:
            stub = fed_service.FederatedTrainingStub(channel)
            while retry > 0:
                try:
                    start_time = time.time()
                    server_msg = stub.SubmitBestLocalModel(best_model_msg)

                    # Clear the stopping flag
                    # if the connection to server recovered.
                    self.should_stop = False

                    end_time = time.time()
                    self.logger.info(
                        f"Server reply to SubmitBestLocalModel: {server_msg.meta.task.name}"
                        f" {server_msg.comment}. SubmitBestLocalModel time: {end_time - start_time} seconds"
                    )
                    break
                except grpc.RpcError as grpc_error:
                    if isinstance(grpc_error, grpc.Call):
                        self.logger.info(f"SubmitBestLocalModel model failed: {grpc_error.details()}")
                    self.grpc_error_handler(
                        servers[task_name],
                        grpc_error,
                        "submit_best_local_model",
                        start_time,
                        retry,
                        verbose=self.verbose,
                    )
                    excep = FLCommunicationException(grpc_error)
                    retry -= 1
                    time.sleep(5)
            if self.should_stop:
                raise excep

    def quit_remote(self, servers, task_name, token):
        """
        Sending the last message to the server before leaving.

        :param task_name: server task identifier
        :return: server's reply to the last message
        """
        server_message, retry = None, self.retry
        with self.set_up_channel(servers[task_name]) as channel:
            stub = fed_service.FederatedTrainingStub(channel)
            while retry > 0:
                try:
                    start_time = time.time()
                    self.logger.info(f"Quitting server: {task_name}")
                    server_message = stub.Quit(self.get_client_state(task_name, token))
                    # Clear the stopping flag
                    # if the connection to server recovered.
                    self.should_stop = False

                    end_time = time.time()
                    self.logger.info(
                        f"Received comment from server: {server_message.comment}. Quit time: {end_time - start_time} seconds"
                    )
                    break
                except grpc.RpcError as grpc_error:
                    self.grpc_error_handler(servers[task_name], grpc_error, "quit_remote", start_time, retry)
                    retry -= 1
                    time.sleep(3)
        return server_message

    def send_heartbeat(self, servers, task_name, token):
        message = fed_msg.Token()
        message.token = token

        with self.set_up_channel(servers[task_name]) as channel:
            while not self.heartbeat_done:
                stub = fed_service.FederatedTrainingStub(channel)
                # retry the heartbeat call for 10 minutes
                retry = 120
                while retry > 0:
                    try:
                        self.logger.debug(f"Send {task_name} heartbeat {token}")
                        stub.Heartbeat(message)
                        break
                    except grpc.RpcError as grpc_error:
                        self.logger.debug(grpc_error)
                        excep = FLCommunicationException(grpc_error)
                        retry -= 1
                        time.sleep(5)
                        # pass
                # if retry <= 0:
                #     raise excep

                time.sleep(60)

    def grpc_error_handler(self, service, grpc_error, action, start_time, retry, verbose=False):
        """
        Handling grpc exceptions
        :param action:
        :param start_time:
        :param service:
        """
        status_code = None
        if isinstance(grpc_error, grpc.Call):
            status_code = grpc_error.code()

        if grpc.StatusCode.RESOURCE_EXHAUSTED == status_code:
            if grpc_error.details().startswith("No token"):
                self.logger.info("No token for this client in current round. " "Waiting for server new round. ")
                self.should_stop = False
                return

        self.logger.info(
            f"Action: {action} grpc communication error. retry: {retry}, First start till now: {time.time() - start_time} seconds."
        )
        if grpc.StatusCode.UNAVAILABLE == status_code:
            self.logger.info(
                f"Could not connect to server: {service.get('target')}\t"
                f"Setting flag for stopping training. {grpc_error.details()}"
            )
            self.should_stop = True

        if grpc.StatusCode.OUT_OF_RANGE == status_code:
            self.logger.info(
                f"Server training has stopped.\t" f"Setting flag for stopping training. {grpc_error.details()}"
            )
            self.should_stop = True

        if verbose:
            self.logger.info(grpc_error)
