import logging
import traceback

from google.protobuf.struct_pb2 import Struct

import flare.private.fed.protos.federated_pb2 as fed_msg
from flare.apis.filter import Filter
from flare.apis.fl_constant import FLConstants, ShareableKey, ShareableValue
from flare.apis.fl_context import FLContext
from flare.private.fed.utils.fed_utils import shareable_to_modeldata
from flare.utils.fed_utils import FED_DELTA_W


class DataAssembler:
    def __init__(self) -> None:
        self.logger = logging.getLogger(self.__class__.__name__)

    def get_contribution_data(
        self, shareable, model_manager, task_name, client_state, outbound_filters: [Filter], fl_ctx: FLContext
    ):
        contrib = fed_msg.Contribution()
        # set client auth. data
        contrib.client.CopyFrom(client_state)
        # set model meta info.
        model_meta = model_manager.model_meta(task_name)
        contrib.client.meta.CopyFrom(model_meta)
        # set num. of local iterations
        contrib.n_iter = shareable.get(ShareableKey.META, {}).get(FLConstants.NUM_TOTAL_STEPS, 0)
        # set contribution type
        contrib.type = FED_DELTA_W
        # set model data
        local_model_dict = shareable.get(ShareableKey.MODEL_WEIGHTS)
        model_data = model_manager.read_current_model(task_name, local_model_dict, contrib.n_iter, contrib.type)

        # submit_shareable = Shareable()
        submit_shareable = shareable
        submit_shareable[ShareableKey.TYPE] = ShareableValue.TYPE_WEIGHT_DIFF
        # submit_shareable[ShareableKey.DATA_TYPE] = ShareableValue.DATA_TYPE_UNENCRYPTED
        submit_shareable[ShareableKey.MODEL_WEIGHTS] = model_data

        fl_ctx.set_model(model_data)
        # ctx_copy = fl_ctx.clone()
        if outbound_filters:
            for t in outbound_filters:
                submit_shareable = t.process(submit_shareable, fl_ctx)

        current_model = shareable_to_modeldata(submit_shareable)
        contrib.data.CopyFrom(current_model)

        s = Struct()
        # s.update({'n_iter': int(model_manager.num_local_iterations())})
        # best_metric = model_manager.get_fitter().get_train_context().get_train_stats().get('best_validation_metric', -10000)
        # s.update({'best_validation_metric': best_metric})

        # for k, v in metadata_generators.items():
        #     s.update({k: v.generate(model_manager.get_fitter().get_train_context())})

        for k, v in fl_ctx.get_all_public_props().items():
            s.update({k: v})

        contrib.meta_data.CopyFrom(s)

        return contrib
