"""Provides a command line interface for a federated client trainer"""

import argparse
import shutil
import os
import sys
import threading
import time
import traceback
from multiprocessing.connection import Listener

from dlmed.utils.argument_utils import parse_vars

from flare.apis.fl_constant import FLConstants
from flare.private.fed.app.fl_conf import FLClientStarterConfiger
from flare.private.fed.client.client_executor import update_client_properties
from flare.private.fed.client.client_status import ClientStatus, get_status_message
from flare.private.fed.crossvalidation.utils import get_model_registry_path


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--workspace", "-m", type=str, help="WORKSPACE folder", required=True)

    parser.add_argument(
        "--fed_client", "-s", type=str, help="an aggregation server specification json file", required=True
    )

    parser.add_argument("--set", metavar="KEY=VALUE", nargs="*")

    parser.add_argument("--local_rank", type=int, default=0)

    args = parser.parse_args()
    kv_list = parse_vars(args.set)

    args.mmar = args.workspace
    args.train_config = "config/config_train.json"
    config_folder = kv_list.get("config_folder", "")
    if config_folder == "":
        args.client_config = "config_fed_client.json"
    else:
        args.client_config = config_folder + "/config_fed_client.json"
    args.env = "config/environment.json"
    args.log_config = None

    try:
        remove_restart_file(args)
    except BaseException:
        print("Could not remove the restart.fl / shutdown.fl file.  Please check your system before starting FL.")
        sys.exit(-1)

    restart_file = os.path.join(args.mmar, "restart.fl")
    if os.path.exists(restart_file):
        os.remove(restart_file)

    print("starting the client .....")

    trainer = None

    try:
        token_file = os.path.join(args.mmar, "client_token.txt")
        with open(token_file, "r") as f:
            token = f.readline().strip()
            run_number = f.readline().strip()
            uid = f.readline().strip()
            listen_port = f.readline().strip()
            print("token is: {} run_number is: {} uid: {} listen_port: {}".format(token, run_number, uid, listen_port))

        workspace = "/tmp/fl/" + uid

        # trainer = WorkFlowFactory().create_client_trainer(train_configs, envs)
        conf = FLClientStarterConfiger(
            mmar_root=workspace,
            wf_config_file_name="config_train.json",
            client_config_file_name=args.fed_client,
            env_config_file_name="environment.json",
            log_config_file_name=workspace + "/log.config",
            kv_list=args.set,
        )
        conf.configure()

        trainer = conf.base_trainer
        federated_client = trainer.create_fed_client()
        federated_client.status = ClientStatus.TRAINING_STARTING

        # Start the thread for responding the inquire
        federated_client.stop_listen = False
        thread = threading.Thread(target=listen_command, args=[federated_client, int(listen_port)])
        thread.start()

        federated_client.token = token
        federated_client.uid = uid
        federated_client.fl_ctx.set_prop(FLConstants.CLIENT_NAME, uid, private=False)
        federated_client.fl_ctx.set_prop(FLConstants.FL_TOKEN, token, private=False)
        federated_client.fl_ctx.set_prop(FLConstants.WORKSPACE, args.workspace, private=False)

        mmar_root = os.path.join(args.mmar, "run_" + str(run_number), "mmar_" + uid)
        env_file = os.path.join(mmar_root, args.env)
        if os.path.exists(env_file):
            env_file = args.env
        else:
            env_file = workspace + "/environment.json"
        model_registry_file = get_model_registry_path(mmar_root)
        if os.path.exists(model_registry_file):
            os.remove(model_registry_file)

        conf = FLClientStarterConfiger(
            mmar_root=mmar_root,
            wf_config_file_name=workspace + "/config_train.json",
            client_config_file_name=args.client_config,
            env_config_file_name=env_file,
            log_config_file_name=args.log_config,
            kv_list=args.set,
            local_rank=args.local_rank,
        )
        conf.configure()

        trainer = conf.base_trainer

        update_client_properties(federated_client, trainer)
        federated_client.fl_ctx.set_prop(FLConstants.MODEL_DIR, trainer.model_log_dir)
        # # fl_trainer = create_fl_trainer(federated_client, trainer)
        federated_client.platform = conf.wf_config_data.get('platform', 'PT')
        # federated_client.status = ClientStatus.TRAINING_STARTED
        #
        # # federated_client.admin_run(fl_trainer)
        client_trainer = conf.client_trainer
        # client_trainer.set_model_manager(federated_client.model_manager)
        # federated_client.handlers.extend(list(conf.fl_components))

        client_trainer.federated_client = federated_client
        federated_client.admin_run(client_trainer, mmar_root, args)

    except BaseException as e:
        traceback.print_exc()
        print("FL client execution exception: " + str(e))
    finally:
        if federated_client:
            federated_client.stop_listen = True
            thread.join()
        if trainer:
            trainer.close()
        # address = ('localhost', 6000)
        # conn_client = Client(address, authkey='client process secret password'.encode())
        # conn_client.send('bye')


def listen_command(client, listen_port):
    try:
        address = ("localhost", listen_port)  # family is deduced to be 'AF_INET'
        listener = Listener(address, authkey="client process secret password".encode())
        conn = listener.accept()
        print(f'Created the listener on port: {listen_port}')

        try:
            while not client.stop_listen:
                if conn.poll(1.0):
                    msg = conn.recv()
                    if msg == "check_status":
                        conn.send(get_status_message(client.status))
                        continue
                    if msg == "abort":
                        client.abort_signal.trigger_time = time.time()
                        client.abort_signal.triggered = True
                        continue
                    if msg == "bye":
                        conn.close()
                        break
        except Exception as e:
            traceback.print_exc()
            print(f'Process communication exception: {listen_port}.')
        listener.close()
    except Exception as e:
        print(f'Could not create the listener for this process on port: {listen_port}.')
        pass


def remove_restart_file(args):
    restart_file = os.path.join(args.mmar, "restart.fl")
    if os.path.exists(restart_file):
        os.remove(restart_file)
    restart_file = os.path.join(args.mmar, "shutdown.fl")
    if os.path.exists(restart_file):
        os.remove(restart_file)


if __name__ == "__main__":

    main()
