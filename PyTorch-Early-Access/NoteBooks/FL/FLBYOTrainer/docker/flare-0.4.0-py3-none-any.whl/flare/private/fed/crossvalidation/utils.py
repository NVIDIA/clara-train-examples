from flare.utils.fed_utils import get_cookie
from flare.apis.shareable import Shareable
from flare.utils.ml_model_registry import MLModelRegistry
import os
from flare.apis.fl_constant import CrossValConstants


def get_cross_validation_folder_path(mmar_root):
    return os.path.join(mmar_root, 'cross_validation')


def get_model_registry_path(mmar_root):
    cross_val_folder = get_cross_validation_folder_path(mmar_root)
    if not os.path.exists(cross_val_folder):
        os.makedirs(cross_val_folder)

    return os.path.join(cross_val_folder, 'model_registry.pkl')


def get_client_model_key(client_id):
    return CrossValConstants.CLIENT_PREFIX + client_id


def get_client_name_from_model_key(model_key):
    if model_key.startswith(CrossValConstants.CLIENT_PREFIX):
        return model_key[len(CrossValConstants.CLIENT_PREFIX):]
    else:
        return model_key[:]


def get_server_model_keys(model_keys):
    return [key for key in model_keys if not key.startswith(CrossValConstants.CLIENT_PREFIX)]


def get_available_models(ml_model_registry: MLModelRegistry, cross_val_dict, model_keys, request_client_id):
    available_model_keys = []
    for model_key in model_keys:
        client_name = get_client_name_from_model_key(model_key)
        if cross_val_dict and request_client_id in cross_val_dict:
            if client_name in cross_val_dict[request_client_id]:
                # This model is already done so skip
                continue

        model_entry = ml_model_registry.find_model(model_key)
        if model_entry:
            available_model_keys.append(model_key)

    return available_model_keys


def get_model_owner(shareable: Shareable):
    if not get_cookie(shareable):
        return None

    return get_cookie(shareable).get(CrossValConstants.CROSS_VAL_MODEL_OWNER, None)
