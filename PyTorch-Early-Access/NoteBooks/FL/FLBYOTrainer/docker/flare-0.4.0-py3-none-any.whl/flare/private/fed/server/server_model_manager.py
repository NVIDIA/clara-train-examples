import logging
import traceback

from flare.apis.event_type import EventType
from flare.apis.fl_component import fire_event
from flare.apis.fl_context import FLContext


class ServerModelManager:
    """
    Global model manager lives on the server side.
    """

    def __init__(
        self,
        start_round=0,
        num_rounds=-1,
        exclude_vars=None,
        model_log_dir=None,
        ckpt_preload_path=None,
        model_aggregator=None,
        model_saver=None,
        shareable_generator=None,
    ):
        self.current_round = start_round
        self.num_rounds = num_rounds
        # self.exclude_vars = re.compile(exclude_vars) if exclude_vars else None

        self.logger = logging.getLogger(self.__class__.__name__)
        # self.model_log_dir = model_log_dir
        # self.ckpt_preload_path = ckpt_preload_path
        # self.session_restored = False

        self.model = None
        # self.session = self.get_session()

        # self._model_saver = tf.train.Saver(save_relative_paths=True)
        # self._ckpt_save_path = os.path.join(self.model_log_dir,
        #                                     'FL_global_model.ckpt')

        # self.make_init_proto()

        # self.model_saver = TFModelSaver(
        #     exclude_vars=self.exclude_vars,
        #     model_log_dir=model_log_dir,
        #     ckpt_preload_path=ckpt_preload_path)

        self.model_saver = model_saver

        self.model_aggregator = model_aggregator

        self.shareable_generator = shareable_generator

    @property
    def should_stop(self):
        """
        num_rounds < 0 means non-stopping
        """
        return (self.num_rounds > 0) and (self.current_round >= self.num_rounds)

    def run_validation(self):
        """
        Run validation
        """
        pass

    def accept(self, shareable, fl_ctx: FLContext):
        return self.model_aggregator.accept(shareable, fl_ctx)

    def update_model(self, handlers, fl_ctx: FLContext):
        """
        Aggregate tensorflow variables.
        This function is not thread-safe.
        :param fl_ctx:
        """
        try:
            # self.logger.info('aggregating %s updates at round %s',
            #                  len(accumulator), self.current_round)

            # fl_ctx.set_prop('global_model', self.get_global_model())
            fire_event(EventType.BEFORE_MODEL_UPDATE, handlers, fl_ctx)
            aggregate_shareable = self.model_aggregator.aggregate(fl_ctx)
            fire_event(EventType.AFTER_MODEL_UPDATE, handlers, fl_ctx)
            # self.model = self._to_modeldata(global_model)
            self.model = self.shareable_generator.shareable_to_learnable(aggregate_shareable, fl_ctx)

            if self.model:
                # Always save the latest checkpoint
                # if self.should_stop:
                fire_event(EventType.BEFORE_SAVE_MODEL, handlers, fl_ctx)
                self.model_saver.save_model(self.get_global_model(), fl_ctx)
                fire_event(EventType.AFTER_SAVE_MODEL, handlers, fl_ctx)
            else:
                self.logger.error('Shareable generator generated an empty model.')
        except Exception as e:
            traceback.print_exc()
            self.logger.error('There has been an error happened in the model aggregation.')
        finally:
            # increase the round number at the end, to avoid the thread racing condition issue.
            self.current_round += 1

    def initialize(self, fl_context):
        # build_ctx = builder.build()
        # # assert isinstance(build_ctx, BuildContext)
        # # with builder.graph.as_default():
        # with build_ctx.get('_graph').as_default():
        #     # only use the first server
        #     if self.model_saver:
        #         self.model_saver.initialize()
        #
        print("Create initial model message...")
        # self.model_saver.initialize(fl_context)
        self.model = self.model_saver.load_model(fl_context)
        print("created initial model_data...")

    def get_shareable(self, fl_ctx):
        return self.shareable_generator.learnable_to_shareable(self.model, fl_ctx)

    def get_global_model(self):
        # model = Model()
        # model.update({k: proto_to_ndarray(v) for k, v in self.model.params.items()})
        # return model
        return self.model

    def close(self):
        """
        TODO final saving before quitting
        """
        # if self.model_saver:
        #     self.model_saver.close()

        self.logger.info("closing the model manager")
