from flare.private.fed.crossvalidation.utils import get_model_owner
import os
import logging
import shutil

from flare.private.fed.crossvalidation.ml_model_shareable_generator import MLModelShareableGenerator
from flare.utils.ml_model_registry import MLModelRegistry
from flare.apis.fl_context import FLContext
from flare.apis.shareable import Shareable
from flare.apis.fl_constant import FLConstants, ShareableKey, ShareableValue
from flare.apis.fl_constant import CrossValConstants
from flare.apis.fl_constant import MLModelKeys
from flare.apis.validator import Validator
from flare.utils.fed_utils import generate_failure, generate_empty_shareable


class ClientCrossSiteValManager(object):

    def __init__(self,
                 validator: Validator,
                 inbound_filters=None,
                 outbound_filters=None,
                 ml_model_registry_path=None,
                 local_model_key=None,
                 is_participating=True,
                 timeout=None) -> None:
        """Cross site validation manager for clients.

        Args:
            validator (Validator): Validates models provided by server.
            inbound_filters (List[Filter], optional): List of inbound filters. Defaults to None.
            outbound_filters (List[Filter], optional): List of outbound filters.. Defaults to None.
            ml_model_registry_path (str, optional): Path to saved model registry. Defaults to None.
            local_model_key (str, optional): Key to pick local model from registry. Defaults to None.
            is_participating (bool, optional): Whether or not to participate in cross validation. Defaults to True.
        """
        self.ml_model_registry_path = ml_model_registry_path
        self.model_validator = validator
        self.is_participating = is_participating
        self.local_model_key = local_model_key
        self.inbound_filters = inbound_filters
        self.outbound_filters = outbound_filters
        self.timeout = timeout
        if not timeout or not isinstance(timeout, int):
            self.timeout = 10

        self.ml_model_registry = None
        self.ml_model_shareable_gen = MLModelShareableGenerator()
        if not self.local_model_key:
            self.local_model_key = MLModelKeys.LOCAL_BEST_MODEL

        self.logger = logging.getLogger("CrossSiteValManager")
        self.logger.info(f"Cross validation timeout is set to {self.timeout} minutes.")

    def _load_model_registry(self):
        self.ml_model_registry = MLModelRegistry()
        if not self.ml_model_registry_path:
            self.logger.info("No model registry path found. Using empty registry.")
        if not os.path.isfile(self.ml_model_registry_path):
            self.logger.info(f"File to load model registry doesn't exist at {self.ml_model_registry_path}."
                             "Using empty registry.")
            return

        try:
            self.ml_model_registry = MLModelRegistry.from_bytes(open(self.ml_model_registry_path, 'rb').read())
        except Exception as e:
            self.logger.info(f"Unable to load MLModelRegistry at {self.ml_model_registry_path}. Exception {e}")
            self.logger.info("Empty registry will be used.")

    def initialize(self, fl_ctx) -> bool:
        """Initialize Cross site validation manager and return true if succeeded.

        Args:
            fl_ctx (FLContext): FL Context.

        Returns:
            bool: True if success. Else false.
        """
        self._load_model_registry()
        fl_ctx.remove_prop(CrossValConstants.PARTICIPATING_IN_CROSS_VAL)
        fl_ctx.set_prop(CrossValConstants.ML_MODEL_REGISTRY, self.ml_model_registry, sticky=True, private=True)
        fl_ctx.set_prop(CrossValConstants.PARTICIPATING_IN_CROSS_VAL, self.is_participating, sticky=True, private=False)

        if not self.is_participating:
            self.logger.info("Not participating in cross site validation. Empty model will be submitted.")
        if not self.model_validator:
            self.logger.info("No model_validator found. Please check client config. Cross site validation exiting.")
            return False
        return True

    def get_local_model_shareable(self, fl_ctx) -> Shareable:
        fl_ctx.remove_prop(FLConstants.FAILURE)
        if not self.ml_model_registry:
            self.logger.info("MLModelRegistry not found. Can't load local model.")
            return generate_empty_shareable(cookie=None)

        if self.is_participating:
            try:
                model_entry = self.ml_model_registry.find_model(self.local_model_key)
                model_shareable = self.ml_model_shareable_gen.ml_model_entry_to_shareable(model_entry)
            except Exception as e:
                self.logger.info(f"Exception in loading model: {e}")
                model_shareable = generate_failure(fl_ctx, reason=f"Local Model failed: {e}", cookie=None)
        else:
            model_shareable = generate_empty_shareable(cookie=None)

        # Apply outbound filters
        self.apply_filters(self.outbound_filters, model_shareable, fl_ctx)

        return model_shareable

    def validate_model(self, shareable, fl_ctx: FLContext, abort_signal):
        # Apply inbound filters
        self.apply_filters(self.inbound_filters, shareable, fl_ctx)

        model_owner = get_model_owner(shareable)

        # Create model_dir to save model.
        mmar_root = fl_ctx.get_prop(FLConstants.MMAR_ROOT, default=None)
        cross_site_val_dir = os.path.join(mmar_root, CrossValConstants.CROSS_VAL_SCRATCH_DIR)
        model_folder = os.path.join(cross_site_val_dir, model_owner)
        if not os.path.exists(model_folder):
            os.makedirs(model_folder, exist_ok=True)

        try:
            self.data_to_file_shareable(shareable, model_folder)
            metric_shareable = self.model_validator.validate(shareable, fl_ctx, abort_signal=abort_signal)
        except Exception as e:
            failure_reason = f"Exception in validating {model_owner}'s model: {e}"

            # Create empty shareable
            self.logger.info(failure_reason)
            metric_shareable = generate_failure(fl_ctx, reason=failure_reason, cookie=None)

        # Apply outbound filters
        self.apply_filters(self.outbound_filters, metric_shareable, fl_ctx)

        # Cleanup. Remove model_dir
        shutil.rmtree(model_folder)

        return metric_shareable

    def data_to_file_shareable(self, shareable, model_folder):
        """Serialize model to model_folder and create shareable. This function modifies shareable similar to
        Filter.

        Args:
            shareable (Shareable]): Model shareable
            model_folder (str): Path to model folder.
        """
        if not shareable[ShareableKey.TYPE] == ShareableValue.TYPE_ML_MODEL:
            self.logger.debug("Shareable must be of type TYPE_ML_MODEL.")
            return

        # Create file based shareable
        model_name = shareable[ShareableKey.MODEL_NAME]
        files = {}
        for data_key, data in shareable[ShareableKey.DATA].items():
            path = os.path.join(model_folder, model_name + '.' + data_key)
            open(path, 'wb').write(data)
            files[data_key] = path
        shareable[ShareableKey.DATA] = files
        shareable[ShareableKey.DATA_TYPE] = ShareableValue.DATA_TYPE_FILES

    def apply_filters(self, filters, shareable, fl_ctx):
        if filters:
            for t in filters:
                shareable = t.process(shareable, fl_ctx)
