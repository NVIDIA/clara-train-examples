import grpc

from flare.apis.fl_context import FLContext
from flare.private.fed.client.client_cross_site_val_manager import ClientCrossSiteValManager
from flare.private.fed.client.fed_client import FederatedClient

from .client_req_processors import ClientRequestProcessors


class BaseClientTrainer:
    def __init__(self):
        self.multi_gpu = False
        self.outbound_filters = None
        self.inbound_filters = None
        self.federated_client = None
        self.model_validator = None
        self.cross_val_participating = False
        self.model_registry_path = None
        self.cross_val_timeout = None

        self.req_processors = ClientRequestProcessors.request_processors

    def build(self, build_ctx):
        self.server_config = build_ctx["server_config"]
        self.client_config = build_ctx["client_config"]
        self.model_reader_writer = build_ctx["model_reader_writer"]
        self.secure_train = build_ctx["secure_train"]
        # self.aggregation_epochs = build_ctx["aggregation_epochs"]
        # self.aggregation_steps = build_ctx["aggregation_steps"]
        self.privacy = build_ctx["privacy"]
        # self.req_processors = build_ctx["req_processors"]
        self.uid = build_ctx["uid"]
        self.trainer = build_ctx["supervised_trainer"]
        self.evaluator = build_ctx["supervised_evaluator"]
        self.model_log_dir = build_ctx["model_log_dir"]
        self.multi_gpu = build_ctx["is_multi_gpu"]
        self.outbound_filters = build_ctx["outbound_filters"]
        self.inbound_filters = build_ctx["inbound_filters"]
        self.handlers = build_ctx["handlers"]
        self.cross_val_participating = build_ctx['cross_val_participating']
        self.model_validator = build_ctx['model_validator']
        self.model_registry_path = build_ctx['model_registry_path']
        self.cross_val_inbound_filters = build_ctx['cross_val_inbound_filters']
        self.cross_val_outbound_filters = build_ctx['cross_val_outbound_filters']
        self.cross_val_timeout = build_ctx['cross_val_timeout']

    # def non_fl_train(self):
    #     fitter = self.create_fitter()
    #
    #     self.federated_client = self.create_fed_client()
    #     self.federated_client.start_heartbeat()
    #     return self.federated_client.run(fitter)
    #
    def set_model_manager(self, model_manager):
        self.model_manager = model_manager

    def create_fed_client(self):
        servers = [{t["name"]: t["service"]} for t in self.server_config]
        retry_timeout = 30
        if "retry_timeout" in self.client_config:
            retry_timeout = self.client_config["retry_timeout"]

        compression = grpc.Compression.NoCompression
        if "Deflate" == self.client_config.get("compression"):
            compression = grpc.Compression.Deflate
        elif "Gzip" == self.client_config.get("compression"):
            compression = grpc.Compression.Gzip

        self.federated_client = FederatedClient(
            client_id=str(self.uid),
            # We only deploy the first server right now .....
            server_args=sorted(servers)[0],
            client_args=self.client_config,
            exclude_vars=self.client_config.get("exclude_vars", "dummy"),
            privacy=self.privacy,
            secure_train=self.secure_train,
            # data_assembler=self.data_assembler,
            retry_timeout=retry_timeout,
            model_reader_writer=self.model_reader_writer,
            outbound_filters=self.outbound_filters,
            inbound_filters=self.inbound_filters,
            req_processors=self.req_processors,
            handlers=self.handlers,
            compression=compression,
        )
        return self.federated_client

    def create_cross_site_val_manager(self):
        cross_site_val_manager = ClientCrossSiteValManager(
            validator=self.model_validator,
            is_participating=self.cross_val_participating,
            ml_model_registry_path=self.model_registry_path,
            inbound_filters=self.cross_val_inbound_filters,
            outbound_filters=self.cross_val_outbound_filters,
            timeout=self.cross_val_timeout
        )
        return cross_site_val_manager

    def finalize(self, fl_ctx: FLContext):
        self.close()

    def close(self):
        if self.federated_client:
            self.federated_client.model_manager.close()
