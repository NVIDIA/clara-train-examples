import gc
import json
import logging
import os
import re
import shutil
import sys
import traceback
from concurrent.futures import ThreadPoolExecutor
from threading import Lock
from typing import Any, Tuple

from dlmed.hci.zip_utils import zip_directory_to_bytes

from flare.private.fed.app.fl_conf import FLServerStarterConfiger
from flare.utils.fl_exception import FLAdminException
from flare.apis.fl_constant import FLConstants

from .server_status import ServerStatus, get_status_message


class ServerAdminInterface(object):
    def __init__(self, server, args, workers=3):
        self.server = server
        self.args = args
        self.run_number = -1

        assert workers >= 1, "workers must >= 1"
        self.executor = ThreadPoolExecutor(max_workers=workers)
        self.lock = Lock()
        self.logger = logging.getLogger(self.__class__.__name__)

    def _get_server_mmar_folder(self):
        return "mmar_server"

    def _get_client_mmar_folder(self, client_name):
        return "mmar_" + client_name

    def _get_run_folder(self):
        return os.path.join(self.args.mmar, "run_" + str(self.run_number))

    def set_run_number(self, num):
        status = self.server.status
        if status == ServerStatus.TRAINING_STARTING or status == ServerStatus.TRAINING_STARTED:
            return "run_number can not be changed during the FL training."

        run_folder = os.path.join(self.args.mmar, "run_" + str(num))
        if os.path.exists(run_folder):
            self.run_number = num
            return "run number already exist. Set the FL run number to {}.".format(num)
        else:
            self.run_number = num
            os.makedirs(run_folder)
            return "Create a new run folder: run_{}".format(num)

    def delete_run_number(self, num):
        run_number_folder = os.path.join(self.args.mmar, "run_" + str(num))
        if os.path.exists(run_number_folder):
            shutil.rmtree(run_number_folder)
        return "FL server: Delete run folder: {}".format(run_number_folder)

    def get_run_number(self):
        return self.run_number

    def start_server_training(self) -> str:
        if self.run_number == -1:
            return "Please set a FL run number."

        status = self.server.status
        if status == ServerStatus.TRAINING_STARTING or status == ServerStatus.TRAINING_STARTED:
            return "Server already in training."
        else:
            mmar_root = os.path.join(self._get_run_folder(), self._get_server_mmar_folder())
            if not os.path.exists(mmar_root):
                return "Server mmar does not exist. Please deploy the server MMAR before start."

            mmar_custom_folder = os.path.join(mmar_root, "custom")
            try:
                sys.path.index(mmar_custom_folder)
            except ValueError:
                self.remove_custom_path()
                sys.path.append(mmar_custom_folder)

            self.initialize_cross_val()

            # future = self.executor.submit(start_server_training, (self.server))
            future = self.executor.submit(
                lambda p: start_server_training(*p), [self.server, self.args, mmar_root, self.run_number]
            )
            return "Server training is starting...."

    def remove_custom_path(self):
        regex = re.compile(".*/run_.*/custom")
        custom_paths = list(filter(regex.search, sys.path))
        for path in custom_paths:
            sys.path.remove(path)

    def stop_server_training(self) -> str:
        status = self.server.status
        if status == ServerStatus.TRAINING_NOT_STARTED:
            return "Server training has not started."

        if status == ServerStatus.TRAINING_STARTING:
            return "Server training is starting, please wait for started before abort."

        self.logger.info("Server training stopped.")
        # self.server.stop_training()
        self.server.shutdown = True
        return "FL training has been stopped."

    def check_status(self) -> Tuple[str, Any, Any]:
        self.logger.debug("Check server status.")
        self.server.remove_dead_clients()
        status = self.server.status
        if self.run_number != -1:
            message = "FL run number:{}".format(self.run_number)
        else:
            message = "FL run number has not been set."
        message += "\nFL server status: {}".format(get_status_message(status))
        if status == ServerStatus.TRAINING_STARTING or status == ServerStatus.TRAINING_STARTED:
            message += "\nrun number:{}\tstart round:{}\tmax round:{}\tcurrent round:{}".format(
                self.run_number, self.server.start_round, self.server.num_rounds, self.server.current_round
            )
            message += "\nmin_num_clients:{}\tmax_num_clients:{}".format(
                self.server.min_num_clients, self.server.max_num_clients
            )
        # message += "\nRegistered clients: {}\n ".format(len(self.server.client_manager.clients))
        # for k, v in self.server.client_manager.clients.items():
        #     message += 'client name:{}\tinstance name:{}\ttoken: {} \n'.format(v.client_id, v.instance_name, k)

        return message, status, self.server.client_manager.clients

    def fl_shutdown(self) -> str:
        status = self.server.status
        if status == ServerStatus.TRAINING_STARTING:
            return "Server training is starting, please wait for started before shutdown."

        self.logger.info("FL server shutdown.")
        # self.server.fl_shutdown()
        # future = self.executor.submit(server_shutdown, (self.server))

        touch_file = os.path.join(self.args.mmar, "shutdown.fl")
        future = self.executor.submit(lambda p: server_shutdown(*p), [self.server, touch_file])
        return "FL training has been shutdown."

    def fl_restart(self) -> str:
        status = self.server.status
        if status == ServerStatus.TRAINING_STARTING:
            return "Server training is starting, please wait for started before restart."

        self.logger.info("FL server restart.")

        touch_file = os.path.join(self.args.mmar, "restart.fl")
        future = self.executor.submit(lambda p: server_shutdown(*p), [self.server, touch_file])
        return "FL training has been shutdown."

    def get_all_clients(self):
        return list(self.server.client_manager.clients.keys())

    def get_all_instance_names(self):
        instance_names = set()
        for token, client in self.server.client_manager.clients.items():
            instance_names.add(client.instance_name)
        return list(instance_names)

    def get_all_client_names(self):
        client_names = set()
        for token, client in self.server.client_manager.clients.items():
            client_names.add(client.client_id)
        return list(client_names)

    def get_client_name_from_instance_name(self, instance_name):
        for token, client in self.server.client_manager.clients.items():
            if instance_name == client.instance_name:
                return client.client_id
        return None

    def get_all_register_tokens(self, client_name):
        tokens = []
        for token, client in self.server.client_manager.clients.items():
            if client_name == client.instance_name:
                tokens.append(token)
            elif client_name.endswith("*") and client_name[:-1] in client.instance_name:
                tokens.append(token)
        return tokens

    def get_instance_name_from_token(self, token):
        client = self.server.client_manager.clients.get(token, None)
        if client:
            return client.instance_name
        else:
            return ""

    def get_all_tokens_from_inputs(self, inputs):
        tokens = []
        invalid_inputs = []
        for item in inputs:
            if item in self.get_all_clients():
                tokens.append(item)
            else:
                register_tokens = self.get_all_register_tokens(item)
                if register_tokens:
                    tokens.extend(register_tokens)
                else:
                    invalid_inputs.append(item)
        return tokens, invalid_inputs

    def get_all_client_names_from_inputs(self, inputs):
        names = []
        invalid_inputs = []
        for item in inputs:
            if item in self.get_all_client_names():
                names.append(item)
            else:
                invalid_inputs.append(item)
        return names, invalid_inputs

    def get_all_taskname(self) -> str:
        return self.server.task_name

    def get_client_mmar(self, client_name):
        if self.run_number == -1:
            raise FLAdminException("Please set a FL run number.")

        # folder = self._get_run_folder()
        # data = zip_directory_to_bytes(folder, self._get_client_mmar_folder(client_name))
        folder = self.args.mmar
        data = zip_directory_to_bytes(
            folder, os.path.join("run_" + str(self.run_number), self._get_client_mmar_folder(client_name))
        )
        return data

    def initialize_cross_val(self):
        cross_val_scratch_dir = self.get_cross_val_directory()
        if not os.path.exists(cross_val_scratch_dir):
            os.makedirs(cross_val_scratch_dir, exist_ok=True)
        else:
            # Delete any old cross validation files.
            shutil.rmtree(cross_val_scratch_dir)

    def get_cross_val_directory(self) -> str:
        return os.path.join(self._get_run_folder(), "cross_validation")

    def get_cross_val_filename(self) -> str:
        return os.path.join(self.get_cross_val_directory(), "cross_val_results.json")

    def load_cross_val_dict(self):
        cross_val_filename = self.get_cross_val_filename()
        if not os.path.exists(cross_val_filename):
            return None

        data = None
        with self.lock:
            try:
                with open(cross_val_filename, "r") as f:
                    data = json.load(f)
            except Exception:
                traceback.print_exc()
        return data

    def write_cross_val_results(self, cross_val_dict):
        # Dump dictionary to file
        with self.lock:
            try:
                with open(self.get_cross_val_filename(), "w") as f:
                    json.dump(cross_val_dict, f)
            except Exception:
                traceback.print_exc()

    def update_cross_val_dict(self, data_client, val_client_names, val_client_metrics):
        """Updates cross site validation results

        Args:
            data_client (str): Name of the client who sent results
            val_client_names (str): List of clients validated
            val_client_metrics (str): Metric dicts for each client

        Returns:
            dict: Updated dictionary
        """

        # Load the dictionary
        cross_val_dict = self.load_cross_val_dict()
        if cross_val_dict is None:
            cross_val_dict = {}
        self.logger.debug(f"Starting with cross val dictionary: {cross_val_dict}")

        # Add new results to dictionary
        if data_client in cross_val_dict:
            for name, metrics in zip(val_client_names, val_client_metrics):
                cross_val_dict[data_client][name] = metrics
        else:
            cross_val_dict[data_client] = dict(zip(val_client_names, val_client_metrics))
        self.logger.debug(f"Updated cross_val results:\n \t{cross_val_dict}")

        self.write_cross_val_results(cross_val_dict)

        return cross_val_dict

    def get_cross_val_results(self, model_client, data_client) -> dict:
        data = self.load_cross_val_dict()
        if not data:
            return ""

        if model_client is None or data_client is None:
            return str(data)

        if data_client in data:
            if model_client in data[data_client]:
                return str(data[data_client][model_client])
        return ""

    def get_mmar_path(self, src):
        return os.path.join(self.server.admin_server.file_upload_dir, src)

    def deploy_mmar(self, src, dest):
        if self.run_number == -1:
            return "Please set a FL run number."

        fullpath_src = os.path.join(self.server.admin_server.file_upload_dir, src)
        fullpath_dest = os.path.join(self._get_run_folder(), dest)
        if not os.path.exists(fullpath_src):
            return f"MMAR folder '{src}' does not exist."
        if os.path.exists(fullpath_dest):
            shutil.rmtree(fullpath_dest)
        shutil.copytree(fullpath_src, fullpath_dest)
        return "{} has been deployed.".format(dest)

    def reset_model_for_client(self, client):
        self.server.tokens[client] = self.server.model_meta_info

    def remove_dead_client(self, token):
        client = self.server.client_manager.remove_client(token)
        # self.tokens.pop(token, None)
        self.server.remove_client_data(token)
        if self.server.admin_server:
            self.server.admin_server.client_dead(client.client_id)

    def set_min_clients(self, num):
        self.server.min_num_clients = num

    def check_aggregation(self):
        # clients = []
        # for item in self.server.contributed_clients:
        #     clients.append(item)
        #
        # return clients
        return self.server.contributed_clients, self.server.current_round

    def close(self):
        self.executor.shutdown()


def start_server_training(server, args, mmar_root, run_number):
    # if server.platform == 'PT':
    #     from medl.apps.fed_learn.fl_conf import FLServerConfiger
    # else:
    #     from nvmidl.apps.fed_learn.fl_conf import FLServerConfiger

    restart_file = os.path.join(args.mmar, "restart.fl")
    if os.path.exists(restart_file):
        os.remove(restart_file)

    trainer = None
    try:
        conf = FLServerStarterConfiger(
            mmar_root=mmar_root,
            wf_config_file_name="/tmp/fl_server/config_train.json",
            server_config_file_name=args.server_config,
            env_config_file_name="/tmp/fl_server/environment.json",
            log_config_file_name="/tmp/fl_server/log.config",
            kv_list=args.set,
            logging_config=False,
        )
        conf.configure()

        trainer = conf.trainer

        first_server, services = trainer.create_fl_server()
        trainer.create_builder(services)

        # services = trainer.deploy(services)
        #
        # # Keep to use the same admin_server
        # server.admin_server.server = services
        # server.admin_server.sai.server = services
        # services.set_admin_server(server.admin_server)
        # # Keep the existing registered clients and tokens
        # services.client_manager.clients = server.client_manager.clients
        # services.tokens = server.tokens
        # server = services

        copy_new_server_properties(server, services)

        # server.handlers.extend(list(conf.fl_components))

        server.fl_ctx.set_prop(FLConstants.TRAIN_ROOT, mmar_root)
        server.fl_ctx.set_prop(FLConstants.CURRENT_RUN, run_number, private=False)
        server.fl_ctx.set_prop(FLConstants.WORKSPACE, args.workspace, private=False)
        server.fl_ctx.set_prop(FLConstants.ARGS, args, private=True)
        if conf.env_config is not None:
            if conf.env_config.get("MMAR_CKPT_DIR", None):
                server.fl_ctx.set_prop(FLConstants.LOG_DIR, conf.env_config["MMAR_CKPT_DIR"], private=True)
            if conf.env_config.get("MMAR_CKPT") is not None:
                server.fl_ctx.set_prop(FLConstants.CKPT_PRELOAD_PATH, conf.env_config["MMAR_CKPT"], private=True)

        server.start()
    except BaseException as e:
        traceback.print_exc()
        logging.getLogger().warning("FL server execution exception: " + str(e))
    finally:
        server.status = ServerStatus.TRAINING_STOPPED
        server.stop_training()
        if trainer:
            trainer.close()

        # Force garbage collection
        gc.collect()

    # return server.start()


def server_shutdown(server, touch_file):
    with open(touch_file, "a"):
        os.utime(touch_file, None)

    try:
        server.fl_shutdown()
        server.admin_server.stop()
    finally:
        sys.exit(2)


def copy_new_server_properties(server, new_server):
    server.model_manager = new_server.model_manager
    # server.model_saver = new_server.model_saver
    server.builder = new_server.builder

    server.wait_after_min_clients = new_server.wait_after_min_clients

    server.outbound_filters = new_server.outbound_filters
    server.inbound_filters = new_server.inbound_filters
    server.cmd_modules = new_server.cmd_modules
    server.processors = new_server.processors

    # server.task_name = new_server.task_name
    server.min_num_clients = new_server.min_num_clients
    server.max_num_clients = new_server.max_num_clients
    server.current_round = new_server.current_round
    server.num_rounds = new_server.num_rounds
    server.start_round = new_server.start_round

    # server.heart_beat_timeout = new_server.heart_beat_timeout
    server.handlers = new_server.handlers

    # clients = server.client_manager.clients
    # server.client_manager = new_server.client_manager
    # server.client_manager.clients = clients
    server.client_manager.min_num_clients = new_server.client_manager.min_num_clients
    server.client_manager.max_num_clients = new_server.client_manager.max_num_clients
    server.client_manager.logger = new_server.client_manager.logger
    server.client_manager.logger.disabled = False

    server.reset_tokens()
    server.contributed_clients.clear()
    # server.accumulator.clear()

    server.fl_ctx = new_server.fl_ctx
