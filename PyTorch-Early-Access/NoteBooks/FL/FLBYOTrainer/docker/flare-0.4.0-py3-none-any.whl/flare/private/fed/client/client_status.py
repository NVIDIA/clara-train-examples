class ClientStatus(object):
    TRAINING_NOT_STARTED = 0
    TRAINING_STARTING = 1
    TRAINING_STARTED = 2
    TRAINING_STOPPED = 3
    TRAINING_EXCEPTION = 4
    CROSS_SITE_VALIDATION = 10
    # TRAINING_COMPLETED = 11
    ABORTED_BY_COMMAND = 20

    status_messages = {
        TRAINING_NOT_STARTED: "training not started",
        TRAINING_STARTING: "training starting",
        TRAINING_STARTED: "training started",
        TRAINING_STOPPED: "training stopped",
        TRAINING_EXCEPTION: "training exception",
        CROSS_SITE_VALIDATION: "cross site validation",
        # TRAINING_COMPLETED: "completed",
        ABORTED_BY_COMMAND: "progress aboorted by command",
    }


def get_status_message(status):
    return ClientStatus.status_messages.get(status)
