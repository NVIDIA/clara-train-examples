import subprocess

from flare.utils.admin_defs import Message

from .admin import RequestProcessor


class ShellCommandProcessor(RequestProcessor):
    def get_topics(self) -> [str]:
        return ["shell"]

    def process(self, req: Message, app_ctx) -> Message:
        shell_cmd = req.body
        output = subprocess.getoutput(shell_cmd)
        message = Message(topic="reply_" + req.topic, body=output)
        return message
