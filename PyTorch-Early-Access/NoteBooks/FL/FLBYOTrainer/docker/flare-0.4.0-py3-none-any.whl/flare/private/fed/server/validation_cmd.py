from dlmed.hci.conn import Connection
from dlmed.hci.reg import CommandModule, CommandModuleSpec, CommandSpec


class ValidationCommandModule(CommandModule):
    def __init__(self, allowed_commands=None):
        self.allowed_commands = allowed_commands

    def get_spec(self):
        return CommandModuleSpec(
            name="validation",
            cmd_specs=[
                CommandSpec(
                    name="taskname",
                    description="get the FL taskname",
                    usage="taskname",
                    handler_func=self.get_taskname,
                    visible=True,
                ),
                CommandSpec(
                    name="validate",
                    description="cross sites validation",
                    usage="validate source_site target_site1 target_site2 ...",
                    handler_func=self.do_validation_command,
                    visible=True,
                ),
            ],
        )

    def do_validation_command(self, conn: Connection, args: [str]):
        if len(args) < 2:
            conn.append_error("Usage: validate <all> or validate <client1> <client2>")
            return
        if len(args) == 2:
            if args[1] != "all":
                conn.append_error("Usage: validate <all>")
                return

        client_name = args[1]
        if self.allowed_commands:
            if client_name not in self.allowed_commands:
                conn.append_error("not allowed")
                return

        sai = conn.app_ctx
        response = ""

        if client_name == "all":
            response += sai.get_cross_val_results(model_client=None, data_client=None)
        else:
            targets = args[2:]

            for target in targets:
                response += f"Validate {client_name}'s model on {target}'s data:\n"
                response += sai.get_cross_val_results(model_client=client_name, data_client=target)
                response += "\n"

        conn.append_string(response)

    def get_taskname(self, conn: Connection, args: [str]):
        sai = conn.app_ctx
        output = sai.get_all_taskname()
        conn.append_string(output)

    # def do_client_status(self, conn: Connection, args: [str]):
    #     if len(args) < 2:
    #         conn.append_error("syntax error: missing site names")
    #         return
    #
    #     clients = ' '.join(args[1:])
    #     message = Message(topic=args[0], body="")
    #
    #     requests = {}
    #     for client in (args[1:]):
    #         requests = {client: message}
    #     server = conn.server
    #     replies = server.send_requests(requests, timeout_secs=15)
    #
    #     response = 'No replies'
    #     if replies:
    #         response = ''
    #         for r in replies:
    #             if r.reply:
    #                 response += r.request.topic + ' : reply --> ' + r.reply.topic + ' : ' + r.reply.body + '\n'
    #             else:
    #                 response += r.request.topic
    #
    #     conn.append_string(response)
