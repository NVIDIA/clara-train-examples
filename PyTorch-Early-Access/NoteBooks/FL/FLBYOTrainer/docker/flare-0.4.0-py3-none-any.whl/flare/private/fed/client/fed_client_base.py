"""The client of the federated training process"""

from flare.private.fed.crossvalidation.utils import get_model_owner
from flare.apis.shareable import Shareable
import logging
import threading
import time
from multiprocessing.dummy import Pool as ThreadPool

from flare.apis.event_type import EventType
from flare.apis.filter import Filter
from flare.apis.fl_component import FLComponent, fire_event
from flare.apis.fl_constant import FLConstants

from flare.apis import FLContext, ModelProcessor
from flare.private.fed.client.client_model_manager import ClientModelManager
from flare.utils.ml_model_registry import MLModelRegistry
from flare.utils.fed_utils import VERBOSE, generate_empty_shareable, get_cookie, set_cookie
from flare.common.signal import Signal
from flare.utils.fl_exception import FLCommunicationException

from flare.apis.fl_constant import CrossValConstants
from .client_status import ClientStatus
from .communicator import Communicator


class FederatedClientBase:
    """
    Federated client-side base implementation.
    This class provide the tools function which will be used in both FedClient and FedClientLite.
    """

    def __init__(
        self,
        client_id,
        client_args,
        secure_train,
        # data_assembler,
        server_args=None,
        exclude_vars=None,
        privacy=None,
        retry_timeout=30,
        model_reader_writer: ModelProcessor = None,
        outbound_filters: [Filter] = None,
        inbound_filters: [Filter] = None,
        client_state_processors: [Filter] = None,
        req_processors=None,
        handlers: [FLComponent] = None,
        compression=None,
    ):
        self.logger = logging.getLogger(self.__class__.__name__)
        self.verbose = VERBOSE

        self.uid = client_id
        self.token = None
        self.client_args = client_args
        self.servers = server_args
        self.model_manager = ClientModelManager(
            task_names=tuple(self.servers),
            exclude_vars=exclude_vars,
            privacy=privacy,
            model_reader_writer=model_reader_writer,
        )

        # self.pool = ThreadPool(len(self.servers))
        self.train_end = False

        self.communicator = Communicator(
            model_manager=self.model_manager,
            ssl_args=client_args,
            secure_train=secure_train,
            retry_timeout=retry_timeout,
            # data_assembler=data_assembler,
            outbound_filters=outbound_filters,
            inbound_filters=inbound_filters,
            client_state_processors=client_state_processors,
            compression=compression,
        )
        self.ml_model_registry = MLModelRegistry()
        self.cross_site_val_manager = None

        self.secure_train = secure_train
        self.handlers = handlers

        self.heartbeat_done = False
        self.fl_ctx = FLContext()
        self.fl_ctx.set_prop(CrossValConstants.ML_MODEL_REGISTRY, self.ml_model_registry)
        self.platform = None
        self.abort_signal = Signal()

        self.status = ClientStatus.TRAINING_NOT_STARTED

        # if self.handlers:
        #     for h in self.handlers:
        #         h.startup(self.fl_ctx)

        # self.create_admin_agent(client_args, client_id, req_processors, secure_train, server_args)

    # def create_admin_agent(self, client_args, client_id, req_processors, secure_train, server_args):
    #     sender = AdminMessageSender(client_name=client_id, root_cert=client_args['ssl_root_cert'],
    #                                 ssl_cert=client_args['ssl_cert'], private_key=client_args['ssl_private_key'],
    #                                 server_args=server_args,
    #                                 secure=secure_train)
    #     self.admin_agent = FedAdminAgent(client_name='admin_agent',
    #                                      sender=sender,
    #                                      app_ctx=ClientAdminInterface(self, client_id, sender))
    #     for processor in req_processors:
    #         self.admin_agent.register_processor(processor)
    #     self.admin_agent.start()

    @property
    def app_context(self):
        # return self.model_manager.get_fitter().get_train_context()
        return self.fl_ctx.get_prop(FLConstants.TRAIN_CONTEXT)

    def client_register(self, task_name):
        if not self.token:
            try:
                self.token = self.communicator.client_registration(self.uid, self.servers, task_name)
                if self.token is not None:
                    self.fl_ctx.set_prop(FLConstants.CLIENT_NAME, self.uid, private=False)
                    self.fl_ctx.set_prop(FLConstants.FL_TOKEN, self.token, private=False)
                    self.logger.info(
                        "Successfully registered client:{} for {}. Got token:{}".format(self.uid, task_name, self.token)
                    )
                    fire_event(EventType.CLIENT_REGISTER, self.handlers, self.fl_ctx)

            except FLCommunicationException as e:
                self.train_end = True
                self.communicator.heartbeat_done = True

    def fetch_remote_model(self, task_name):
        """
        Get registered with the remote server via channel,
        and fetch the server's model parameters.

        :param task_name: server identifier string
        :return: a CurrentModel message from server
        """
        try:
            self.logger.info("Starting to fetch global model.")
            model = self.communicator.getModel(self.servers, task_name, self.token)
            fire_event(EventType.RECEIVE_MODEL, self.handlers, self.fl_ctx)

            return model
        except FLCommunicationException as e:
            self.logger.info(e)
            self.train_end = True
            # self.communicator.heartbeat_done = True

    def push_remote_model(self, task_name):
        """
        Read local model and push to self.server[task_name] channel.
        This function makes and sends a Contribution Message.

        :param task_name: should be one of the keys of `self.server`
        """
        try:
            self.logger.info("Starting to push model.")
            fire_event(EventType.BEFORE_SEND_MODEL, self.handlers, self.fl_ctx)
            message = self.communicator.submitUpdate(
                self.servers, task_name, self.token, self.fl_ctx, self.uid, self.shareable
            )
            fire_event(EventType.SEND_MODEL, self.handlers, self.fl_ctx)

            return message
        except FLCommunicationException as e:
            self.logger.info(e)
            self.train_end = True
            # self.communicator.heartbeat_done = True

    def send_heartbeat(self, task_name):
        try:
            if self.token:
                self.communicator.send_heartbeat(self.servers, task_name, self.token)
        except FLCommunicationException as e:
            self.communicator.heartbeat_done = True

    def heartbeat(self):
        """
        Sends a heartbeat from the client to the server.
        """
        pool = None
        try:
            pool = ThreadPool(len(self.servers))
            return pool.map(self.send_heartbeat, tuple(self.servers))
        finally:
            if pool:
                pool.terminate()

    def pull_models(self):
        """
        Fetch remote models and update the local client's session.
        """
        pool = None
        try:
            pool = ThreadPool(len(self.servers))
            self.remote_models = pool.map(self.fetch_remote_model, tuple(self.servers))
            pull_success = self.check_progress(self.remote_models)
            # Update app_ctx's current round info
            if self.app_context and self.remote_models[0] is not None:
                self.app_context.global_round = self.remote_models[0].meta.current_round
            # TODO: if some of the servers failed
            # return self.model_manager.assign_current_model(self.remote_models)
            return pull_success
        finally:
            if pool:
                pool.terminate()

    def push_models(self):
        """
        Push the local model to multiple servers.
        """
        pool = None
        try:
            pool = ThreadPool(len(self.servers))
            return pool.map(self.push_remote_model, tuple(self.servers))
        finally:
            if pool:
                pool.terminate()

    def register(self):
        """
        Push the local model to multiple servers.
        """
        pool = None
        try:
            pool = ThreadPool(len(self.servers))
            return pool.map(self.client_register, tuple(self.servers))
        finally:
            if pool:
                pool.terminate()

    def push_best_model(self, task_name):
        """
        Pushes the best local model to server. This function sends a LocalModel message.

        :param task_name: Should be one of the keys to `self.servers`
        """
        try:
            submit_ctx = self.fl_ctx
            fire_event(EventType.BEFORE_SEND_BEST_MODEL, self.handlers, submit_ctx)

            local_model_shareable = self.cross_site_val_manager.get_local_model_shareable(submit_ctx)

            submit_ctx.set_prop(
                CrossValConstants.LOCAL_MODEL_SHAREABLE, value=local_model_shareable, private=True, sticky=False
            )
            fire_event(EventType.LOCAL_BEST_MODEL_AVAILABLE, self.handlers, submit_ctx)

            response = self.communicator.submit_best_local_model(
                self.uid, self.servers, task_name, self.token, model_shareable=local_model_shareable, fl_ctx=submit_ctx
            )

            fire_event(EventType.AFTER_SEND_BEST_MODEL, self.handlers, submit_ctx)

            return response
        except FLCommunicationException as flce:
            self.logger.info(flce)
        except BaseException as e:
            self.logger.info(e)

    def push_best_models(self):
        """
        Push the best local model to multiple servers.
        """
        pool = None
        try:
            pool = ThreadPool(len(self.servers))
            return pool.map(self.push_best_model, tuple(self.servers))
        finally:
            if pool:
                pool.terminate()

    def get_validation_models_from_servers(self):
        pool = None
        try:
            pool = ThreadPool(len(self.servers))
            return pool.map(self.get_validation_models, tuple(self.servers))
        finally:
            if pool:
                pool.terminate()

    def get_validation_models(self, task_name):
        """
        Gets the best models of other clients from server to run cross-validation.
        """
        try:
            self.logger.info("Getting other models from server for cross validation.")
            submit_ctx = self.fl_ctx
            fire_event(EventType.BEFORE_GET_VALIDATION_MODELS, self.handlers, submit_ctx)

            validation_models = self.communicator.get_validation_models(self.uid, self.servers, task_name, self.token)
            model_shareables = [Shareable.from_bytes(model.data) for model in validation_models.models]

            submit_ctx.set_prop(
                CrossValConstants.CROSS_VAL_VALIDATION_SHAREABLE, private=True, sticky=False, value=model_shareables
            )
            submit_ctx.set_prop(
                CrossValConstants.FINISHED, value=validation_models.finished, sticky=False, private=True
            )
            submit_ctx.set_prop(
                CrossValConstants.MORE_MODELS_AVAILABLE,
                value=validation_models.models_available,
                sticky=False,
                private=True,
            )
            fire_event(EventType.AFTER_GET_VALIDATION_MODELS, self.handlers, submit_ctx)

            return validation_models
        except FLCommunicationException as flce:
            self.logger.info(flce)
        except Exception as e:
            self.logger.info(e)

    def validate_model(self, val_model_shareable):
        """Validates a model shareables

        Args:
            val_model_shareable (Shareable): Model Shareable for validation.

        Returns:
            Shareable: Metric shareable to return
        """
        submit_ctx = self.fl_ctx
        submit_ctx.set_prop(
            CrossValConstants.CROSS_VAL_MODEL_OWNER,
            value=get_model_owner(val_model_shareable),
            sticky=False,
            private=True,
        )
        submit_ctx.set_prop(
            CrossValConstants.CROSS_VAL_VALIDATION_SHAREABLE, value=val_model_shareable, sticky=False, private=True
        )
        fire_event(EventType.BEFORE_VALIDATE_MODEL, handlers=self.handlers, ctx=submit_ctx)

        try:
            metric_shareable = self.cross_site_val_manager.validate_model(
                val_model_shareable, submit_ctx, abort_signal=self.abort_signal
            )
        except Exception as e:
            self.logger.info(f"Exception in validating model: {e}")
            metric_shareable = generate_empty_shareable(cookie=None)

        submit_ctx.set_prop(CrossValConstants.METRIC_SHAREABLE, metric_shareable, private=True, sticky=False)
        fire_event(EventType.AFTER_VALIDATE_MODEL, handlers=self.handlers, ctx=submit_ctx)

        return metric_shareable

    def submit_cross_site_validation_results(self, metric_shareable, task_name):
        try:
            submit_ctx = self.fl_ctx
            self.logger.info("Submitting cross validation results to server.")
            fire_event(EventType.BEFORE_SUBMIT_VALIDATION_RESULTS, handlers=self.handlers, ctx=submit_ctx)

            return_ctx = self.communicator.submit_cross_site_validation_results(
                self.uid, self.servers, task_name, self.token, metric_shareable
            )

            fire_event(EventType.AFTER_SUBMIT_VALIDATION_RESULTS, self.handlers, self.fl_ctx)

            return return_ctx
        except FLCommunicationException as flce:
            self.logger.info(flce)
        except Exception as e:
            self.logger.info(f"Submit cross validation failed: {e}")

    def run_cross_site_validation(self):
        """
        Run cross validation
        """
        # Clear FL Context
        self.fl_ctx.remove_prop(FLConstants.PEER_CONTEXT)
        finished = False
        models_available = False
        timeout = self.cross_site_val_manager.timeout
        time_since_last_model = 0

        while not finished:
            # Check for abort
            if self.abort_signal.triggered:
                self.logger.info("Abort called. Exiting cross site validation.")
                return

            validation_models_msg = self.get_validation_models_from_servers()[0]

            # Retrieve data
            if validation_models_msg:
                finished = validation_models_msg.finished
                models_available = validation_models_msg.models_available
                model_shareables = [Shareable.from_bytes(model.data) for model in validation_models_msg.models]
                for model_shareable in model_shareables:
                    if model_shareable:
                        time_since_last_model = 0
                        metric_shareable = self.validate_model(model_shareable)
                        set_cookie(metric_shareable, get_cookie(model_shareable))
                    else:
                        metric_shareable = generate_empty_shareable(cookie=None)

                    # Send Metrics back to server
                    self.submit_cross_site_validation_results(metric_shareable, tuple(self.servers)[0])
            else:
                self.logger.info("Server did not send any models.")

            # Determine if we need to wait or not
            if not finished:
                if models_available:
                    self.logger.info("More models available with server.")
                else:
                    self.logger.info("Server has no models available currently. Waiting 60 secs before asking again.")
                    for _ in range(60):
                        time.sleep(1)
                        if self.abort_signal.triggered:
                            self.logger.info("Abort called. Exiting cross site validation.")
                            return
                    time_since_last_model = time_since_last_model + 1  # Mins
                    if timeout and time_since_last_model >= timeout:
                        self.logger.info(
                            f"Timeout was set to {timeout}. Exiting cross validation after waiting for "
                            f"{time_since_last_model} minutes without receiving any models."
                        )
                        return
            else:
                self.logger.info("Finished cross site validation.")

    def run_heartbeat(self):
        """
        Periodically runs the heartbeat.
        """
        # while not self.heartbeat_done:
        #     time.sleep(60)
        #     self.heartbeat()

        self.heartbeat()

        # self.communicator.heartbeat_done = True

    def start_heartbeat(self):
        heartbeat_thread = threading.Thread(target=self.run_heartbeat)
        # heartbeat_thread.daemon = True
        heartbeat_thread.start()

    def quit_remote(self, task_name):
        """
        Sending the last message to the server before leaving.

        :param task_name: server task identifier
        :return: server's reply to the last message
        """
        return self.communicator.quit_remote(self.servers, task_name, self.token)

    def close(self):
        """
        Quit the remote federated server, close the local session.
        """
        self.logger.info("Shutting down client")

        # pool = None
        # try:
        #     pool = ThreadPool(len(self.servers))
        #     pool.map(self.quit_remote, tuple(self.servers))
        #     # self.pool.join()
        # except Exception as e:
        #     self.logger.info(e)
        # finally:
        #     if pool:
        #         pool.terminate()  # clean up all threads
        # pool = ThreadPool(len(self.servers))
        # pool.map(self.quit_remote, tuple(self.servers))

        # TF sometimes holds the thread not being able to shutdown cleanly. Not call this for now.
        # self.model_manager.close()

        # import traceback, sys
        # for thread in threading.enumerate():
        #     traceback.print_stack(sys._current_frames()[thread.ident])

        # self.admin_agent.shutdown()

        return 0

    def check_progress(self, remote_models):
        if remote_models[0] is not None:
            print("Get global model for round: {}".format(remote_models[0].meta.current_round))
            if remote_models[0].meta.current_round >= remote_models[0].meta.num_rounds - 1:
                # set the local train to finish after the last round training.
                self.train_end = True
            self.server_meta = remote_models[0].meta
            return True
        else:
            return False
