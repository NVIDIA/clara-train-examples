import logging
import os
import re
import shutil
import sys
import time
import traceback
from concurrent.futures import ThreadPoolExecutor

from dlmed.hci.zip_utils import unzip_all_from_bytes

from flare.utils.admin_defs import Message

from .client_executor import ProcessExecutor
from .client_status import ClientStatus


class ClientAdminInterface(object):
    def __init__(self, client, client_name, sender, args, rank, workers=5):
        self.client = client
        self.client_name = client_name
        self.sender = sender
        self.args = args
        self.rank = rank
        self.client.process = None
        self.client_executor = ProcessExecutor(client.uid)

        assert workers >= 1, "workers must >= 1"
        self.executor = ThreadPoolExecutor(max_workers=workers)

        self.logger = logging.getLogger(self.__class__.__name__)

    def set_agent(self, admin_agent):
        self.admin_agent = admin_agent

    def _get_open_port(self):
        import socket

        s = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        s.bind(("", 0))
        s.listen(1)
        port = s.getsockname()[1]
        s.close()
        return port

    def do_validate(self, req: Message):
        self.logger.info("starting cross site validation.")
        future = self.executor.submit(lambda p: _do_validate(*p), [self.sender, req])
        # thread = threading.Thread(target=_do_validate, args=(self.sender, req))
        # thread.start()

        return "validate process started."

    def client_status(self):
        if self.rank == 0:
            self.logger.info("check client status.")
            client_name = self.client.uid
            token = self.client.token
            message = "client name: {}".format(client_name)
            message += "\ttoken: {}".format(token)

            message += "\tstatus: {}".format(self.client_executor.check_status(self.client))
            # if self.client.status == ClientStatus.TRAINING_STOPPED:
            #     message += '\tlocal epochs: {}'.format(self.client.model_manager.fitter.num_epochs)

            return message
        else:
            return ""

    def start_client(self, run_number):
        status = self.client.status
        if (
            status == ClientStatus.TRAINING_STARTING
            or status == ClientStatus.TRAINING_STARTED
            or status == ClientStatus.CROSS_SITE_VALIDATION
        ):
            return "Client already in training."

        mmar_root = os.path.join(self.args.mmar, "run_" + str(run_number), "mmar_" + self.client.uid)
        if not os.path.exists(mmar_root):
            return "Client mmar does not exist. Please deploy it before start client."

        mmar_custom_folder = os.path.join(mmar_root, "custom")
        try:
            sys.path.index(mmar_custom_folder)
        except ValueError:
            self.remove_custom_path()
            sys.path.append(mmar_custom_folder)

        self.logger.info("Starting client training. rank: {}".format(self.rank))

        open_port = self._get_open_port()
        self._write_token_file(run_number, open_port)

        self.client_executor.start_train(self.client, self.args, mmar_root, mmar_custom_folder, open_port)

        return "Start the client..."

    def wait_training_process_finish(self):
        self.client.process.join()

        # _cross_validation(self.client, self.args)
        self.client.status = ClientStatus.TRAINING_STOPPED

    def start_mgpu_client(self, run_number, gpu_number):
        status = self.client.status
        if status == ClientStatus.TRAINING_STARTING or status == ClientStatus.TRAINING_STARTED:
            return "Client already in training."

        mmar_root = os.path.join(self.args.mmar, "run_" + str(run_number), "mmar_" + self.client.uid)
        if not os.path.exists(mmar_root):
            return "Client mmar does not exist. Please deploy it before start client."

        mmar_custom_folder = os.path.join(mmar_root, "custom")
        try:
            sys.path.index(mmar_custom_folder)
        except ValueError:
            self.remove_custom_path()
            sys.path.append(mmar_custom_folder)

        self.logger.info("Starting client training. rank: {}".format(self.rank))

        open_port = self._get_open_port()
        self._write_token_file(run_number, open_port)

        self.client_executor.start_mgpu_train(
            self.client, self.args, mmar_root, gpu_number, mmar_custom_folder, open_port
        )

        return "Start the client..."

    def _write_token_file(self, run_number, open_port):
        token_file = os.path.join(self.args.mmar, "client_token.txt")
        if os.path.exists(token_file):
            os.remove(token_file)
        with open(token_file, "wt") as f:
            f.write("%s\n%s\n%s\n%s\n" % (self.client.token, run_number, self.client.uid, open_port))

    def wait_process_complete(self):
        self.client.process.wait()

        # self.client.cross_validation()
        self.client.status = ClientStatus.TRAINING_STOPPED

    def remove_custom_path(self):
        regex = re.compile(".*/run_.*/custom")
        custom_paths = list(filter(regex.search, sys.path))
        for path in custom_paths:
            sys.path.remove(path)

    def abort_client(self):
        status = self.client.status
        if status == ClientStatus.TRAINING_STOPPED:
            return "Client training already stopped."

        if status == ClientStatus.TRAINING_NOT_STARTED:
            return "Client training has not started."

        if status == ClientStatus.TRAINING_STARTING:
            return "Client training is starting, please wait for started before abort."

        self.client_executor.abort_train(self.client)

        return "Aborted the client. "

    def shutdown_client(self):
        self.logger.info("Client shutdown...")
        touch_file = os.path.join(self.args.mmar, "shutdown.fl")
        self.client_executor.close()
        self.client.train_end = True
        future = self.executor.submit(lambda p: _shutdown_client(*p), [self.client, self.admin_agent, touch_file])

        return "Shutdown the client..."

    def restart_client(self):
        self.logger.info("Client shutdown...")
        touch_file = os.path.join(self.args.mmar, "restart.fl")
        self.client_executor.close()
        self.client.train_end = True
        future = self.executor.submit(lambda p: _shutdown_client(*p), [self.client, self.admin_agent, touch_file])

        return "Restart the client..."

    def deploy_mmar(self, data):
        if self.rank == 0:
            # if not os.path.exists('/tmp/tmp'):
            #     os.makedirs('/tmp/tmp')
            unzip_all_from_bytes(data, self.args.mmar)

            return "MMAR deployed."
        else:
            return ""

    def delete_run_number(self, num):
        run_number_folder = os.path.join(self.args.mmar, "run_" + str(num))
        if os.path.exists(run_number_folder):
            shutil.rmtree(run_number_folder)
        return "Delete run folder: {}".format(run_number_folder)


def _do_validate(sender, message):
    print("starting the validate process .....")
    time.sleep(60)
    print("Generating processing result ......")
    reply = Message(topic=message.topic, body="")
    sender.send_result(reply)
    pass


def _shutdown_client(client, admin_agent, touch_file):
    with open(touch_file, "a"):
        os.utime(touch_file, None)

    try:
        print("About to shutdown the client...")
        client.train_end = True
        client.communicator.heartbeat_done = True
        time.sleep(3)
        client.close()

        if client.process:
            client.process.terminate()

        admin_agent.shutdown()
    except BaseException as e:
        traceback.print_exc()
        print("FL client execution exception: " + str(e))
        # client.status = ClientStatus.TRAINING_EXCEPTION
