import json
import os
import re

from dlmed.utils.clara_conf import ClaraConfiger
from dlmed.utils.class_utils import get_config_classname
from dlmed.utils.json_scanner import Node
from dlmed.utils.wfconf import ConfigContext

from flare.apis.fl_component import FLComponent
from flare.private.fed.client.base_client_trainer import BaseClientTrainer

from .trainers.server_trainer import ServerTrainer
from flare.private.fed.crossvalidation.utils import get_model_registry_path

FL_PACKAGES = ["flare"]
FL_MODULES = ["server", "client", "components", "handlers", "pt", "app"]


class FLServerStarterConfiger(ClaraConfiger):
    def __init__(
        self,
        mmar_root: str,
        wf_config_file_name=None,
        server_config_file_name=None,
        env_config_file_name=None,
        log_config_file_name=None,
        kv_list=None,
        logging_config=True
    ):

        if not wf_config_file_name:
            wf_config_file_name = "config/config_fed_server.json"

        base_pkgs = FL_PACKAGES
        module_names = FL_MODULES

        ClaraConfiger.__init__(
            self,
            base_pkgs=base_pkgs,
            module_names=module_names,
            mmar_root=mmar_root,
            wf_config_file_name=wf_config_file_name,
            env_config_file_name=env_config_file_name,
            log_config_file_name=log_config_file_name,
            kv_list=kv_list,
            num_passes=2,
            element_filter=lambda x: not x.startswith("lambda"),
            logging_config=logging_config
        )

        self.mmar_root = mmar_root
        self.server_config_file_name = server_config_file_name
        self.env_config_file_name = env_config_file_name
        self.log_config_file_name = log_config_file_name
        self.kv_list = kv_list

        self.train_model = None

        self.outbound_filters = []
        self.inbound_filters = []
        self.cmd_modules = []
        self.result_processors = []
        self.fl_handlers = []
        self.model_aggregator = None
        self.model_saver = None
        self.mmar_validator = None
        self.server_trainer = None
        self.shareable_generator = None

        # self.fl_components = set()

    def start_config(self, config_ctx: ConfigContext):
        super().start_config(config_ctx)

        # loading server specifications
        try:
            with open(os.path.join(self.mmar_root, self.server_config_file_name), "r") as f:
                self.wf_config_data.update(json.load(f))
                # update the SSL certs with mmar root
                for server in self.wf_config_data["servers"]:
                    if server.get("ssl_private_key"):
                        server["ssl_private_key"] = os.path.join(self.mmar_root, server["ssl_private_key"])
                    if server.get("ssl_cert"):
                        server["ssl_cert"] = os.path.join(self.mmar_root, server["ssl_cert"])
                    if server.get("ssl_root_cert"):
                        server["ssl_root_cert"] = os.path.join(self.mmar_root, server["ssl_root_cert"])
        except Exception:
            raise ValueError("Server config error: '{}'".format(self.server_config_file_name))

    def process_first_pass(self, node: Node):
        element = node.element
        path = node.path()

        if path == "aggregator" and isinstance(element, dict):
            self.model_aggregator = self.build_component(element)
            return

        if path == "model_persistor" and isinstance(element, dict):
            # model_config = element.get("args").get("model")
            # if model_config:
            #     self.wf_config_data["model_persistor"]["args"]["model"] = self.build_component(model_config)

            self.model_saver = self.build_component(element)
            return

        if re.search(r"^outbound_filters.#[0-9]+$", path):
            t = self.build_component(element)
            self.outbound_filters.append(t)
            return

        if re.search(r"^inbound_filters.#[0-9]+$", path):
            t = self.build_component(element)
            self.inbound_filters.append(t)
            return

        if re.search(r"^admin_cmd_modules.#[0-9]+$", path):
            t = self.build_component(element)
            self.cmd_modules.append(t)
            return

        if re.search(r"^result_processors.#[0-9]+$", path):
            t = self.build_component(element)
            self.result_processors.append(t)
            return

        if re.search(r"^handlers.#[0-9]+$", path):
            t = self.build_nested(element, self.mmar_root)
            if not isinstance(t, FLComponent):
                self.fl_handlers.append(t)
            return

        if path == "config_validator" and isinstance(element, dict):
            self.mmar_validator = self.build_component(element)
            return

        if path == "server_trainer" and isinstance(element, dict):
            self.server_trainer = self.build_component(element)
            return

        if path == "shareable_generator" and isinstance(element, dict):
            self.shareable_generator = self.build_component(element)
            return

        if path == "model" and isinstance(element, dict):
            self.train_model = self.build_component(element)
            return

        # super().process_first_pass(node)

    def build_component(self, config_dict):
        t = super().build_component(config_dict)
        if isinstance(t, FLComponent):
            self.fl_handlers.append(t)
        return t

    def process_second_pass(self, node: Node):
        # super().process_second_pass(node)
        path = node.path()
        element = node.element

        # process validation transforms
        # if re.search(r'^validate\.pre_transforms\.#[0-9]+$', path):
        #     if 'ref' in element:
        #         comp = self.create_component_from_ref(self._trans_refs, element)
        #     else:
        #         comp = self.build_component(element)
        #     if comp is not None:
        #         self.val_transforms.append(comp)
        #     return
        #
        # if re.search(r'^validate\.post_transforms\.#[0-9]+$', path):
        #     if 'ref' in element:
        #         comp = self.create_component_from_ref(self._post_trans_refs, element)
        #     else:
        #         comp = self.build_component(element)
        #     if comp is not None:
        #         self.val_post_transforms.append(comp)
        #     return
        #

    # def _setup_model(self):
    #     for item in self._train_model_element:
    #         if item.get("disabled", False):
    #             continue
    #         if self.train_model is not None:
    #             raise ConfigError("only one model can be enabled, but got two")
    #
    #         ts_path = item.get("ts_path", None)
    #         if ts_path is not None:
    #             self.train_model = torch.jit.load(ts_path)
    #         else:
    #             self.train_model = self.build_component(item)
    #

    def process_config_element(self, config_ctx: ConfigContext, node: Node):
        if config_ctx.pass_num == 1:
            self.process_first_pass(node)
        else:
            self.process_second_pass(node)

    def finalize_config(self, config_ctx: ConfigContext):
        # FIXME: will also add optimizer and lr_shcedule for FL aggregation soon
        # self._setup_model()

        if "PROCESSING_TASK" not in self.env_config:
            raise Exception("Must provide a processing task.")
        secure_train = False
        if self.cmd_vars.get("secure_train"):
            secure_train = self.cmd_vars["secure_train"]

        # all_extra_inputs = self.trainer.extra_inputs

        build_ctx = {
            "task": self.env_config["PROCESSING_TASK"],
            "initial_learning_rate": self.env_config.get("learning_rate", 1e-4),
            "model": self.train_model,
            # "data_source": self.train_data_source,
            # "loss": self.loss,
            # "optimizer": self.optimizer,
            "is_multi_gpu": self.env_config.get("multi_gpu", False),
            "ckpt_preload_path": self.env_config.get("MMAR_CKPT", None),
            "model_aggregator": self.model_aggregator,
            # "dynamic_input_shape": self.dynamic_input_shape,
            "model_saver": self.model_saver,
            "shareable_generator": self.shareable_generator,
            "outbound_filters": self.outbound_filters,
            "inbound_filters": self.inbound_filters,
            "cmd_modules": self.cmd_modules,
            "result_processors": self.result_processors,
            "secure_train": secure_train,
            # "extra_inputs": all_extra_inputs,
            "handlers": self.fl_handlers,
            "mmar_validator": self.mmar_validator,
            "server_config": self.wf_config_data["servers"],
            "model_log_dir": self.env_config["MMAR_CKPT_DIR"],
        }

        # if self.server_trainer:
        #     trainer = self.server_trainer
        # else:
        #     trainer = ServerTrainer(
        #         task=self.env_config['PROCESSING_TASK'],
        #         initial_learning_rate=self.env_config.get('learning_rate', 1e-4),
        #         model=self.model,
        #         data_source=self.train_data_source,
        #         loss=self.loss,
        #         optimizer=self.optimizer,
        #         is_multi_gpu=self.env_config.get('multi_gpu', False),
        #         ckpt_preload_path=self.env_config.get('MMAR_CKPT', None),
        #         model_aggregator=self.model_aggregator,
        #         dynamic_input_shape=self.dynamic_input_shape,
        #         model_saver=self.model_saver,
        #         outbound_filters=self.outbound_filters,
        #         inbound_filters=self.inbound_filters,
        #         cmd_modules=self.cmd_modules,
        #         result_processors=self.result_processors,
        #         secure_train=secure_train,
        #         extra_inputs=all_extra_inputs,
        #         handlers=self.fl_handlers,
        #         mmar_validator=self.mmar_validator
        #     )
        #
        #     trainer.set_server_config(self.wf_config_data['servers'])
        #     trainer.set_model_log_dir(self.env_config['MMAR_CKPT_DIR'])

        trainer = ServerTrainer()
        trainer.build(build_ctx)
        self.trainer = trainer

    def build_nested(self, config_dict, mmar_root):
        if get_config_classname(config_dict) == "ClaraEvaluator":
            config_dict["args"]["mmar_root"] = mmar_root
        for k in config_dict["args"]:
            element = config_dict["args"][k]
            if isinstance(element, dict) and element.get("args") is not None:
                config_dict["args"][k] = self.build_nested(config_dict["args"][k], mmar_root)
        return self.build_component(config_dict)


class FLClientStarterConfiger(ClaraConfiger):
    def __init__(
        self,
        mmar_root: str,
        wf_config_file_name=None,
        client_config_file_name=None,
        env_config_file_name=None,
        log_config_file_name=None,
        kv_list=None,
        local_rank=0,
    ):

        if not wf_config_file_name:
            wf_config_file_name = "config/config_fed_client.json"

        base_pkgs = FL_PACKAGES
        module_names = FL_MODULES
        # TrainConfiger.__init__(self,
        #                        mmar_root=mmar_root,
        #                        wf_config_file_name=wf_config_file_name,
        #                        env_config_file_name=env_config_file_name,
        #                        log_config_file_name=log_config_file_name,
        #                        kv_list=kv_list,
        #                        local_rank=local_rank,
        #                        base_pkgs=base_pkgs,
        #                        module_names=module_names)
        ClaraConfiger.__init__(
            self,
            base_pkgs=base_pkgs,
            module_names=module_names,
            mmar_root=mmar_root,
            wf_config_file_name=wf_config_file_name,
            env_config_file_name=env_config_file_name,
            log_config_file_name=log_config_file_name,
            kv_list=kv_list,
            num_passes=2,
            element_filter=lambda x: not x.startswith("lambda"),
        )

        self.mmar_root = mmar_root
        self.client_config_file_name = client_config_file_name

        self.outbound_filters = []
        self.inbound_filters = []
        self.req_processors = []
        self.client_trainer = None
        self.privacy = None

        self.handlers = []
        self.trainer = None
        self.evaluator = None
        self.use_gpu = True
        self.model_reader_writer = None

        # Cross site validation config
        self.cross_site_val_manager = None
        self.model_validator = None
        self.is_participating_cross_val = False
        self.cross_val_timeout = None
        self.cross_val_inbound_filters = []
        self.cross_val_outbound_filters = []

    def start_config(self, config_ctx: ConfigContext):
        super().start_config(config_ctx)

        self.use_gpu = self.all_vars.get("use_gpu", True)
        # loading client specifications
        try:
            with open(os.path.join(self.mmar_root, self.client_config_file_name), "r") as f:
                self.wf_config_data.update(json.load(f))
                # update the SSL certs with mmar root
                client = self.wf_config_data["client"]
                if client.get("ssl_private_key"):
                    client["ssl_private_key"] = os.path.join(self.mmar_root, client["ssl_private_key"])
                if client.get("ssl_cert"):
                    client["ssl_cert"] = os.path.join(self.mmar_root, client["ssl_cert"])
                if client.get("ssl_root_cert"):
                    client["ssl_root_cert"] = os.path.join(self.mmar_root, client["ssl_root_cert"])
        except Exception:
            raise ValueError("Client config error: '{}'".format(self.client_config_file_name))

    def process_first_pass(self, node: Node):
        element = node.element
        path = node.path()

        # if path == 'client' and isinstance(element, dict):
        #     # client_config = train_configs['client']
        #     # self.privacy = self.build_component(element['privacy'])
        #     self.model_reader_writer = self.build_component(element['model_reader_writer'])
        #     self.model_validator = self.build_component(element['model_validator'])
        #     return

        if re.search(r"^client.outbound_filters.#[0-9]+$", path):
            t = self.build_component(element)
            self.outbound_filters.append(t)
            return

        if re.search(r"^client.inbound_filters.#[0-9]+$", path):
            t = self.build_component(element)
            self.inbound_filters.append(t)
            return

        if re.search(r"^client.req_processors.#[0-9]+$", path):
            t = self.build_component(element)
            self.req_processors.append(t)
            return

        if re.search(r"^handlers.#[0-9]+$", path):
            t = self.build_nested(element, self.mmar_root)
            if not isinstance(t, FLComponent):
                self.handlers.append(t)
            return

        if path == "client_trainer" and isinstance(element, dict):
            reader_writer_config = element.get("args").get("model_reader_writer")
            if reader_writer_config:
                element["args"]["model_reader_writer"] = self.build_component(reader_writer_config)

            self.client_trainer = self.build_component(element)
            return

        if path == 'cross_site_validation' and isinstance(element, dict):
            model_validator_config = element.get('model_validator')
            if model_validator_config:
                self.model_validator = self.build_component(model_validator_config)
            is_participating_config = element.get('is_participating')
            if is_participating_config:
                self.is_participating_cross_val = is_participating_config
            cross_val_timout_config = element.get('timeout')
            if cross_val_timout_config:
                self.cross_val_timeout = cross_val_timout_config
            return

        if re.search(r"^cross_site_validation.inbound_filters.#[0-9]+$", path):
            t = self.build_component(element)
            self.cross_val_inbound_filters.append(t)

        if re.search(r"^cross_site_validation.outbound_filters.#[0-9]+$", path):
            t = self.build_component(element)
            self.cross_val_outbound_filters.append(t)

    def process_second_pass(self, node: Node):
        # super().process_second_pass(node)
        pass

    def build_component(self, config_dict):
        t = super().build_component(config_dict)
        if isinstance(t, FLComponent):
            self.handlers.append(t)
        return t

    def process_config_element(self, config_ctx: ConfigContext, node: Node):
        if config_ctx.pass_num == 1:
            self.process_first_pass(node)
        else:
            self.process_second_pass(node)

    def finalize_config(self, config_ctx: ConfigContext):
        # super().finalize_config(config_ctx)

        if "PROCESSING_TASK" not in self.env_config:
            raise Exception("Must provide a processing task.")
        secure_train = False
        if self.cmd_vars.get("secure_train"):
            secure_train = self.cmd_vars["secure_train"]

        # all_extra_inputs = self.trainer.extra_inputs

        build_ctx = {
            "uid": self.cmd_vars.get("uid", ""),
            "aggregation_epochs": self.wf_config_data["client"].get("local_epochs", 1),
            "aggregation_steps": self.wf_config_data["client"].get("steps_aggregation", 0),
            "is_multi_gpu": self.env_config.get("multi_gpu", False),
            "save_checkpoint": self.wf_config_data["client"].get("save_checkpoint", True),
            "server_config": self.wf_config_data.get("servers", []),
            "client_config": self.wf_config_data["client"],
            "privacy": self.privacy,
            "secure_train": secure_train,
            # "dynamic_input_shape": self.dynamic_input_shape,
            "model_reader_writer": self.model_reader_writer,
            "model_validator": self.model_validator,
            "outbound_filters": self.outbound_filters,
            "inbound_filters": self.inbound_filters,
            "req_processors": self.req_processors,
            # "extra_inputs": all_extra_inputs,
            "handlers": self.handlers,
            "model_log_dir": self.env_config["MMAR_CKPT_DIR"],
            "supervised_trainer": self.trainer,
            "supervised_evaluator": self.evaluator,
            "cross_val_participating": self.is_participating_cross_val,
            "model_registry_path": get_model_registry_path(self.mmar_root),
            "cross_val_inbound_filters": self.cross_val_inbound_filters,
            "cross_val_outbound_filters": self.cross_val_outbound_filters,
            "cross_val_timeout": self.cross_val_timeout
        }

        # if self.client_trainer:
        #     trainer = self.client_trainer
        # else:
        #     trainer = ClientTrainer(trainer=self.trainer,
        #                             uid=self.cmd_vars.get('uid', ''),
        #                             num_epochs=self.wf_config_data['client']['local_epochs'],
        #                             save_checkpoint=self.wf_config_data['client'].get('save_checkpoint', True),
        #                             server_config=self.wf_config_data.get('servers', []),
        #                             client_config=self.wf_config_data['client'],
        #                             privacy=self.privacy,
        #                             secure_train=secure_train,
        #                             dynamic_input_shape=self.dynamic_input_shape,
        #                             # data_assembler=self.data_assembler,
        #                             model_reader_writer=self.model_reader_writer,
        #                             model_validator=self.model_validator,
        #                             outbound_filters=self.outbound_filters,
        #                             inbound_filters=self.inbound_filters,
        #                             req_processors=self.req_processors,
        #                             extra_inputs=all_extra_inputs,
        #                             handlers=self.handlers)

        self.base_trainer = BaseClientTrainer()
        self.base_trainer.build(build_ctx)
        # self.trainer = trainer
        # self.client_trainer = trainer

    def build_nested(self, config_dict, mmar_root):
        if get_config_classname(config_dict) == "ClaraEvaluator":
            config_dict["args"]["mmar_root"] = mmar_root
        for k in config_dict["args"]:
            element = config_dict["args"][k]
            if isinstance(element, dict) and element.get("args") is not None:
                config_dict["args"][k] = self.build_nested(config_dict["args"][k], mmar_root)
        return self.build_component(config_dict)
