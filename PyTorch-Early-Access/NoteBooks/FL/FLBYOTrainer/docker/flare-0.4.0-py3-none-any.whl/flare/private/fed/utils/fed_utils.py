from flare.private.fed.protos.federated_pb2 import ModelData
from flare.private.fed.utils.numproto import bytes_to_proto


def shareable_to_modeldata(shareable):
    # make_init_proto message
    model_data = ModelData()  # create an empty message

    model_data.params["data"].CopyFrom(bytes_to_proto(shareable.to_bytes()))
    return model_data
