from dlmed.hci.reg import CommandModule

from flare.private.fed.server.shell_cmd import ShellCommandModule
from flare.private.fed.server.sys_cmd import SystemCommandModule
from flare.private.fed.server.training_cmd import TrainingCommandModule
from flare.private.fed.server.validation_cmd import ValidationCommandModule


class ServerCommandModules:
    cmd_modules = [ShellCommandModule(), SystemCommandModule(), TrainingCommandModule(), ValidationCommandModule()]

    def __init__(self) -> None:
        super().__init__()

    @staticmethod
    def register_cmd_module(cmd_module: CommandModule):
        ServerCommandModules.cmd_modules.append(cmd_module)
