from flare.private.fed.server.server_cmd_modules import ServerCommandModules
from flare.private.fed.server.fed_server import FederatedServer


class ServerTrainer:
    def __init__(self):
        self.mmar_validator = None
        self.services = None
        self.cmd_modules = ServerCommandModules.cmd_modules

    def build(self, build_ctx):
        self.server_config = build_ctx["server_config"]
        # self.cmd_modules = build_ctx["cmd_modules"]
        self.model_log_dir = build_ctx["model_log_dir"]
        self.secure_train = build_ctx["secure_train"]
        self.ckpt_preload_path = build_ctx["ckpt_preload_path"]
        self.model_aggregator = build_ctx["model_aggregator"]
        self.model_saver = build_ctx["model_saver"]
        self.shareable_generator = build_ctx["shareable_generator"]
        self.outbound_filters = build_ctx["outbound_filters"]
        self.inbound_filters = build_ctx["inbound_filters"]
        self.result_processors = build_ctx["result_processors"]
        self.handlers = build_ctx["handlers"]
        self.mmar_validator = build_ctx["mmar_validator"]
        self.model = build_ctx["model"]

    def train(self):
        self.services = self.deploy()
        self.start_training(self.services)

    def start_training(self, services):
        services.start()

    def create_builder(self, services):
        services.set_builder(builder=self.model)

    def create_fl_server(self):
        # We only deploy the first server right now .....
        first_server = sorted(self.server_config)[0]
        wait_after_min_clients = first_server.get("wait_after_min_clients", 10)
        heart_beat_timeout = 600
        if first_server["heart_beat_timeout"]:
            heart_beat_timeout = first_server["heart_beat_timeout"]
        services = FederatedServer(
            task_name=first_server.get("name", ''),
            min_num_clients=first_server["min_num_clients"],
            max_num_clients=first_server["max_num_clients"],
            wait_after_min_clients=wait_after_min_clients,
            start_round=first_server.get("start_round", 0),
            num_rounds=first_server.get("num_rounds", 0),
            exclude_vars=first_server.get("exclude_vars", "dummy"),
            model_log_dir=self.model_log_dir,
            ckpt_preload_path=self.ckpt_preload_path,
            model_aggregator=self.model_aggregator,
            model_saver=self.model_saver,
            shareable_generator=self.shareable_generator,
            outbound_filters=self.outbound_filters,
            inbound_filters=self.inbound_filters,
            cmd_modules=self.cmd_modules,
            result_processors=self.result_processors,
            heart_beat_timeout=heart_beat_timeout,
            handlers=self.handlers,
        )
        return first_server, services

    def deploy(self):
        first_server, services = self.create_fl_server()
        services.deploy(grpc_args=first_server, secure_train=self.secure_train)
        self.create_builder(services)
        print("deployed FL server trainer.")
        return services

    def close(self):
        if self.services:
            self.services.close()
