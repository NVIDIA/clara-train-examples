from .shell_cmd import ShellCommandProcessor
from .sys_cmd import SysInfoProcessor
from .training_cmd import (
    AbortClientProcessor,
    ClientStatusProcessor,
    DeleteRunNumberProcessor,
    DeployProcessor,
    RestartClientProcessor,
    ShutdownClientProcessor,
    StartClientMGpuProcessor,
    StartClientProcessor,
)
from .validation_cmd import ValidateRequestProcessor


class ClientRequestProcessors:
    request_processors = [
        StartClientProcessor(),
        ClientStatusProcessor(),
        AbortClientProcessor(),
        ShutdownClientProcessor(),
        DeployProcessor(),
        ValidateRequestProcessor(),
        ShellCommandProcessor(),
        DeleteRunNumberProcessor(),
        SysInfoProcessor(),
        RestartClientProcessor(),
        StartClientMGpuProcessor(),
    ]

    @staticmethod
    def register_cmd_module(request_processor):
        from .admin import RequestProcessor

        assert isinstance(request_processor, RequestProcessor)

        ClientRequestProcessors.request_processors.append(request_processor)
