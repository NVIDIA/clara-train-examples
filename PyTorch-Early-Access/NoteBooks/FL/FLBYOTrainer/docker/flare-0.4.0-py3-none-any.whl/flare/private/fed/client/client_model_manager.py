"""Server and client side model handlers"""

import logging
import re

import numpy as np

from flare.apis.fl_constant import FLConstants
from flare.private.fed.protos.federated_pb2 import ModelMetaData
from flare.utils.fed_utils import FED_DELTA_W


class ClientModelManager:
    """
    Client-side model manager lives on client's local machine.
    """

    def __init__(
        self,
        task_names=None,
        exclude_vars=None,
        privacy=None,
        model_reader_writer=None,
        visualizer=None,
    ):
        """
        Initialization of general params inside a cient model manager.

        :param task_names: a list of hashable, each uniquely defines
             a remote server
        """
        self.logger = logging.getLogger(self.__class__.__name__)

        self.federated_meta = {task_name: list() for task_name in task_names}
        # a regular expression string, matching the
        # variable names. Matched variables will be client-specific
        # variables, not read to or written by the server's global model
        self.exclude_vars = re.compile(exclude_vars) if exclude_vars else None
        # self.fitter = None

        self.model_reader_writer = model_reader_writer
        # self.model_validator = model_validator
        self.visualizer = visualizer

    def set_fitter(self, trainer, model_reader_writer):
        # self.fitter = self.model_reader_writer.initialize(trainer)
        self.model_reader_writer = model_reader_writer
        if self.model_reader_writer:
            self.model_reader_writer.initialize(trainer)

    def model_meta(self, task_name):
        """
        task meta data, should be consistent with the server's
        """
        task_meta = self.federated_meta.get(task_name, [])
        return ModelMetaData() if not task_meta else task_meta[0]

    def model_vars(self, task_name):
        """
        task variables, should be a subset of the server's
        """
        task_meta = self.federated_meta.get(task_name, [])
        return [] if not task_meta else task_meta[1]

    # def update_current_model(self, local_model_params):
    #     """
    #     Save the local_model values by model writer.
    #
    #     :param local_model: Should be a dict of numpy.ndarray with weights values.
    #     """
    #     self.model_reader_writer.apply_model(local_model_params,
    #                                          options={'no_proto_convert': True})
    #
    # def get_current_model_data(self, local_model_params=None):
    #     """
    #     Save the local_model values by model writer.
    #
    #     :param local_model: Should be a dict of numpy.ndarray with weights values.
    #     """
    #     return self.model_reader_writer.extract_model(local_model_params)

    def read_current_model(self, task_name, local_model_dict, total_steps, type_str=FED_DELTA_W):
        """
        Read variables from the model reader.
        Also it computes the model diff values.

        :return: a ModelData message to be sent to server
        """
        # local_model_dict = self.generate_shareable(task_name)

        model_vars = self.model_vars(task_name)
        if type_str != FED_DELTA_W:
            raise NotImplementedError("Only delta_w supported.")
        global_model_dict = {
            # var_name: proto_to_ndarray(model_vars[var_name])
            var_name: model_vars[var_name]
            for var_name in tuple(model_vars)
        }
        # compute delta model, global model has the primary key set
        # model_diff = {}
        model_diff = {}
        for name in global_model_dict:
            if name not in local_model_dict:
                continue
            model_diff[name] = local_model_dict[name] - global_model_dict[name]
        # modifying delta_w
        # if self.privacy_policy is not None:
        #     model_diff = self.privacy_policy.apply(model_diff, train_ctx)

        # prepare output of model reading
        # model_data = ModelData()
        model_values = []
        for v_name in model_diff:
            # # TODO: Check if model_diff[v_name] is already ndarray, why do we need to
            # #       call make_ndarray(make_tensor(...))?
            # model_data.params[v_name].CopyFrom(
            #     # ndarray_to_proto(make_ndarray(make_tensor(model_diff[v_name]))))
            #     ndarray_to_proto(model_diff[v_name]))
            model_values.append(model_diff[v_name].ravel())
        # invariant to number of steps
        if self.visualizer:
            # We call visualize API to do platform-dependent visualizations.
            model_values = np.concatenate(model_values) / np.float(total_steps)
            self.visualizer.visualize(model_values)
        self.logger.debug("Finished read_current_model .... ")
        # return model_data
        return model_diff

    def track_remote_model(self, shareable, server_meta, fl_ctx):
        shared_fl_context = fl_ctx.get_prop(FLConstants.PEER_CONTEXT)
        # meta = shared_fl_context.get_prop("model_meta")

        # remote_task_name = model.meta.task.name
        remote_task_name = shared_fl_context.get_prop("task_name")

        # filtering the variables to be shared
        # model_params = model.data.params
        model_params = shareable
        for name in tuple(model_params):
            if self.exclude_vars and self.exclude_vars.search(name):
                del model_params[name]

        # tracking remote model variable names
        self.federated_meta[remote_task_name].clear()
        self.federated_meta[remote_task_name].append(server_meta)
        self.federated_meta[remote_task_name].append(model_params)

        shared_fl_context.set_prop("model_vars", model_params, private=False)

    def close(self):
        """Clear up everything."""
        # if self.fitter is not None:
        #     self.fitter.close()
        pass
