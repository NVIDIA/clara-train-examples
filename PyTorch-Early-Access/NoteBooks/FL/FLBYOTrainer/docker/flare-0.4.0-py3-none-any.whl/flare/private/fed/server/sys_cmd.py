import json

import psutil
from dlmed.hci.conn import Connection
from dlmed.hci.reg import CommandModule, CommandModuleSpec, CommandSpec

from flare.security.authz import Action, FLAuthzContext
from flare.private.fed.server.admin import new_message


class SystemCommandModule(CommandModule):
    def __init__(self, allowed_commands=None):
        self.allowed_commands = allowed_commands

    def get_spec(self):
        return CommandModuleSpec(
            name="sys",
            cmd_specs=[
                CommandSpec(
                    name="sys_info",
                    description="get the system info",
                    usage="sys_info server/client <client-name>",
                    handler_func=self.sys_info,
                    authz_func=self.authorize_sys_info,
                    visible=True,
                ),
            ],
        )

    def authorize_sys_info(self, conn: Connection, args: [str]):
        if len(args) < 2:
            conn.append_error("syntax error: missing site names")
            return False, None

        dest = args[1]
        if dest == "server":
            return True, FLAuthzContext.new_authz_context(site_names=["server"], actions=[Action.OPERATE])
        elif dest == "client":
            sai = conn.app_ctx
            if len(args) == 2:
                clients = sai.get_all_clients()
                client_names = sai.get_all_client_names()
            else:
                clients, invalid_inputs = sai.get_all_tokens_from_inputs(args[2:])
                client_names, _ = sai.get_all_client_names_from_inputs(args[2:])
                if invalid_inputs:
                    conn.append_error("There's invalid clients: {}".format(" ".join(invalid_inputs)))
                    return False, None
            conn.set_prop("target_clients", clients)
            return True, FLAuthzContext.new_authz_context(site_names=client_names, actions=[Action.OPERATE])
        else:
            # conn.append_string("unknown command. Usage: start server/client ...")
            return True, None

    def sys_info(self, conn: Connection, args: [str]):
        if len(args) < 2:
            conn.append_error("syntax error: missing site names")
            return

        sai = conn.app_ctx
        dest = args[1]
        if dest == "server":
            infos = dict(psutil.virtual_memory()._asdict())

            table = conn.append_table(["Metrics", "Value"])

            for k, v in infos.items():
                table.add_row([str(k), str(v)])
            table.add_row(
                ["availabe_percent", "%.1f" % (psutil.virtual_memory().available * 100 / psutil.virtual_memory().total)]
            )
            return

        if dest == "client":
            message = new_message(conn, topic=args[0], body="")

            requests = {}
            clients = conn.get_prop("target_clients")

            for client in clients:
                requests.update({client.strip(): message})
            server = conn.server
            response = self.get_client_cmd_reply(sai, requests, server, conn)

            conn.append_string(response)
            return

        conn.append_string("unknown command. Usage: sys_info server/client <client-name>")

    def get_client_cmd_reply(self, sai, requests, server, conn):
        replies = server.send_requests(requests, timeout_secs=server.timeout)
        response = "No replies"
        if replies:
            response = ""
            for r in replies:
                conn.append_string("instance:" + sai.get_instance_name_from_token(r.client_name))

                if r.reply:
                    infos = json.loads(r.reply.body)
                    table = conn.append_table(["Metrics", "Value"])

                    for k, v in infos.items():
                        table.add_row([str(k), str(v)])
                    table.add_row(
                        [
                            "availabe_percent",
                            "%.1f" % (psutil.virtual_memory().available * 100 / psutil.virtual_memory().total),
                        ]
                    )
                else:
                    conn.append_string(": No replies")
        return response
