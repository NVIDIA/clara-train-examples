import time


class AggregateManager:
    def _is_valid_contribution(self, contribution_meta, server_meta):
        """
        check if the client submitted a valid contribution
        contribution meta should be for the current task and
        for the current round; matching server's model meta data.

        :param contrib_meta_data: Contribution message's meta data
        :return: the meta data if the contrib's meta data is valid,
            None otherwise.
        """
        # server_meta = self.model_meta_info
        if "{}".format(contribution_meta) == "{}".format(server_meta):
            return contribution_meta
        return None

    def is_current_round(self, client_contrib_id, contribution, server_meta) -> bool:
        model_meta = self._is_valid_contribution(contribution.client.meta, server_meta)
        if model_meta is None:
            return False
        else:
            return True

    def is_for_aggregate(self, server, accepted) -> bool:
        # Only the first one meets the minimum clients trigger the aggregation.
        if accepted and server.current_round_contributions == server.min_num_clients:
            if server.current_round_contributions < len(server.client_manager.get_clients()):
                time.sleep(server.wait_after_min_clients)
            return True
        return False
