from flare.private.fed.protos.admin_pb2 import Message as Proto_Message
from flare.utils.admin_defs import Message


def message_to_proto(message: Message) -> Proto_Message:
    protomessage = Proto_Message()
    protomessage.id = message.id
    protomessage.topic = message.topic
    if isinstance(message.body, str):
        protomessage.body_type = "str"
        protomessage.body = bytes(message.body, "utf-8")
    elif isinstance(message.body, bytes):
        protomessage.body_type = "bytes"
        protomessage.body = message.body
    else:
        protomessage.body_type = "unknown"
        protomessage.body = message.body

    for k, v in message.headers.items():
        protomessage.headers[k] = v
    return protomessage


def proto_to_message(proto: Proto_Message) -> Message:
    if proto.body_type == "str":
        message = Message(topic=proto.topic, body=proto.body.decode("utf-8"))
    elif proto.body_type == "bytes":
        message = Message(topic=proto.topic, body=proto.body)
    else:
        message = Message(topic=proto.topic)

    message.id = proto.id
    for k, v in proto.headers.items():
        message.headers[k] = v
    return message


if __name__ == "__main__":
    message = Message(topic="topic", body="{'id': 100}")
    message.set_header("Content-Type", "application/json")

    messageproto = message_to_proto(message)

    new_message = proto_to_message(messageproto)
    assert message == new_message
