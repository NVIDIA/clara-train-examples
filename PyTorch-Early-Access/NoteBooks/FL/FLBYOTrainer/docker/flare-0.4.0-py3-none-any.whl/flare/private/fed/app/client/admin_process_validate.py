"""Provides a command line interface for a federated client trainer"""

import argparse
import os
import sys
import time
import traceback
from multiprocessing.connection import Listener

from dlmed.utils.argument_utils import parse_vars

from flare.apis.fl_constant import FLConstants
from flare.private.fed.app.fl_conf import FLClientStarterConfiger
from flare.private.fed.client.client_executor import update_client_properties
from flare.private.fed.client.client_status import ClientStatus, get_status_message
from flare.utils.client_utils import read_client_info, get_mmar_root


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--workspace", "-m", type=str, help="WORKSPACE folder", required=True)

    parser.add_argument(
        "--fed_client", "-s", type=str, help="an aggregation server specification json file", required=True
    )

    parser.add_argument("--set", metavar="KEY=VALUE", nargs="*")

    parser.add_argument("--local_rank", type=int, default=0)
    args = parser.parse_args()
    kv_list = parse_vars(args.set)

    args.mmar = args.workspace
    args.train_config = 'config/config_train.json'
    args.val_config = 'config/config_train.json'
    config_folder = kv_list.get('config_folder', '')
    if config_folder == '':
        args.client_config = 'config_fed_client.json'
    else:
        args.client_config = config_folder + "/config_fed_client.json"
    args.env = "config/environment.json"
    args.log_config = None

    try:
        remove_restart_file(args)
    except BaseException:
        print("Could not remove the restart.fl / shutdown.fl file.  Please check your system before starting FL.")
        sys.exit(-1)

    restart_file = os.path.join(args.mmar, "restart.fl")
    if os.path.exists(restart_file):
        os.remove(restart_file)

    print("starting the client .....")

    trainer = None

    try:
        token, run_number, uid = read_client_info(mmar_root=args.mmar, client_file=FLConstants.CLIENT_TOKEN_FILE)
        workspace = '/tmp/fl/' + uid

        # trainer = WorkFlowFactory().create_client_trainer(train_configs, envs)
        conf = FLClientStarterConfiger(mmar_root=workspace,
                                       wf_config_file_name='config_train.json',
                                       client_config_file_name=args.fed_client,
                                       env_config_file_name='environment.json',
                                       log_config_file_name=workspace + '/log.config',
                                       kv_list=args.set)
        conf.configure()

        trainer = conf.base_trainer
        federated_client = trainer.create_fed_client()

        federated_client.token = token
        federated_client.uid = uid
        federated_client.fl_ctx.set_prop(FLConstants.CLIENT_NAME, uid, private=False)
        federated_client.fl_ctx.set_prop(FLConstants.FL_TOKEN, token, private=False)
        federated_client.fl_ctx.set_prop(FLConstants.WORKSPACE, args.workspace, private=False)

        mmar_root = get_mmar_root(args.mmar, run_number, uid)
        conf = FLClientStarterConfiger(mmar_root=mmar_root,
                                       wf_config_file_name=args.train_config,
                                       client_config_file_name=args.client_config,
                                       env_config_file_name=args.env,
                                       log_config_file_name=args.log_config,
                                       kv_list=args.set,
                                       local_rank=args.local_rank)
        # conf.configure()
        #
        # trainer = conf.trainer
        #
        # update_client_properties(federated_client, trainer)
        # # fl_trainer = create_fl_trainer(federated_client, trainer)
        federated_client.platform = conf.wf_config_data.get('platform', 'PT')
        #
        # # federated_client.admin_run(fl_trainer)
        # trainer.set_model_manager(federated_client.model_manager)

        conf.configure()
        trainer = conf.base_trainer

        cross_site_val_manager = trainer.create_cross_site_val_manager()
        federated_client.cross_site_val_manager = cross_site_val_manager

        # TODO(madil): This should use update_cross_val_properties to not use trainer elements.
        update_client_properties(federated_client, trainer)

        federated_client.status = ClientStatus.CROSS_SITE_VALIDATION
        # federated_client.handlers.extend(list(conf.fl_components))

        # # Start the thread for responding the inquire
        # thread = threading.Thread(target=listen_command, args=[federated_client])
        # thread.start()

        federated_client.fl_ctx.set_prop(FLConstants.ARGS, args)
        federated_client.fl_ctx.set_prop(FLConstants.MMAR_ROOT, mmar_root, private=True)
        federated_client.cross_validation(client_local_rank=0)

        federated_client.stop_listen = True

    except BaseException as e:
        traceback.print_exc()
        print("FL client execution exception: " + str(e))
    finally:
        if trainer:
            trainer.close()


def listen_command(client):
    address = ("localhost", 6000)  # family is deduced to be 'AF_INET'
    listener = Listener(address, authkey="client process secret password".encode())
    conn = listener.accept()

    client.stop_listen = False
    while not client.stop_listen:
        if conn.poll(1.0):
            msg = conn.recv()
            if msg == "check_status":
                conn.send(get_status_message(client.status))
                continue
            if msg == "abort":
                client.abort_signal.trigger_time = time.time()
                client.abort_signal.triggered = True
                continue
            if msg == "bye":
                conn.close()
                break
    listener.close()


def remove_restart_file(args):
    restart_file = os.path.join(args.mmar, "restart.fl")
    if os.path.exists(restart_file):
        os.remove(restart_file)
    restart_file = os.path.join(args.mmar, "shutdown.fl")
    if os.path.exists(restart_file):
        os.remove(restart_file)


if __name__ == "__main__":

    main()
