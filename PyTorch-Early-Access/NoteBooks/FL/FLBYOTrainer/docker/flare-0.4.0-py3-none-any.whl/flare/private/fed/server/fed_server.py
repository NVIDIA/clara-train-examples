"""federated server for aggregating and sharing federated model"""

import copy
from abc import abstractmethod
from flare.private.fed.server.server_cross_site_val_manager import ServerCrossSiteValManager

import logging
import threading
from concurrent import futures
from threading import Lock
import time

import grpc
from google.protobuf.struct_pb2 import Struct
from google.protobuf.timestamp_pb2 import Timestamp

import flare.private.fed.protos.admin_pb2 as admin_msg
import flare.private.fed.protos.admin_pb2_grpc as admin_service
import flare.private.fed.protos.federated_pb2 as fed_msg
import flare.private.fed.protos.federated_pb2_grpc as fed_service
from flare.apis.event_type import EventType
from flare.apis.filter import Filter
from flare.apis.fl_component import FLComponent, fire_event
from flare.apis.fl_constant import FLConstants, ShareableKey
from flare.apis.fl_context import FLContext
from flare.apis.shareable import Shareable
from flare.utils.fed_utils import GRPC_DEFAULT_OPTIONS
from ..utils.fed_utils import shareable_to_modeldata
from flare.private.fed.utils.messageproto import message_to_proto, proto_to_message
from .result_processor import ResultProcessor
from .server_status import ServerStatus
from flare.private.fed.utils.numproto import proto_to_bytes

from .aggregate_manager import AggregateManager
from .client_manager import ClientManager
from .server_model_manager import ServerModelManager


class BaseServer:
    def __init__(
        self,
        task_name=None,
        min_num_clients=2,
        max_num_clients=10,
        wait_after_min_clients=10,
        start_round=1,
        num_rounds=-1,
        heart_beat_timeout=600,
        handlers: [FLComponent] = None,
        cmd_modules=None,
    ):
        self.task_name = task_name  # should uniquely define a tlt workflow
        self.min_num_clients = max(min_num_clients, 1)
        self.max_num_clients = max(max_num_clients, 1)
        self.current_round = start_round
        self.num_rounds = num_rounds
        self.start_round = start_round

        self.heart_beat_timeout = heart_beat_timeout
        self.handlers = handlers
        self.cmd_modules = cmd_modules

        self.client_manager = ClientManager(
            task_name=self.task_name, min_num_clients=self.min_num_clients, max_num_clients=self.max_num_clients
        )

        self.grpc_server = None
        self.admin_server = None
        self.lock = Lock()
        self.fl_ctx = FLContext()
        # self.fl_ctx.set_prop("current_round", self.current_round)
        # self.app_ctx = ApplicationContext()
        self.platform = None
        self.server_cross_site_val_manager = ServerCrossSiteValManager()

        self.shutdown = False
        self.status = ServerStatus.TRAINING_NOT_STARTED

        self.logger = logging.getLogger(self.__class__.__name__)

    @property
    def should_stop(self):
        """
        num_rounds < 0 means non-stopping
        """
        return (self.num_rounds > 0) and (self.current_round >= self.num_rounds)

    def get_all_clients(self):
        return self.client_manager.get_clients()

    @abstractmethod
    def remove_client_data(self, token):
        pass

    def close(self):
        """
        shutdown the server.

        :return:
        """
        try:
            if self.lock:
                self.lock.release()
        except RuntimeError:
            self.logger.info("canceling sync locks")
        try:
            if self.grpc_server:
                self.grpc_server.stop(0)
            if self.handlers:
                for h in self.handlers:
                    h.shutdown(self.fl_ctx)
            # if self.admin_server:
            #     self.admin_server.stop()
        finally:
            self.logger.info("server off")
            return 0

    # def _create_admin_server(self, args=None, secure_train=False):
    #     sai = ServerAdminInterface(self)
    #     users = {}
    #     # cmd_modules = [ValidationCommandModule()]
    #
    #     root_cert = args['ssl_root_cert'] if secure_train else None
    #     server_cert = args['ssl_cert'] if secure_train else None
    #     server_key = args['ssl_private_key'] if secure_train else None
    #     admin_server = FedAdminServer(
    #                  fed_admin_interface=sai,
    #                  users=users,
    #                  cmd_modules=self.cmd_modules,
    #                  file_upload_dir='/tmp',
    #                  file_download_dir='/tmp',
    #                  allowed_shell_cmds=None,
    #                  host='localhost',
    #                  port=5005,
    #                  ca_cert_file_name=root_cert,
    #                  server_cert_file_name=server_cert,
    #                  server_key_file_name=server_key,
    #                  accepted_client_cns=None
    #     )
    #     return admin_server

    def deploy(self, grpc_args=None, secure_train=False):
        """
        start a grpc server and listening the designated port.
        :param fl_ctx:
        """
        num_server_workers = grpc_args.get("num_server_workers", 1)
        num_server_workers = max(self.client_manager.get_min_clients(), num_server_workers)
        target = grpc_args["service"].get("target", "0.0.0.0:6007")
        grpc_options = grpc_args["service"].get("options", GRPC_DEFAULT_OPTIONS)

        compression = grpc.Compression.NoCompression
        if "Deflate" == grpc_args.get("compression"):
            compression = grpc.Compression.Deflate
        elif "Gzip" == grpc_args.get("compression"):
            compression = grpc.Compression.Gzip

        if not self.grpc_server:
            self.grpc_server = grpc.server(
                futures.ThreadPoolExecutor(max_workers=num_server_workers),
                options=grpc_options,
                compression=compression,
            )
            fed_service.add_FederatedTrainingServicer_to_server(self, self.grpc_server)
            admin_service.add_AdminCommunicatingServicer_to_server(self, self.grpc_server)

        if secure_train:
            with open(grpc_args["ssl_private_key"], "rb") as f:
                private_key = f.read()
            with open(grpc_args["ssl_cert"], "rb") as f:
                certificate_chain = f.read()
            with open(grpc_args["ssl_root_cert"], "rb") as f:
                root_ca = f.read()

            server_credentials = grpc.ssl_server_credentials(
                (
                    (
                        private_key,
                        certificate_chain,
                    ),
                ),
                root_certificates=root_ca,
                require_client_auth=True,
            )
            self.grpc_server.add_secure_port(target, server_credentials)
            self.logger.info("starting secure server at %s", target)
        else:
            self.grpc_server.add_insecure_port(target)
            self.logger.info("starting insecure server at %s", target)
        self.grpc_server.start()

        # self.admin_server = self._create_admin_server(grpc_args, secure_train)
        # self.admin_server.start()

        # return self.start()
        cleanup_thread = threading.Thread(target=self.client_cleanup)
        # heartbeat_thread.daemon = True
        cleanup_thread.start()

    def client_cleanup(self):
        while not self.shutdown:
            self.remove_dead_clients()
            time.sleep(15)

    def set_admin_server(self, admin_server):
        self.admin_server = admin_server

    def start(self):
        try:
            # if self.handlers:
            #     for h in self.handlers:
            #         h.startup(self.fl_ctx)
            self.status = ServerStatus.TRAINING_STARTED

            self.logger.info("Server training has been started.")
            self.shutdown = False
            while not self.should_stop and not self.shutdown:
                # self.remove_dead_clients()

                time.sleep(3)

            fire_event(EventType.END_RUN, self.handlers, self.fl_ctx)

        except KeyboardInterrupt:
            pass
        except Exception as e:
            print(e)
        finally:
            # return self.close()
            self.status = ServerStatus.TRAINING_STOPPED

    def remove_dead_clients(self):
        # Clean and remove the dead client without heartbeat.
        self.logger.debug("trying to remove dead clients .......")
        delete = []
        for token, client in self.client_manager.get_clients().items():
            if client.heart_beat < time.time() - self.heart_beat_timeout:
                delete.append(token)
        for token in delete:
            client = self.client_manager.remove_client(token)
            # self.tokens.pop(token, None)
            self.remove_client_data(token)
            if self.admin_server:
                self.admin_server.client_dead(client.client_id)
            self.logger.info(
                "Remove the dead Client. Name: {}\t Token: {}.  Total clients: {}".format(
                    client.client_id, token, len(self.client_manager.get_clients())
                )
            )

    def fl_shutdown(self):
        self.shutdown = True
        self.close()


class FederatedServer(BaseServer, fed_service.FederatedTrainingServicer, admin_service.AdminCommunicatingServicer):
    """
    Federated model aggregation services
    """

    def __init__(
        self,
        task_name=None,
        min_num_clients=2,
        max_num_clients=10,
        wait_after_min_clients=10,
        start_round=1,
        num_rounds=-1,
        exclude_vars=None,
        model_log_dir=None,
        ckpt_preload_path=None,
        model_aggregator=None,
        model_saver=None,
        shareable_generator=None,
        outbound_filters: [Filter] = None,
        inbound_filters: [Filter] = None,
        cmd_modules=None,
        result_processors=[],
        heart_beat_timeout=600,
        handlers: [FLComponent] = None,
    ):
        """

        :param start_round: 0 indicates init. the global model randomly.
        :param min_num_clients: minimum number of contributors at each round.
        :param max_num_clients: maximum number of contributors at each round.
        """
        assert model_log_dir is not None, "model_log_dir must be specified to save checkpoint"

        self.logger = logging.getLogger("FederatedServer")

        BaseServer.__init__(
            self,
            task_name=task_name,
            min_num_clients=min_num_clients,
            max_num_clients=max_num_clients,
            wait_after_min_clients=wait_after_min_clients,
            start_round=start_round,
            num_rounds=num_rounds,
            heart_beat_timeout=heart_beat_timeout,
            handlers=handlers,
        )

        self.model_manager = ServerModelManager(
            start_round=start_round,
            num_rounds=num_rounds,
            exclude_vars=exclude_vars,
            model_log_dir=model_log_dir,
            ckpt_preload_path=ckpt_preload_path,
            model_aggregator=model_aggregator,
            model_saver=model_saver,
            shareable_generator=shareable_generator,
        )

        # self.accumulator = list()  # accumulating client's contributions
        self.contributed_clients = {}
        self.tokens = None
        self.round_started = Timestamp()

        # self.model_saver = model_saver

        with self.lock:
            self.reset_tokens()

        self.wait_after_min_clients = wait_after_min_clients

        self.outbound_filters = outbound_filters
        self.inbound_filters = inbound_filters
        self.cmd_modules = cmd_modules

        # #   For Tesing .....
        # from fed_learn.components.data_processor import ModelEncryptor, DataCompressor, DataDeCompressor, ModelDecryptor
        # self.outbound_filters = [ModelEncryptor(), DataCompressor()]
        # self.inbound_filters = [DataDeCompressor(), ModelDecryptor()]

        self.processors = {}
        for processor in result_processors:
            self.register_processor(processor)
        self.builder = None

        # Additional fields for CurrentModel meta_data in GetModel API.
        self.current_model_meta_data = {}
        # Decide whether it's allowed to call getModel multiple times within one round.
        self.allow_multi_call_get_model = False

        self.aggregate_manager = AggregateManager()
        self.current_round_contributions = 0

    def get_current_model_meta_data(self):
        """Get the model meta data, which usually contains additional fields"""
        s = Struct()
        for k, v in self.current_model_meta_data.items():
            s.update({k: v})
        return s

    @property
    def model_meta_info(self):
        """
        the model_meta_info uniquely defines the current model,
        it is used to reject outdated client's update.

        :return: model meta data object
        """
        if self.should_stop:
            return None
        meta_info = fed_msg.ModelMetaData()
        meta_info.created.CopyFrom(self.round_started)
        meta_info.current_round = self.current_round
        meta_info.num_rounds = self.num_rounds
        meta_info.task.name = self.task_name
        return meta_info

    def register_processor(self, processor: ResultProcessor):
        # assert isinstance(processor, ResultProcessor), 'processor must be ResultProcessor'

        topics = processor.get_topics()
        for topic in topics:
            assert topic not in self.processors, "duplicate processors for topic {}".format(topic)
            self.processors[topic] = processor

    def remove_client_data(self, token):
        self.tokens.pop(token, None)

    def reset_tokens(self):
        """
        restart the token set, so that each client can take a token
        and start fetching the current global model.
        This function is not thread-safe.
        """
        # last_time = self.round_started.seconds
        # self.round_started.GetCurrentTime()
        # now_time = self.round_started.seconds
        # reset_duration = now_time - last_time
        # self.logger.info("Round time: %s second(s).", reset_duration if reset_duration > 0 else "less than a")

        self.tokens = dict()
        for client in self.get_all_clients().keys():
            self.tokens[client] = self.model_meta_info
        self.current_round_contributions = 0
        # self.contributed_clients.clear()

    def set_builder(self, builder):
        self.builder = builder

    def Register(self, request, context):
        """
        register new clients on the fly.
        Each client must get registered before getting the global model.
        The server will expect updates from the registered clients
        for multiple federated rounds.

        This function does not change min_num_clients and max_num_clients.
        """
        fire_event(EventType.CLIENT_REGISTER, self.handlers, self.fl_ctx)

        token = self.client_manager.authenticate(request, context)
        if token:
            self.tokens[token] = self.model_meta_info
            if self.admin_server:
                self.admin_server.client_heartbeat(token)

            return fed_msg.FederatedSummary(comment="New client registered", token=token)

    def Quit(self, request, context):
        """
        existing client quits the federated training process.
        Server will stop sharing the global model with the client,
        further contribution will be rejected.

        This function does not change min_num_clients and max_num_clients.
        """
        fire_event(EventType.CLIENT_QUIT, self.handlers, self.fl_ctx)

        token = self.client_manager.validate_client(request, context)
        if token:
            client = self.client_manager.remove_client(token)
            self.tokens.pop(token, None)
            if self.admin_server:
                self.admin_server.client_dead(token)

        return fed_msg.FederatedSummary(comment="Removed client")

    def GetModel(self, request, context):
        """
        process client's request of the current global model
        """
        token = self.client_manager.validate_client(request, context)
        self.logger.info(f"GetModel requested from: {token}")
        if token is None:
            return None

        if self.status == ServerStatus.TRAINING_STOPPED:
            context.abort(grpc.StatusCode.OUT_OF_RANGE, "Server training stopped")

        if self.status != ServerStatus.TRAINING_STARTED:
            context.abort(grpc.StatusCode.RESOURCE_EXHAUSTED, "No token available for the current round")
            return

        model_meta_info = None
        if self.allow_multi_call_get_model:
            # We allow this GetModel API to be called by multiple times.
            model_meta_info = self.tokens.get(token, None)
        else:
            # We allow this GetModel API to be called only once for each client per round.
            model_meta_info = self.tokens.pop(token, None)

        if model_meta_info is None:
            # no more tokens for this round
            context.abort(grpc.StatusCode.RESOURCE_EXHAUSTED, "No token available for the current round")

        with self.lock:
            fire_event(EventType.GET_MODEL, self.handlers, self.fl_ctx)

            shareable = self.model_manager.get_shareable(self.fl_ctx)
            shareable_copy = copy.deepcopy(shareable)

            # ctx_copy = self.fl_ctx.clone()
            if self.outbound_filters:
                for t in self.outbound_filters:
                    shareable_copy = t.process(shareable_copy, self.fl_ctx)

            model = fed_msg.CurrentModel()
            model.meta.CopyFrom(model_meta_info)
            meta_data = self.get_current_model_meta_data()
            meta_data.update({FLConstants.PEER_CONTEXT: self.fl_ctx.get_all_public_props()})

            # meta_data.update({'shareable_dict': self._get_shareable_without_weights(shareable_copy)})

            model.meta_data.CopyFrom(meta_data)

            # fetch current global model
            # weights_dict = shareable_copy[ShareableKey.WEIGHTS_DICT]
            # current_model = self.model_manager.shareable_generator.shareable_to_modeldata(weights_dict)
            current_model = shareable_to_modeldata(shareable_copy)
            model.data.CopyFrom(current_model)
            self.logger.info(f"Return model to : {token} for round: {self.current_round}")
            return model

    def _get_shareable_without_weights(self, shareable):
        data = {}
        for k, v in shareable.items():
            if not k == ShareableKey.WEIGHTS_DICT:
                data[k] = v
        return data

    def SubmitUpdate(self, request, context):
        """
        handling client's submission of the federated updates
        running aggregation if there are enough updates
        """
        if self.status == ServerStatus.TRAINING_STOPPED or \
                self.status == ServerStatus.TRAINING_NOT_STARTED:
            context.abort(grpc.StatusCode.OUT_OF_RANGE,
                          'Server training stopped')
            return

        contribution = request

        token = self.client_manager.validate_client(contribution.client, context)
        if token is None:
            response_comment = "Ignored the submit from invalid client. "
            self.logger.info(response_comment)
        else:

            # if len(self.accumulator) > self.client_manager.get_min_clients():
            #     context.abort(grpc.StatusCode.ALREADY_EXISTS,
            #                   'Contrib: already enough in the current round')

            with self.lock:
                fire_event(EventType.RECEIVE_CONTRIBUTION, self.handlers, self.fl_ctx)

                contribution_ctx = FLContext()
                contribution_ctx.set_model(request.data)
                meta_data = {q: v for q, v in request.meta_data.items()}
                contribution_ctx.set_public_props(meta_data)
                contribution_ctx.set_prop("_contribution", request)

                shareable = Shareable()
                shared_fl_context = FLContext()
                # shareable.update({k: proto_to_ndarray(v) for k, v in request.data.params.items()})

                shareable = shareable.from_bytes(proto_to_bytes(request.data.params["data"]))

                for key, value in meta_data.items():
                    shared_fl_context.set_prop(key, value, private=False)

                shared_fl_context.set_prop(FLConstants.CLIENT_NAME, request.client.uid, private=False)
                shared_fl_context.set_prop(FLConstants.NUM_STEPS_CURRENT_ROUND, request.n_iter, private=False)
                shared_fl_context.set_prop(FLConstants.CURRENT_ROUND, request.client.meta.current_round, private=False)

                self.fl_ctx.set_prop(FLConstants.PEER_CONTEXT, shared_fl_context)
                if self.inbound_filters:
                    for t in self.inbound_filters:
                        shareable = t.process(shareable, self.fl_ctx)

                shared_fl_context.set_prop(FLConstants.SHAREABLE, shareable, private=False)

                # contribution_meta = self.is_valid_contribution(contribution.client.meta)
                # if contribution_meta is None:
                #     context.abort(grpc.StatusCode.FAILED_PRECONDITION,
                #                   'Contrib: invalid for the current round')
                #     response_comment = 'Invalid contribution. '
                #     self.logger.info(response_comment)
                # else:

                contribution_meta = contribution.client.meta
                client_contrib_id = "{}_{}_{}".format(
                    contribution_meta.task.name, token, contribution_meta.current_round
                )

                timenow = Timestamp()
                timenow.GetCurrentTime()
                time_seconds = timenow.seconds - self.round_started.seconds
                self.logger.info(
                    "received %s (%s Bytes, %s seconds)",
                    client_contrib_id,
                    contribution.ByteSize(),
                    time_seconds or "less than 1",
                )
                # print('Received model from client: {} for round: {}'.format(client_contrib_id, self.current_round))

                fire_event(EventType.BEFORE_ACCEPT, self.handlers, self.fl_ctx)

                trigger_aggregate = False
                if self.save_contribution(client_contrib_id, contribution):
                    # with self.lock:
                    # self.fl_ctx.set_prop("contribution_round", contribution_meta.current_round)
                    contribution_round = shared_fl_context.get_prop(FLConstants.CURRENT_ROUND)
                    accepted, trigger_aggregate = self.model_manager.accept(shareable, self.fl_ctx)
                    if accepted:
                        if request.client.uid in self.contributed_clients.keys():
                            contribution_count = self.contributed_clients[request.client.uid]["contribution_count"]
                            contribution_count += 1
                        else:
                            contribution_count = 1
                        self.contributed_clients[request.client.uid] = {
                            "last_round": contribution_round,
                            "contribution_count": contribution_count,
                        }
                        # self.accumulator.append(contribution_ctx)
                        # self.fl_ctx.set_prop('all_contributions', self.accumulator)
                        # if self.get_enough_updates():
                        #     self.aggregate()
                        # if self.aggregate_manager.is_current_round(client_contrib_id, contribution, self.model_meta_info):
                        if contribution_round == self.current_round:
                            self.current_round_contributions += 1
                        else:
                            response_comment = "contribution not for the current round: {} ".format(client_contrib_id)
                            self.logger.info(response_comment)

                    fire_event(EventType.AFTER_ACCEPT, self.handlers, self.fl_ctx)

            # Only the first one meets the minimum clients trigger the aggregation.
            # if self.current_round_contributions == self.min_num_clients:
            #     if self.current_round_contributions < len(self.client_manager.get_clients()):
            #         time.sleep(self.wait_after_min_clients)
            if trigger_aggregate or self.aggregate_manager.is_for_aggregate(self, accepted):
                with self.lock:
                    aggregate_start = time.time()
                    self.aggregate()
                    aggregate_end = time.time()
                    self.logger.info(
                        "Aggregation time for the round {} : {} seconds.".format(
                            self.current_round-1, aggregate_end - aggregate_start
                        )
                    )

        response_comment = "Received round {} from {} ({} Bytes, {} seconds)".format(
            contribution.client.meta.current_round,
            contribution.client.uid,
            contribution.ByteSize(),
            time_seconds or "less than 1",
        )
        summary_info = fed_msg.FederatedSummary(comment=response_comment)
        if self.model_meta_info is not None:
            summary_info.meta.CopyFrom(self.model_meta_info)
        return summary_info

    def SubmitBestLocalModel(self, request, context):
        """Receive the best local model from clients."""
        client = request.client

        token = self.client_manager.validate_client(client, context)
        with self.lock:
            response_comment = self.server_cross_site_val_manager.accept_model(token, request, self.fl_ctx)

        summary_info = fed_msg.FederatedSummary(comment=response_comment)
        return summary_info

    def SubmitCrossSiteValidationResults(self, request, context):
        """Get the cross validation results from client."""
        send_client = request.client

        # Extract shareable from request
        shareable = Shareable.from_bytes(request.shareable)

        token = self.client_manager.validate_client(send_client, context)
        with self.lock:
            response = self.server_cross_site_val_manager.accept_validation_results(shareable, token, self.fl_ctx)

        summary_info = fed_msg.FederatedSummary(comment=response)
        return summary_info

    def GetValidationModels(self, request, context):
        """Send validation models to server."""
        # Check that client is valid
        client = request
        token = self.client_manager.validate_client(client, context)

        if token is None:
            response_comment = "Ignored model request from invalid client."
            self.logger.info(response_comment)

            summary_info = fed_msg.FederatedSummary(comment=response_comment)
            return summary_info
        else:
            with self.lock:
                return self.server_cross_site_val_manager.get_model_for_validation(client, token, self.status, self.fl_ctx)

    def Heartbeat(self, request, context):
        token = request.token
        client_id = ""
        cn_names = context.auth_context().get("x509_common_name")
        if cn_names:
            client_id = cn_names[0].decode("utf-8")

        if self.client_manager.heartbeat(token, client_id, context):
            self.tokens[token] = self.model_meta_info
            if self.admin_server:
                self.admin_server.client_heartbeat(token)

        summary_info = fed_msg.FederatedSummary()
        return summary_info

    def Retrieve(self, request, context):
        client_name = request.client_name
        messages = self.admin_server.get_outgoing_requests(client_name=client_name) if self.admin_server else []

        response = admin_msg.Messages()
        # response.message.CopyFrom(messages)
        for m in messages:
            # message = response.message.add()
            response.message.append(message_to_proto(m))
        return response

    def SendReply(self, request, context):
        client_name = request.client_name
        message = proto_to_message(request.message)
        if self.admin_server:
            self.admin_server.accept_reply(client_name=client_name, reply=message)

        response = admin_msg.Empty()
        return response

    def SendResult(self, request, context):
        client_name = request.client_name
        message = proto_to_message(request.message)

        processor = self.processors.get(message.topic)
        processor.process(client_name, message)

        response = admin_msg.Empty()
        return response

    def save_contribution(self, client_contrib_id, data):
        """
        save the client's current contribution.

        :return: True iff it is successfully saved
        """
        return True

    def aggregate(self):
        """
        invoke model aggregation using the accumulator's content,
        then reset the tokens and accumulator.

        :return:
        """
        self.fl_ctx.set_prop(FLConstants.CURRENT_ROUND, self.current_round)
        fire_event(EventType.BEFORE_AGGREGATION, self.handlers, self.fl_ctx)
        self.logger.info("> aggregating: %s", self.current_round)
        self.model_manager.update_model(self.handlers, self.fl_ctx)

        self.current_round += 1
        self.current_round_contributions = 0
        self.fl_ctx.set_prop(FLConstants.CURRENT_ROUND, self.current_round)
        self.reset_tokens()
        # self.accumulator.clear()
        # self.contributed_clients.clear()

        fire_event(EventType.END_AGGREGATION, self.handlers, self.fl_ctx)

        last_time = self.round_started.seconds
        self.round_started.GetCurrentTime()
        now_time = self.round_started.seconds
        reset_duration = now_time - last_time
        self.logger.info("Round time: %s second(s).", reset_duration if reset_duration > 0 else "less than a")

    # def is_valid_contribution(self, contrib_meta_data):
    #     """
    #     check if the client submitted a valid contribution
    #     contribution meta should be for the current task and
    #     for the current round; matching server's model meta data.
    #
    #     :param contrib_meta_data: Contribution message's meta data
    #     :return: the meta data if the contrib's meta data is valid,
    #         None otherwise.
    #     """
    #     server_meta = self.model_meta_info
    #     if '{}'.format(contrib_meta_data) == '{}'.format(server_meta):
    #         return contrib_meta_data
    #     return None

    def start(self):
        self.status = ServerStatus.TRAINING_STARTING
        # build_ctx = self.builder.build()
        # # assert isinstance(build_ctx, BuildContext)
        # # with builder.graph.as_default():
        # with build_ctx.get('_graph').as_default():
        #     # only use the first server
        #     if self.model_saver:
        #         self.model_saver.initialize()
        #
        # self.fl_ctx = FLContext()
        fire_event(EventType.START_RUN, self.handlers, self.fl_ctx)
        self.fl_ctx.set_prop("task_name", self.task_name, private=False)
        self.fl_ctx.set_prop(FLConstants.WAIT_AFTER_MIN_CLIENTS, self.wait_after_min_clients, private=False)
        self.current_round = self.start_round
        self.round_started.GetCurrentTime()

        self.fl_ctx.set_prop("builder", self.builder)
        self.model_manager.initialize(self.fl_ctx)
        self.fl_ctx.set_model(self.model_manager.model)
        # self.fl_ctx.set_prop("model_log_dir", self.model_saver.model_log_dir)
        self.fl_ctx.set_prop(FLConstants.CURRENT_ROUND, self.current_round)
        self.fl_ctx.set_prop(FLConstants.START_ROUND, self.start_round)

        # Cross validation init
        # self.fl_ctx.set_prop('model_log_dir', self.model_saver.model_log_dir)
        self.server_cross_site_val_manager.initialize(self.fl_ctx, self.handlers, self.admin_server)

        return super().start()

    def stop_training(self):
        self.logger.info("Stopping server training...")
        try:
            if self.model_manager:
                self.model_manager.close()

            # if self.model_saver:
            #     self.model_saver.close()

            self.reset_tokens()
            self.contributed_clients.clear()
            # self.accumulator.clear()

            self.status = ServerStatus.TRAINING_STOPPED
            # self.admin_server.stop()
        except RuntimeError:
            self.logger.info("closing model manager")

    def close(self):
        """
        shutdown the server.

        :return:
        """
        self.logger.info("shutting down server")
        try:
            if self.model_manager:
                self.model_manager.close()
            # self.admin_server.stop()
        except RuntimeError:
            self.logger.info("closing model manager")

        return super().close()
