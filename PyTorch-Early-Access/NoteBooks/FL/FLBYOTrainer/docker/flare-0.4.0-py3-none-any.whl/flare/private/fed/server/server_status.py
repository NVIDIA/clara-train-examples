class ServerStatus(object):
    TRAINING_NOT_STARTED = 0
    TRAINING_STARTING = 1
    TRAINING_STARTED = 2
    TRAINING_STOPPED = 3
    # TRAINING_COMPLETED = 4

    status_messages = {
        TRAINING_NOT_STARTED: "training not started",
        TRAINING_STARTING: "training starting",
        TRAINING_STARTED: "training started",
        TRAINING_STOPPED: "training stopped",
        # TRAINING_COMPLETED: "completed",
    }


def get_status_message(status):
    return ServerStatus.status_messages.get(status)
