"""The client of the federated training process"""
from flare.private.fed.crossvalidation.utils import get_model_registry_path
import threading
import traceback

from flare.apis import EventType, Filter, FLComponent, FLContext, ModelProcessor
from flare.apis.fl_component import FLComponent, fire_event
from flare.apis.fl_constant import CrossValConstants, FLConstants, ShareableKey
from flare.apis.shareable import Shareable
from flare.utils.fed_utils import generate_failure
from flare.private.fed.utils.numproto import proto_to_bytes
from flare.private.fed.crossvalidation.utils import get_model_registry_path

from .client_status import ClientStatus
from .fed_client_base import FederatedClientBase


class FederatedClient(FederatedClientBase):
    """
    Federated client-side implementation.
    """

    def __init__(
        self,
        client_id,
        client_args,
        secure_train,
        # data_assembler,
        server_args=None,
        exclude_vars=None,
        privacy=None,
        retry_timeout=30,
        model_reader_writer: ModelProcessor = None,
        outbound_filters: [Filter] = None,
        inbound_filters: [Filter] = None,
        client_state_processors: [Filter] = None,
        req_processors=None,
        handlers: [FLComponent] = None,
        compression=None,
    ):
        # We call the base implementation directly.
        super().__init__(
            client_id=client_id,
            client_args=client_args,
            secure_train=secure_train,
            server_args=server_args,
            exclude_vars=exclude_vars,
            privacy=privacy,
            retry_timeout=retry_timeout,
            model_reader_writer=model_reader_writer,
            outbound_filters=outbound_filters,
            inbound_filters=inbound_filters,
            client_state_processors=client_state_processors,
            req_processors=req_processors,
            handlers=handlers,
            compression=compression,
        )

        self.inbound_filters = inbound_filters
        self.remote_models = None

    def federated_step(self, trainer):
        """
        Run a federated step.
        """
        # fitter = trainer.get_fitter()

        fire_event(EventType.BEFORE_PULL_MODEL, self.handlers, self.fl_ctx)
        client_local_rank = self.fl_ctx.get_prop(FLConstants.MY_RANK, 0)
        if client_local_rank == 0:
            pull_success = self.pull_models()
        else:
            pull_success = False
        fire_event(EventType.AFTER_PULL_MODEL, self.handlers, self.fl_ctx)

        print("pull_models completed. Status:{} rank:{}".format(pull_success, client_local_rank))
        multi_gpu = self.fl_ctx.get_prop(FLConstants.MULTI_GPU)
        if multi_gpu:
            with threading.Lock():
                if self.platform == "PT":
                    import torch
                    import torch.distributed as dist

                    device = self.fl_ctx.get_prop(FLConstants.DEVICE)
                    pull_success = torch.as_tensor(int(pull_success), device=device)
                    train_end = torch.as_tensor(int(self.train_end), device=device)
                    dist.broadcast(pull_success, src=0)
                    dist.broadcast(train_end, src=0)
                    pull_success = bool(pull_success)
                    self.train_end = bool(train_end)

                    # dist.broadcast(self.remote_models, src=0)
                else:
                    from mpi4py import MPI

                    comm = MPI.COMM_WORLD
                    pull_success = comm.bcast(pull_success, root=0)
                    self.train_end = comm.bcast(self.train_end, root=0)

        if pull_success:  # pull models from multiple servers

            shareable = Shareable()
            if client_local_rank == 0:
                shareable = self.extract_shareable()

                # self.fl_ctx.set_prop('remote_models', self.remote_models)
                # self.model_manager.assign_current_model(self.remote_models)

                model_weights = shareable[ShareableKey.MODEL_WEIGHTS]
                self.model_manager.track_remote_model(model_weights, self.server_meta, self.fl_ctx)

            # if multi_gpu:
            #     if self.platform == "PT":
            #         import torch.distributed as dist
            #
            #         net = self.fl_ctx.get_prop(FLConstants.MODEL_NETWORK)
            #         for _, v in net.state_dict().items():
            #             dist.broadcast(v, src=0)
            #     else:
            #         import horovod.tensorflow as hvd
            #
            #         hvd.broadcast_global_variables(root_rank=0)

            try:
                fire_event(EventType.BEFORE_TRAIN, self.handlers, self.fl_ctx)
                self.fl_ctx.set_prop(FLConstants.PLATFORM, self.platform, private=True)
                self.shareable = trainer.train(shareable, self.fl_ctx, self.abort_signal)  # do local fitting
                fire_event(EventType.AFTER_TRAIN, self.handlers, self.fl_ctx)
            except Exception as e:
                self.shareable = generate_failure(self.fl_ctx, "Client Train exception")
                traceback.print_exc()
            finally:
                if client_local_rank == 0:
                    print("Send model to server.")
                    self.push_models()  # push models

    def extract_shareable(self):
        shareable = Shareable()
        sharted_fl_context = FLContext()
        # meta = list()
        for item in self.remote_models:
            meta_data = {
                q: v for q, v in {q: v for q, v in item.meta_data.items()}.get(FLConstants.PEER_CONTEXT).items()
            }
            for key, value in meta_data.items():
                sharted_fl_context.set_prop(key, value)

            # shareable.update({k: proto_to_ndarray(v) for k, v in item.data.params.items()})
            shareable = shareable.from_bytes(proto_to_bytes(item.data.params["data"]))

            # sharted_fl_context.set_prop("model_meta", item.meta)

        self.fl_ctx.set_prop(FLConstants.CURRENT_ROUND, self.remote_models[0].meta.current_round, private=False)

        self.fl_ctx.set_prop(FLConstants.PEER_CONTEXT, sharted_fl_context, private=True)
        if self.inbound_filters:
            for t in self.inbound_filters:
                shareable = t.process(shareable, self.fl_ctx)

        return shareable

    def run_federated_steps(self, fl_trainer, mmar_root, args):
        """
        Keep running federated steps.
        """
        # self.fl_ctx.set_prop(FLConstants.FEDERATE_CLIENT, self)
        self.fl_ctx.set_prop(FLConstants.TRAIN_ROOT, mmar_root)
        self.fl_ctx.set_prop(FLConstants.ARGS, args)
        self.fl_ctx.set_prop(FLConstants.IS_FIRST_ROUND, True, private=False)
        fire_event(EventType.START_RUN, self.handlers, self.fl_ctx)

        while not self.train_end:
            fire_event(EventType.START_ROUND, self.handlers, self.fl_ctx)
            # fl_trainer.initialize(self.fl_ctx)
            self.status = ClientStatus.TRAINING_STARTED

            # fire_event(EventType.AFTER_INITIALIZE, self.handlers, self.fl_ctx)
            self.federated_step(fl_trainer)
            self.fl_ctx.set_prop(FLConstants.IS_FIRST_ROUND, False, private=False)
            fire_event(EventType.END_ROUND, self.handlers, self.fl_ctx)

            # Save model registry at end of round
            self.save_model_registry()

        fire_event(EventType.END_RUN, self.handlers, self.fl_ctx)

    def save_model_registry(self):
        mmar_root = self.fl_ctx.get_prop(FLConstants.TRAIN_ROOT)
        ml_model_registry = self.fl_ctx.get_prop(CrossValConstants.ML_MODEL_REGISTRY)
        if not mmar_root:
            self.logger.info("Model registry can't be saved because no TRAIN_ROOT in context.")
            return
        if not ml_model_registry:
            self.logger.info("Model Registry object empty in fl context.")
            return
        try:
            model_registry_file = get_model_registry_path(mmar_root)
            if ml_model_registry._content_updated:
                open(model_registry_file, "wb").write(ml_model_registry.to_bytes())
                ml_model_registry._content_updated = False
        except BaseException:
            self.logger.info("Exception in saving model registry")
            traceback.print_exc()

    def cross_validation(self, client_local_rank):
        self.status = ClientStatus.CROSS_SITE_VALIDATION
        if self.cross_site_val_manager:
            success = self.cross_site_val_manager.initialize(self.fl_ctx)
            self.push_best_models()
            if success:
                self.run_cross_site_validation()
        else:
            self.logger.info("ClientCrossSiteValManager not found. Cross validation exiting.")
        self.status = ClientStatus.TRAINING_STOPPED

    def abort(self):
        """Abort cross site validation. Training is run in client_executor and aborted there."""
        try:
            if self.status == ClientStatus.CROSS_SITE_VALIDATION:
                if self.cross_site_val_manager:
                    self.cross_site_val_manager.terminate()
                self.status = ClientStatus.TRAINING_STOPPED
        except Exception:
            traceback.print_exc()

    def admin_run(self, fl_trainer, mmar_root, args):
        try:
            self.status = ClientStatus.TRAINING_STARTING
            self.run_federated_steps(fl_trainer, mmar_root, args)

        except Exception:
            self.status = ClientStatus.TRAINING_EXCEPTION
            traceback.print_exc()
        finally:
            self.train_end = True
            self.model_manager.close()
