"""Provides a command line interface for a federated client trainer"""

import argparse
import os
import shutil
import sys
import time

from dlmed.common.excepts import ConfigError, ErrorHandled
from dlmed.hci.server.authz import AuthorizationService
from dlmed.sec.audit import AuditService
from dlmed.sec.security_content_service import LoadResult, SecurityContentService
from dlmed.utils.argument_utils import parse_vars

from flare.private.fed.app.fl_conf import FLClientStarterConfiger
from flare.private.fed.client.admin import FedAdminAgent
from flare.private.fed.client.admin_msg_sender import AdminMessageSender
from flare.private.fed.client.cai import ClientAdminInterface
from flare.security.authz import FLAuthorizer


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--workspace", "-m", type=str, help="WORKSPACE folder", required=True)

    parser.add_argument(
        "--fed_client", "-s", type=str, help="an aggregation server specification json file", required=True
    )

    parser.add_argument("--set", metavar="KEY=VALUE", nargs="*")

    parser.add_argument("--local_rank", type=int, default=0)

    args = parser.parse_args()
    kv_list = parse_vars(args.set)

    args.mmar = args.workspace
    args.train_config = "config/config_train.json"
    config_folder = kv_list.get("config_folder", "")
    if config_folder == "":
        args.client_config = "config_fed_client.json"
    else:
        args.client_config = config_folder + "/config_fed_client.json"
    args.env = "config/environment.json"
    args.log_config = None

    try:
        remove_restart_file(args)
    except BaseException:
        print("Could not remove the restart.fl / shutdown.fl file.  Please check your system before starting FL.")
        sys.exit(-1)

    # multi_gpu = kv_list.get('multi_gpu', False)
    # if multi_gpu:
    #     multi_gpu_init()
    #     rank = multi_gpu_get_rank()
    # else:
    #     rank = 0
    rank = args.local_rank

    try:
        os.chdir(args.workspace)
        AuditService.initialize(audit_file_name="audit.log")

        if rank == 0:
            workspace = create_workspace(args)
        time.sleep(rank * 2)

        # initialize the SecurityContentService.
        # must do this before initializing other services since it may be needed by them!
        startup = os.path.join(args.workspace, "startup")
        SecurityContentService.initialize(content_folder=startup)

        insecure_list = secure_content_check(args)
        if len(insecure_list):
            print("The following files are not secure content.")
            for item in insecure_list:
                print(item)
            sys.exit(1)

        # initialize the AuditService, which is used by command processing.
        # The Audit Service can be used in other places as well.
        AuditService.initialize(audit_file_name="audit.log")

        # Initialize the AuthorizationService. It is used by command authorization
        # We use FLAuthorizer for policy processing.
        # AuthorizationService depends on SecurityContentService to read authorization policy file.
        AuthorizationService.initialize(FLAuthorizer())

        # trainer = WorkFlowFactory().create_client_trainer(train_configs, envs)
        conf = FLClientStarterConfiger(
            mmar_root=workspace,
            wf_config_file_name="config_train.json",
            client_config_file_name=args.fed_client,
            env_config_file_name="environment.json",
            log_config_file_name=workspace + "/log.config",
            kv_list=args.set,
            local_rank=args.local_rank,
        )
        conf.configure()

        trainer = conf.base_trainer
        federated_client = trainer.create_fed_client()
        federated_client.platform = conf.wf_config_data.get('platform', 'PT')
        federated_client.use_gpu = conf.use_gpu
        # federated_client.cross_site_validate = kv_list.get("cross_site_validate", True)
        federated_client.config_folder = config_folder

        if rank == 0:
            federated_client.register()

        if not federated_client.token:
            print("The client could not register to server. ")
            raise RuntimeError("Login failed.")

        # if trainer.multi_gpu:
        #     from mpi4py import MPI
        #
        #     comm = MPI.COMM_WORLD
        #     federated_client.token = comm.bcast(federated_client.token, root=0)

        federated_client.start_heartbeat()

        servers = [{t["name"]: t["service"]} for t in trainer.server_config]

        admin_agent = create_admin_agent(
            trainer.client_config,
            trainer.uid,
            trainer.req_processors,
            trainer.secure_train,
            sorted(servers)[0],
            federated_client,
            args,
            trainer.multi_gpu,
            rank,
        )
        admin_agent.start()

        trainer.close()

    except ConfigError as ex:
        print("ConfigError:", str(ex))
    except ErrorHandled as ex:
        print("ErrorHandled:", str(ex))
        pass
    finally:
        # shutil.rmtree(workspace)
        pass

    sys.exit(0)


def secure_content_check(args):
    insecure_list = []
    data, sig = SecurityContentService.load_json(args.fed_client)
    if sig != LoadResult.OK:
        insecure_list.append(args.fed_client)

    client = data["client"]
    content, sig = SecurityContentService.load_content(client.get("ssl_cert"))
    if sig != LoadResult.OK:
        insecure_list.append(client.get("ssl_cert"))
    content, sig = SecurityContentService.load_content(client.get("ssl_private_key"))
    if sig != LoadResult.OK:
        insecure_list.append(client.get("ssl_private_key"))
    content, sig = SecurityContentService.load_content(client.get("ssl_root_cert"))
    if sig != LoadResult.OK:
        insecure_list.append(client.get("ssl_root_cert"))

    return insecure_list


def remove_restart_file(args):
    restart_file = os.path.join(args.mmar, "restart.fl")
    if os.path.exists(restart_file):
        os.remove(restart_file)
    restart_file = os.path.join(args.mmar, "shutdown.fl")
    if os.path.exists(restart_file):
        os.remove(restart_file)


def create_workspace(args):
    kv_vars = parse_vars(args.set)
    workspace = '/tmp/fl/' + kv_vars.get('uid')

    if os.path.exists(workspace):
        shutil.rmtree(workspace)
    startup = os.path.join(args.workspace, "startup")
    shutil.copytree(startup, workspace)

    with open(workspace + "/config_train.json", "wt") as f:
        f.write(
            r'{"epochs":1260,"multi_gpu":false,"train":{"loss":{"name":"DiceLoss","args":{"to_onehot_y":true,"softmax":true}},"optimizer":{"name":"Adam","args":{"lr":0.0002}},"lr_scheduler":{"name":"StepLR","args":{"step_size":5000,"gamma":0.1}},"model":{"name":"UNet","args":{"dimensions":3,"in_channels":1,"out_channels":2,"channels":[16,32,64,128,256],"strides":[2,2,2,2],"num_res_units":2,"norm":"batch"}},"pre_transforms":[{"name":"LoadImaged","args":{"keys":["image","label"]}},{"name":"AddChanneld","args":{"keys":["image","label"]}},{"name":"ScaleIntensityRanged","args":{"keys":"image","a_min":-57,"a_max":164,"b_min":0,"b_max":1,"clip":true}},{"name":"RandCropByPosNegLabeld","args":{"keys":["image","label"],"label_key":"label","spatial_size":[96,96,96],"pos":1,"neg":1,"num_samples":4,"image_key":"image","image_threshold":0}},{"name":"RandShiftIntensityd","args":{"keys":"image","offsets":0.1,"prob":0.5}},{"name":"ToTensord","args":{"keys":["image","label"]}}],"dataset":{"name":"CacheDataset","args":{"cache_num":32,"cache_rate":1,"num_workers":4}},"dataloader":{},"inferer":{"name":"SimpleInferer"},"handlers":[{"name":"LrScheduleHandler","args":{"print_lr":true}},{"name":"ValidationHandler","args":{"interval":20,"epoch_level":true}},{"name":"StatsHandler","rank":0,"args":{"tag_name":"train_loss","output_transform":""}},{"name":"TensorBoardStatsHandler","rank":0,"args":{"log_dir":"{MMAR_CKPT_DIR}","tag_name":"train_loss","output_transform":""}},{"name":"CheckpointSaver","rank":0,"args":{"save_dir":"{MMAR_CKPT_DIR}","save_dict":["model","optimizer","lr_scheduler"],"save_interval":400}}],"post_transforms":[{"name":"Activationsd","args":{"keys":"pred","softmax":true}},{"name":"AsDiscreted","args":{"keys":["pred","label"],"argmax":[true,false],"to_onehot":true,"n_classes":2}}],"metrics":[{"name":"Accuracy","log_label":"train_acc","is_key_metric":true,"args":{"output_transform":""}}],"trainer":{"name":"SupervisedTrainer"}},"validate":{"pre_transforms":[{"name":"LoadImaged","args":{"keys":["image","label"]}},{"name":"AddChanneld","args":{"keys":["image","label"]}},{"name":"ScaleIntensityRanged","args":{"keys":"image","a_min":-57,"a_max":164,"b_min":0,"b_max":1,"clip":true}},{"name":"CropForegroundd","args":{"keys":["image","label"],"source_key":"image"}},{"name":"ToTensord","args":{"keys":["image","label"]}}],"dataset":{"name":"CacheDataset","args":{"cache_num":9,"cache_rate":1,"num_workers":4}},"dataloader":{"name":"DataLoader","args":{"batch_size":1,"shuffle":false,"num_workers":4}},"inferer":{"name":"SlidingWindowInferer","args":{"roi_size":[160,160,160],"sw_batch_size":4,"overlap":0.5}},"handlers":[{"name":"StatsHandler","rank":0,"args":{"output_transform":"lambda x: None"}},{"name":"TensorBoardStatsHandler","rank":0,"args":{"log_dir":"{MMAR_CKPT_DIR}","output_transform":"lambda x: None"}},{"name":"CheckpointSaver","rank":0,"args":{"save_dir":"{MMAR_CKPT_DIR}","save_dict":["model"],"save_key_metric":true}}],"post_transforms":[{"name":"Activationsd","args":{"keys":"pred","softmax":true}},{"name":"AsDiscreted","args":{"keys":["pred","label"],"argmax":[true,false],"to_onehot":true,"n_classes":2}}],"metrics":[{"name":"MeanDice","log_label":"val_mean_dice","is_key_metric":true,"args":{"include_background":false,"output_transform":""}},{"name":"Accuracy","log_label":"val_acc","args":{"output_transform":""}}],"evaluator":{"name":"SupervisedEvaluator"}}}'
        )

    with open(workspace + "/environment.json", "wt") as f:
        # f.write(r'{"PROCESSING_TASK": "segmentation", "DATASET_JSON": "/tmp/fl/dataset_0.json", "MMAR_CKPT_DIR": "models"}')
        f.write(r'{"PROCESSING_TASK": "segmentation", "DATASET_JSON": "", "MMAR_CKPT_DIR": "models"}')

    # with open(workspace + '/log.config', 'wt') as f:
    #     f.write("[loggers]\nkeys=root,modelLogger\n[handlers]\nkeys=consoleHandler\n[formatters]\nkeys=fullFormatter\n[logger_root]\nlevel=INFO\nhandlers=consoleHandler\n[logger_modelLogger]\nlevel=DEBUG\nhandlers=consoleHandler\nqualname=modelLogger\npropagate=0\n[handler_consoleHandler]\nclass=StreamHandler\nlevel=DEBUG\nformatter=fullFormatter\nargs=(sys.stdout,)\n[formatter_fullFormatter]\nformat=%(asctime)s - %(name)s - %(levelname)s - %(message)s")

    return workspace


def create_admin_agent(
    client_args, client_id, req_processors, secure_train, server_args, federated_client, args, is_multi_gpu, rank
):
    sender = AdminMessageSender(
        client_name=federated_client.token,
        root_cert=client_args["ssl_root_cert"],
        ssl_cert=client_args["ssl_cert"],
        private_key=client_args["ssl_private_key"],
        server_args=server_args,
        secure=secure_train,
        is_multi_gpu=is_multi_gpu,
        rank=rank,
    )
    admin_agent = FedAdminAgent(
        client_name="admin_agent",
        sender=sender,
        app_ctx=ClientAdminInterface(federated_client, federated_client.token, sender, args, rank),
    )
    admin_agent.app_ctx.set_agent(admin_agent)
    for processor in req_processors:
        admin_agent.register_processor(processor)

    return admin_agent
    # self.admin_agent.start()


if __name__ == "__main__":
    # # For MacOS, it needs to use 'spawn' for creating multi-process.
    # if os.name == 'posix':
    #     import multiprocessing
    #     multiprocessing.set_start_method('spawn')

    # import multiprocessing
    # multiprocessing.set_start_method('spawn')

    main()
