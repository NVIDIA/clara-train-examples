import json

import psutil

try:
    import pynvml
except ImportError:
    pynvml = None

from flare.utils.admin_defs import Message

from .admin import RequestProcessor


class SysInfoProcessor(RequestProcessor):
    def get_topics(self) -> [str]:
        return ["sys_info"]

    def process(self, req: Message, app_ctx) -> Message:
        cai = app_ctx

        infos = dict(psutil.virtual_memory()._asdict())
        if pynvml:
            try:
                pynvml.nvmlInit()
                device_count = pynvml.nvmlDeviceGetCount()
                gpu_info = {"gpu_count": device_count}
                for index in range(device_count):
                    handle = pynvml.nvmlDeviceGetHandleByIndex(index)
                    gpu_info[f"gpu_device_{index}"] = pynvml.nvmlDeviceGetName(handle).decode("utf-8")
                pynvml.nvmlShutdown()
                infos.update(gpu_info)
            except pynvml.nvml.NVMLError_LibraryNotFound:
                pass

        # docker_image_tag = os.environ.get('DOCKER_IMAGE_TAG', 'N/A')
        # infos.update({'docker_image_tag':docker_image_tag})
        message = Message(topic="reply_" + req.topic, body=json.dumps(infos))
        print("return sys_info")
        print(infos)
        return message
