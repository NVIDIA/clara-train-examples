
from flare.private.fed.crossvalidation.utils import get_model_owner
from google.protobuf.struct_pb2 import Struct
from flare.private.fed.server.server_status import ServerStatus
import os
import logging
from flare.private.fed.crossvalidation.utils import \
    get_available_models, get_client_model_key, get_server_model_keys, get_client_name_from_model_key
from flare.private.fed.crossvalidation.ml_model_shareable_generator import MLModelShareableGenerator
from flare.apis.shareable import Shareable
from flare.apis.event_type import EventType
from flare.apis.fl_component import fire_event
from flare.apis.fl_constant import CrossValConstants
from flare.apis.fl_constant import FLConstants, ShareableKey, ShareableValue
from flare.apis.fl_context import FLContext
from flare.utils.ml_model_registry import MLModelRegistry
import flare.private.fed.protos.federated_pb2 as fed_msg


class ServerCrossSiteValManager(object):

    def __init__(self) -> None:
        self.admin_server = None
        self.handlers = None
        self.logger = logging.getLogger(self.__class__.__name__)

    def initialize(self, fl_ctx: FLContext, handlers, admin_server):
        # Reset the model registry
        self.ml_model_registry = MLModelRegistry()
        self.ml_model_shareable_gen = MLModelShareableGenerator()
        self.handlers = handlers
        self.admin_server = admin_server
        fl_ctx.set_prop(CrossValConstants.ML_MODEL_REGISTRY, self.ml_model_registry)

    def accept_model(self, token, request, fl_ctx: FLContext):
        if token is None:
            response_comment = 'Ignored the submit from invalid client. '
            self.logger.info(response_comment)
            return response_comment

        model_shareable = Shareable()
        model_shareable = model_shareable.from_bytes(request.data)

        send_context = request.fl_context
        shared_fl_context = FLContext()
        for key, value in send_context.items():
            shared_fl_context.set_prop(key, value, private=False)

        send_client_id = self.admin_server.sai.get_instance_name_from_token(token)

        # Use model scratch space for this client
        run_folder = self.admin_server.sai._get_run_folder()
        client_model_folder = os.path.join(run_folder, 'cross_validation', send_client_id)
        if not os.path.exists(client_model_folder):
            os.makedirs(client_model_folder)

        # Create local context
        fl_ctx.remove_prop(FLConstants.PEER_CONTEXT)
        fl_ctx.set_prop(FLConstants.PEER_CONTEXT, value=shared_fl_context, private=True)
        fl_ctx.set_prop("run_folder", value=run_folder, sticky=False, private=True)
        fl_ctx.set_prop(CrossValConstants.CLIENT_MODEL_FOLDER, client_model_folder, sticky=False, private=True)
        fl_ctx.set_prop(CrossValConstants.LOCAL_MODEL_SHAREABLE, model_shareable, sticky=False, private=True)

        fire_event(EventType.SERVER_RECEIVE_BEST_MODEL, self.handlers, fl_ctx)

        if model_shareable[ShareableKey.TYPE] == ShareableValue.TYPE_ML_MODEL:
            save_path = client_model_folder
            ml_model_entry = self.ml_model_shareable_gen.shareable_to_ml_model_entry(
                model_shareable, save_dir=save_path)
            self.ml_model_registry.register_model(get_client_model_key(send_client_id), ml_model_entry)
        else:
            if model_shareable[ShareableKey.TYPE] == ShareableValue.TYPE_NONE:
                self.logger.info(f"Empty model submitted by client {send_client_id}.")
            else:
                self.logger.info(f"Client {send_client_id} submitted model shareable of wrong type.")
            for client_id in self.admin_server.sai.get_all_instance_names():
                self.admin_server.sai.update_cross_val_dict(client_id, [send_client_id], [{}])

        self.logger.info(f"Received best model from {send_client_id}")
        response_comment = f'Received best model from {send_client_id}.'

        return response_comment

    def get_model_for_validation(self, client, token, server_status, fl_ctx):
        models_per_message = 1
        val_models_msg = fed_msg.ValidationModel()

        # Parameters
        request_client_id = self.admin_server.sai.get_instance_name_from_token(token)
        cross_val_dict = self.admin_server.sai.load_cross_val_dict()
        model_keys = self.ml_model_registry._get_all_model_keys()
        all_clients = self.admin_server.sai.get_all_clients()
        self.logger.info(f"Client {request_client_id} requested models for cross site validation.")

        # Get all the client models
        available_model_keys = []
        if server_status == ServerStatus.TRAINING_STOPPED:
            available_model_keys = get_available_models(
                self.ml_model_registry, cross_val_dict, model_keys, request_client_id
            )
        else:
            self.logger.debug("Server has not finished training. Not sending any models.")

        # Set limit on number of models
        models_to_send = available_model_keys[:models_per_message]
        if len(available_model_keys) > 1:
            val_models_msg.models_available = True

        # Find the number of models that are already done.
        number_done = 0
        if cross_val_dict and request_client_id in cross_val_dict:
            number_done += len(cross_val_dict[request_client_id])
        number_done += len(models_to_send)

        # Determine if client should keep waiting or not.
        total_number = len(get_server_model_keys(model_keys)) + len(all_clients)
        if number_done == total_number:
            val_models_msg.finished = True
            self.logger.info(f"Last set of models sent to {request_client_id}.")
        elif number_done < total_number:
            self.logger.info(f"Sent {number_done} out of {total_number} models to {request_client_id}."
                             " Will be asked to wait and retry.")
        else:
            val_models_msg.finished = True
            self.logger.debug("Number of models sent is greater than total number of models. "
                              "This shouldn't be happening.")

        self.logger.debug(f"Available keys are {available_model_keys}")
        self.logger.debug(f"Number done is {number_done}")
        self.logger.debug(f"Total number is {total_number}")
        self.logger.debug(f"Current cross val dict is {cross_val_dict}")

        # Convert model entries to LocalModel Msg
        model_msgs = []
        for model_key in models_to_send:
            model_entry = self.ml_model_registry.find_model(model_key)
            model_shareable = self.ml_model_shareable_gen.ml_model_entry_to_shareable(model_entry)
            client_name = get_client_name_from_model_key(model_key)
            model_shareable[ShareableKey.META][FLConstants.META_COOKIE] = \
                {CrossValConstants.CROSS_VAL_MODEL_OWNER: client_name}

            local_model = fed_msg.LocalModel()
            local_model.client.uid = client_name
            local_model.data = model_shareable.to_bytes()
            s = Struct()
            for k, v in fl_ctx.get_all_public_props().items():
                s.update({k: v})
            model_msgs.append(local_model)

            self.logger.info(f"Sending {client_name}'s model to {request_client_id} for validation.")

        val_models_msg.models.extend(model_msgs)
        self.logger.debug(f"Sending {len(model_msgs)} models to {request_client_id} for validation.")

        fl_ctx.set_prop("models_to_send", model_msgs, sticky=False)
        fire_event(EventType.SEND_MODEL_FOR_VALIDATION, handlers=self.handlers, ctx=fl_ctx)

        return val_models_msg

    def accept_validation_results(self, metric_shareable, token, fl_ctx):
        if token is None:
            return "Ignored SubmitCrossValidation request from invalid client."
        else:
            owner = get_model_owner(metric_shareable)
            if not owner:
                return "Shareable sent by client didn't have cookie. Discarding results as owner unknown."

            send_client_id = self.admin_server.sai.get_instance_name_from_token(token)
            self.logger.info(f"{send_client_id} submitted results of validating {owner}'s model.")

            metrics = metric_shareable.get(ShareableKey.METRICS)

            self.admin_server.sai.update_cross_val_dict(send_client_id, [owner], [metrics])

            fire_event(EventType.RECEIVE_VALIDATION_RESULTS, self.handlers, fl_ctx)

            # If some results were received print them
            if owner and metrics:
                added_results = {send_client_id: {owner: metrics}}
                self.logger.info(f"New results added are: {added_results}")

            return f"Received Cross Validation results from {send_client_id}."
