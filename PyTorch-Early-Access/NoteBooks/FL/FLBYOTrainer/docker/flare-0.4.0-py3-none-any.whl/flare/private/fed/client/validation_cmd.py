from flare.utils.admin_defs import Message

from .admin import RequestProcessor


class ValidateRequestProcessor(RequestProcessor):
    def get_topics(self) -> [str]:
        return ["validate"]

    def process(self, req: Message, app_ctx) -> Message:
        cai = app_ctx

        result = cai.do_validate(req)
        message = Message(topic="reply_" + req.topic, body=result)
        return message
