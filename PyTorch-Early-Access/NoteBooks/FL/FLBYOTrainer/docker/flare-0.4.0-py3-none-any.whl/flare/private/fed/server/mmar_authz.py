from dlmed.hci.server.authz import AuthzContext

from flare.security.authz import Action, FLAuthzContext


class MMARAuthzService(object):

    mmar_validator = None

    @staticmethod
    def initialize(mmar_validator):
        MMARAuthzService.mmar_validator = mmar_validator

    @staticmethod
    def authorize_upload(mmar_path: str) -> (str, AuthzContext):
        if not MMARAuthzService.mmar_validator:
            return "", {}
        err, mmar_info = MMARAuthzService.mmar_validator.validate(mmar_path)
        if err:
            return err, None

        byoc = mmar_info.get("byoc", False)
        custom_datalist = mmar_info.get("custom_datalist", False)
        actions = [Action.UPLOAD]
        if byoc:
            actions.append(Action.BYOC)
        if custom_datalist:
            actions.append(Action.CUSTOM_DATALIST)

        return "", FLAuthzContext.new_authz_context(site_names=["server"], actions=actions)

    @staticmethod
    def authorize_deploy(mmar_path: str, sites: [str]) -> (str, AuthzContext):
        if not MMARAuthzService.mmar_validator:
            return "", {}
        err, mmar_info = MMARAuthzService.mmar_validator.validate(mmar_path)
        if err:
            return err, None

        byoc = mmar_info.get("byoc", False)
        custom_datalist = mmar_info.get("custom_datalist", False)
        actions = [Action.DEPLOY]
        if byoc:
            actions.append(Action.BYOC)
        if custom_datalist:
            actions.append(Action.CUSTOM_DATALIST)

        return "", FLAuthzContext.new_authz_context(site_names=sites, actions=actions)
