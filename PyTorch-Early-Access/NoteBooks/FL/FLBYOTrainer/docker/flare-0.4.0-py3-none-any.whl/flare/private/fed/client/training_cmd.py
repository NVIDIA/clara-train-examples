from flare.utils.admin_defs import Message

from .admin import RequestProcessor


class StartClientProcessor(RequestProcessor):
    def get_topics(self) -> [str]:
        return ["start"]

    def process(self, req: Message, app_ctx) -> Message:
        cai = app_ctx

        run_number = int(req.get_header("run_number"))
        result = cai.start_client(run_number)
        message = Message(topic="reply_" + req.topic, body=result)
        return message


class StartClientMGpuProcessor(RequestProcessor):
    def get_topics(self) -> [str]:
        return ["start_mgpu"]

    def process(self, req: Message, app_ctx) -> Message:
        cai = app_ctx

        run_number = int(req.get_header("run_number"))
        gpu_number = int(req.get_header("gpu_number"))
        result = cai.start_mgpu_client(run_number, gpu_number)
        message = Message(topic="reply_" + req.topic, body=result)
        return message


class AbortClientProcessor(RequestProcessor):
    def get_topics(self) -> [str]:
        return ["abort"]

    def process(self, req: Message, app_ctx) -> Message:
        cai = app_ctx

        result = cai.abort_client()
        message = Message(topic="reply_" + req.topic, body=result)
        return message


class ShutdownClientProcessor(RequestProcessor):
    def get_topics(self) -> [str]:
        return ["shutdown"]

    def process(self, req: Message, app_ctx) -> Message:
        cai = app_ctx

        result = cai.shutdown_client()
        message = Message(topic="reply_" + req.topic, body=result)
        return message


class RestartClientProcessor(RequestProcessor):
    def get_topics(self) -> [str]:
        return ["restart"]

    def process(self, req: Message, app_ctx) -> Message:
        cai = app_ctx

        result = cai.restart_client()
        message = Message(topic="reply_" + req.topic, body=result)
        return message


class ClientStatusProcessor(RequestProcessor):
    def get_topics(self) -> [str]:
        return ["check_status"]

    def process(self, req: Message, app_ctx) -> Message:
        cai = app_ctx

        result = cai.client_status()
        message = Message(topic="reply_" + req.topic, body=result)
        return message


class DeployProcessor(RequestProcessor):
    def get_topics(self) -> [str]:
        return ["deploy"]

    def process(self, req: Message, app_ctx) -> Message:
        cai = app_ctx

        result = cai.deploy_mmar(req.body)
        message = Message(topic="reply_" + req.topic, body=result)
        return message


class DeleteRunNumberProcessor(RequestProcessor):
    def get_topics(self) -> [str]:
        return ["delete_run_number"]

    def process(self, req: Message, app_ctx) -> Message:
        cai = app_ctx

        run_number = int(req.get_header("run_number"))
        result = cai.delete_run_number(run_number)
        message = Message(topic="reply_" + req.topic, body=result)
        return message
