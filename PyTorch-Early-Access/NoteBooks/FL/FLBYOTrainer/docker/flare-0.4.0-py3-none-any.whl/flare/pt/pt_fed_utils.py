import logging

import torch
import torch.nn as nn

from flare.utils.fed_utils import FED_UPDATE_OPS


def feed_vars(model: nn.Module, model_params):
    """feed variable values from model_params to pytorch state_dict.

    Args:
        model (nn.Module): the local pytorch model
        model_params: a ModelData message

    Returns:
        a list of params and a dictionary of vars to params
    """
    _logger = logging.getLogger("AssignVariables")
    _logger.debug("AssignVariables...")

    to_assign = []
    n_ext = len(model_params)
    _logger.debug(f"n_ext {n_ext}")
    _logger.debug(f"FED_UPDATE_OPS {FED_UPDATE_OPS}")

    local_var_dict = model.state_dict()
    for var_name in local_var_dict:
        try:
            if var_name in tuple(model_params):
                nd = model_params[var_name]
                to_assign.append(nd)
                local_var_dict[var_name] = torch.as_tensor(
                    nd
                )  # update local state dict TODO: enable setting of datatype
        except Exception as e:
            print("pt_feed_vars Exception:", str(e))
            raise RuntimeError(str(e))

    _logger.debug("Updated local variables to be assigned.")

    n_assign = len(to_assign)
    _logger.info(f"Vars {n_ext} of {n_assign} assigned.")
    return to_assign, local_var_dict
