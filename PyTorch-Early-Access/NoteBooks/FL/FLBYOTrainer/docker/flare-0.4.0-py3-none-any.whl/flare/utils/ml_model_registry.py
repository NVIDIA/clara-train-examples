import logging
import pickle
import threading


class MLModelEntry:
    def __init__(self, name, files=None, meta_data=None) -> None:
        self.name = name
        self.meta = {}
        self.files = {}
        if files:
            self.add_files(files)
        if meta_data:
            self.add_meta_data(meta_data)

    def add_meta_data(self, meta_data):
        if not isinstance(meta_data, dict):
            self.logger.info("meta_data must be dict.")

        self.meta.update(meta_data)

    def add_files(self, files):
        if not files:
            self.logger.info("files is empty.")
            return

        if not isinstance(files, dict):
            self.logger.info("files must be a dict")
            return

        self.files.update(files)


class MLModelRegistry:
    def __init__(self) -> None:
        self.registry = {}
        self._update_lock = threading.Lock()
        self._content_updated = False

        self.logger = logging.getLogger(self.__class__.__name__)

    def _get_all_model_keys(self):
        return self.registry.keys()

    def find_model(self, model_key: str) -> MLModelEntry:
        return self.registry.get(model_key, None)

    def remove_model(self, model_key: str) -> MLModelEntry:
        return self.registry.pop(model_key, default=None)

    def register_model(self, model_key, ml_model_entry: MLModelEntry, override=False):
        if not ml_model_entry:
            self.logger.info("Empty model entry submitted")
            return False
        if not isinstance(ml_model_entry, MLModelEntry):
            self.logger.info("ml_model_entry must be an instance of MLModelEntry")
            return False

        if model_key in self.registry and not override:
            self.logger.debug(f"Model Key {model_key} already exists in registry and override is False.")
            return False
        else:
            with self._update_lock:
                self.registry[model_key] = ml_model_entry
                self._content_updated = True
        return True

    def to_bytes(self):
        with self._update_lock:
            data = pickle.dumps(self.registry)
        return data

    @classmethod
    def from_bytes(cls, data):
        obj = cls()
        obj.registry = pickle.loads(data)
        return obj
