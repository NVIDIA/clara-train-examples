import os


def read_client_info(mmar_root, client_file):
    """Read client info like token, uid and run number."""
    token_file = os.path.join(mmar_root, client_file)
    with open(token_file, "r") as f:
        token = f.readline().strip()
        run_number = f.readline().strip()
        uid = f.readline().strip()
        print("token is: {} run_number is: {} uid: {}".format(token, run_number, uid))

    return token, run_number, uid


def get_mmar_root(mmar, run_number, uid):
    return os.path.join(mmar, "run_" + str(run_number), "mmar_" + uid)
