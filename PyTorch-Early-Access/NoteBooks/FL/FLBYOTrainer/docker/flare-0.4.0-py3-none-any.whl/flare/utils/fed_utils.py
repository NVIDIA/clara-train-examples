"""Utilities for federated learning"""
from flare.apis.fl_constant import FLConstants, ShareableKey, ShareableValue
from flare.apis.fl_context import FLContext
from flare.apis.shareable import Shareable

GRPC_DEFAULT_OPTIONS = [
    ("grpc.max_send_message_length", 1024 * 1024 * 1024),
    ("grpc.max_receive_message_length", 1024 * 1024 * 1024),
]
VERBOSE = True

FED_DELTA_W = "delta_w"
FED_W = "w"
CONTRIB_TYPE = {FED_DELTA_W, FED_W}
FED_UPDATE_OPS = "fedlearn_ops"


def generate_failure(fl_ctx: FLContext, reason: str, cookie=None):
    fl_ctx.set_prop(FLConstants.FAILURE, reason, sticky=False, private=False)

    shareable = generate_empty_shareable(cookie=cookie)
    return shareable


def generate_empty_shareable(cookie=None):
    shareable = Shareable()
    shareable[ShareableKey.TYPE] = ShareableValue.TYPE_NONE
    meta = {}
    shareable[ShareableKey.META] = meta
    if cookie is not None:
        meta[FLConstants.META_COOKIE] = cookie
    return shareable


def set_cookie(shareable, cookie):
    if not shareable.get(ShareableKey.META):
        shareable[ShareableKey.META] = {}

    if isinstance(shareable.get(ShareableKey.META), dict):
        shareable[ShareableKey.META][FLConstants.META_COOKIE] = cookie


def get_cookie(shareable: Shareable):
    # shareable may include META
    # META's value must be a dictionary and it may have COOKIE
    return shareable.get(ShareableKey.META, {}).get(FLConstants.META_COOKIE, None)
