import uuid


class MsgHeader(object):

    REF_MSG_ID = "_refMsgId"
    RETURN_CODE = "_rtnCode"


class ReturnCode(object):

    OK = "_ok"
    ERROR = "_error"


class Message(object):
    def __init__(self, topic: str, body):
        self.id = str(uuid.uuid4())
        self.topic = topic
        self.body = body
        self.headers = {}

    def set_header(self, key, value):
        self.headers[key] = value

    def set_headers(self, headers: dict):
        if not headers:
            return

        assert isinstance(headers, dict)
        if len(headers) > 0:
            self.headers.update(headers)

    def get_header(self, key, default=None):
        return self.headers.get(key, default)

    def get_ref_id(self, default=None):
        return self.get_header(MsgHeader.REF_MSG_ID, default)

    def set_ref_id(self, msg_id):
        self.set_header(MsgHeader.REF_MSG_ID, msg_id)


def error_reply(err: str) -> Message:
    msg = Message(topic="reply", body=err)
    msg.set_header(MsgHeader.RETURN_CODE, ReturnCode.ERROR)
    return msg


def ok_reply(data=None) -> Message:
    if data is None:
        data = "ok"

    msg = Message(topic="reply", body=data)
    msg.set_header(MsgHeader.RETURN_CODE, ReturnCode.OK)
    return msg
