from flare.apis.fl_constant import FLConstants
from flare.apis.fl_context import FLContext


def server_fl_ctx_sanity_check(fl_ctx: FLContext, check_peer=False, nice=10):
    """Checking key values in fl_ctx

    Args:
        fl_ctx (FLContext): server side FLContext
        check_peer (bool, optional): whether to check PEER_CONTEXT. Defaults to False.
        nice (int, optional): >=10 skips checking most key values Defaults to 10.
    """
    assert fl_ctx is not None, "missing fl_ctx"
    if check_peer:
        peer_ctx = fl_ctx.get_prop(FLConstants.PEER_CONTEXT)
        assert peer_ctx is not None, "missing peer context"
    else:
        peer_ctx = None

    if nice < 10:
        for key in [FLConstants.CLIENT_NAME, FLConstants.CURRENT_RUN, FLConstants.CURRENT_ROUND]:
            _sanity_check(fl_ctx, peer_ctx, key, check_peer)


def _sanity_check(fl_ctx, peer_ctx, key, check_peer):
    value1 = fl_ctx.get_prop(key)
    assert value1 is not None, f"missing {key} from fl ctx"
    if check_peer:
        value2 = peer_ctx.get_prop(key)
        assert value2 is not None, f"missing {key} in peer ctx"
        assert value1 == value2, f"{key}:{value1} in fl ctx mismatched with {key}:{value2} in peer ctx"
