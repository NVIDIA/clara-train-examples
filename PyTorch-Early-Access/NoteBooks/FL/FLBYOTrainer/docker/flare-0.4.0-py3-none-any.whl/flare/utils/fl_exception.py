class FLCommunicationException(Exception):
    """
    Base class for fed_learn communication exceptions
    """

    def __init__(self, exception):
        # Copy all the SimpleTrainer properties into ClientTrainer instance.
        self.__dict__.update(exception.__dict__)


class FLAdminException(Exception):
    """
    FL Admin exceptions
    """

    def __init__(self, message):
        # Call the base class constructor with the parameters it needs
        super().__init__(message)
