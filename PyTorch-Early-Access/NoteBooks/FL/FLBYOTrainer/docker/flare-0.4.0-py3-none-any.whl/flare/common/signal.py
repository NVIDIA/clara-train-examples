import time


class Signal(object):
    def __init__(self):
        self.value = None
        self.trigger_time = None
        self.triggered = False

    def trigger(self, value):
        self.value = value
        self.trigger_time = time.time()
        self.triggered = True

    def reset(self, value=None):
        self.value = value
        self.trigger_time = None
        self.triggered = False
