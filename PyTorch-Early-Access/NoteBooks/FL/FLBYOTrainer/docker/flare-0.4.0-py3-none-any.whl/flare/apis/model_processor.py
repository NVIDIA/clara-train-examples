from abc import ABC, abstractmethod

from flare.apis.fl_context import FLContext


class ModelProcessor(ABC):
    @abstractmethod
    def initialize(self, trainer):
        pass

    @abstractmethod
    def extract_model(self, model_vars, fl_ctx: FLContext):
        pass

    @abstractmethod
    def apply_model(self, model_params, fl_ctx: FLContext, options=None):
        pass

    @abstractmethod
    def get_local_models(self, model_params=None):
        pass
