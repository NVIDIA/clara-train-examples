from abc import abstractmethod
from typing import Tuple

from .fl_component import FLComponent
from .fl_context import FLContext
from .shareable import Shareable


class Aggregator(FLComponent):
    @abstractmethod
    def accept(self, shareable: Shareable, fl_ctx: FLContext) -> Tuple[bool, bool]:
        """
            accept the shareable submitted by the client.

        Args:
            shareable: submitted Shareable object
            fl_ctx: FLContext

        Returns:
            first boolean to indicate if the contribution has been accepted.
            second boolean to indicate if trigger the current round aggregate() call right away.

        """
        pass

    @abstractmethod
    def aggregate(self, fl_ctx: FLContext) -> Shareable:
        """
            perform the aggregation for all the received Shareable from the clients.

        Args:
            fl_ctx: FLContext

        Returns:
            shareable
        """
        pass
