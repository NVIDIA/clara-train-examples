from abc import abstractmethod

from .fl_component import FLComponent
from .fl_context import FLContext
from .learnable import Learnable


class ModelPersistor(FLComponent):
    @abstractmethod
    def load_model(self, fl_ctx: FLContext) -> Learnable:
        """
            initialize and load the Learnable.

        Args:
            fl_ctx: FLContext

        Returns:
            Model object

        """
        pass

    @abstractmethod
    def save_model(self, model: Learnable, fl_ctx: FLContext):
        """
            persist the Learnable object

        Args:
            model: Model object
            fl_ctx: FLContext

        """
        pass
