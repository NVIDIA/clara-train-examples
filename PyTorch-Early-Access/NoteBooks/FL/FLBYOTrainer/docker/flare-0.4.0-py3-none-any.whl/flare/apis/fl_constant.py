from enum import Enum


class FLConstants(object):

    FEDERATE_CLIENT = "federate_client"
    CONFIG_PATH = "config_path"
    FL_TRAINING_MODE = "fl_training_mode"
    MODEL_NETWORK = "model_network"
    MULTI_GPU = "multi_gpu"
    TRAIN_CONTEXT = "train_context"
    DEVICE = "device"
    MODEL_NAME = "model_name"
    MODEL_URL = "model_url"

    CLIENT_NAME = "client_name"
    FL_TOKEN = "fl_token"
    LOCAL_EPOCHS = "local_epochs"
    TRAIN_ROOT = "train_root"
    WORKSPACE = "workspace"
    PLATFORM = "platform"
    WAIT_AFTER_MIN_CLIENTS = "wait_after_min_clients"

    CURRENT_RUN = "current_run"
    START_ROUND = "start_round"
    CURRENT_ROUND = "current_round"
    MAX_ROUNDS = "max_rounds"
    TOTAL_ROUND = "total_round"

    NUM_STEPS_CURRENT_ROUND = "num_steps_current_round"  # ITERATION_NUMBER
    NUM_TOTAL_STEPS = "num_total_steps"  # TOTAL_STEPS
    NUM_EPOCHS_CURRENT_ROUND = "num_epochs_current_round"  # CURRENT_EPOCHS
    NUM_TOTAL_EPOCHS = "num_total_epochs"  # LOCAL_EPOCHS

    ARGS = "args"
    IS_FIRST_ROUND = "is_first_round"
    MY_RANK = "my_rank"
    INITIAL_LEARNING_RATE = "initial_learning_rate"
    CURRENT_LEARNING_RATE = "current_learning_rate"
    NUMBER_OF_GPUS = "number_of_gpus"
    INITIAL_METRICS = "initial_metrics"
    PEER_CONTEXT = "peer_context"
    FAILURE = "failure"
    META = "meta"
    META_COOKIE = "cookie"
    META_DATA = "meta_data"
    GLOBAL_MODEL = "global_model"

    IS_BEST = "is_best"
    SHAREABLE = "shareable"

    LOG_DIR = "model_log_dir"
    CKPT_PRELOAD_PATH = "ckpt_preload_path"

    MODEL_DIR = "model_dir"
    MODEL_NAME = "model_name"
    MODEL_FILES = "model_files"
    MMAR_ROOT = "mmar_root"

    CLIENT_TOKEN_FILE = "client_token.txt"


class ShareableKey(Enum):

    TYPE = "type"
    DATA_TYPE = "data_type"
    MODEL_WEIGHTS = "model_weights"
    UNENCRYPTED_WEIGHTS = "unencrypted_weights"
    ENCRYPTED_WEIGHTS = "encrypted_weights"
    META = "meta"

    MODEL_NAME = "model_name"
    DATA = "DATA"
    METRICS = "metrics"


class ShareableValue(Enum):

    TYPE_WEIGHTS = "weights_dict"
    TYPE_WEIGHT_DIFF = "weights_diff"
    TYPE_NONE = "none"
    TYPE_ML_MODEL = "ml_model"
    TYPE_METRICS = "metrics"

    DATA_TYPE_UNENCRYPTED = "unencrypted"
    DATA_TYPE_ENCRYPTED = "encrypted"
    DATA_TYPE_MIXED = "mixed"
    DATA_TYPE_BYTES = "bytes"
    DATA_TYPE_FILES = "files"


class ShareableMetaKey(Enum):
    META_MODEL_NAME = "meta_model_name"


class CrossValConstants:

    PARTICIPATING_IN_CROSS_VAL = "cross_val_is_participating"
    LOCAL_MODEL_SHAREABLE = "cross_val_local_model_shareable"
    ML_MODEL_REGISTRY = "ml_model_registry"
    CROSS_VAL_FINISHED = "cross_val_finished"
    CROSS_VAL_MODELS_AVAILABLE = "cross_val_are_models_available"
    CROSS_VAL_VALIDATION_SHAREABLE = "cross_val_validation_shareable"
    CROSS_VAL_MODEL_OWNER = "cross_val_model_owner"
    CROSS_VAL_SCRATCH_DIR = "cross_validation"
    METRIC_SHAREABLE = "metric_shareable"
    CLIENT_MODEL_FOLDER = "client_model_folder"
    CROSS_VAL_TIMEOUT = "cross_val_timeout"

    UNKNOWN_OWNER = "unknown owner"
    CLIENT_PREFIX = "CLIENT_"
    META_MODEL_NAME = "meta_model_name"
    FINISHED = "finished"
    MORE_MODELS_AVAILABLE = "more_models_available"


class MLModelKeys:
    LOCAL_BEST_MODEL = "local_best_model"
