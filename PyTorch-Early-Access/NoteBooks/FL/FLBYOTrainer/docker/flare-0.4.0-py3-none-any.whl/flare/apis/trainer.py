from abc import abstractmethod

from flare.common.signal import Signal

from .fl_component import FLComponent
from .fl_context import FLContext
from .shareable import Shareable


class Trainer(FLComponent):
    @abstractmethod
    def train(self, shareable: Shareable, fl_ctx: FLContext, abort_signal: Signal) -> Shareable:
        """
            use the Shareable from the server to train the model.

        Args:
            shareable: shareable from server
            fl_ctx: FLContext
            abort_signal: signal to indicate abort the training

        Returns:
            Shareable object to be submitted to server for aggregation

        """
        pass
