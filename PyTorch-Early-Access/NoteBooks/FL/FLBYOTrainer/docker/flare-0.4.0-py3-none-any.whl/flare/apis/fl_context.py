import copy
import logging
import threading

_update_lock = threading.Lock()


class FLContext(object):
    MASK_STICKY = 1 << 0
    MASK_PRIVATE = 1 << 1

    @classmethod
    def _is_sticky(cls, mask) -> bool:
        return mask & cls.MASK_STICKY > 0

    @classmethod
    def _is_private(cls, mask) -> bool:
        return mask & cls.MASK_PRIVATE > 0

    @classmethod
    def _matching_private(cls, mask, private) -> bool:
        return (mask & cls.MASK_PRIVATE > 0) == private

    @classmethod
    def _to_string(cls, mask) -> str:
        if cls._is_private(mask):
            result = "private:"
        else:
            result = "public:"

        if cls._is_sticky(mask):
            return result + "sticky"
        else:
            return result + "non-sticky"

    def __init__(self):
        self.model = None
        self.props = {}
        self.logger = logging.getLogger(self.__class__.__name__)

    def public_key_exists(self, key):
        return key in self.props and not self._is_private(self.props[key]["mask"])

    def set_public_props(self, metadata: dict):
        # remove all public props
        self.props = {k: v for k, v in self.props.items() if self._is_private(v["mask"] or self._is_sticky(v["mask"]))}

        for key, value in metadata.items():
            self.set_prop(key, value, private=False, sticky=True)

    def get_all_public_props(self):
        return {k: v["value"] for k, v in self.props.items() if not self._is_private(v["mask"])}

    def set_model(self, model):
        with _update_lock:
            self.model = model

    def get_model(self):
        return self.model

    def set_prop(self, key: str, value, private=True, sticky=True):
        with _update_lock:
            mask = 0
            if private:
                mask += FLContext.MASK_PRIVATE
            if sticky:
                mask += FLContext.MASK_STICKY
            if key not in self.props or key in self.props and self.props[key]["mask"] == mask:
                self.props[key] = {"value": value, "mask": mask}
            else:
                existing_mask = self.props[key]["mask"]
                self.logger.warning(
                    f"property {key} already exists with attributes "
                    f"{self._to_string(existing_mask)}, cannot change to {self._to_string(mask)}"
                )
                return False

    def get_prop(self, key, default=None):
        with _update_lock:
            if key in self.props:
                return self.props.get(key)["value"]
            else:
                return default

    def remove_prop(self, key: str):
        with _update_lock:
            self.props.pop(key, None)

    def clone(self):
        with _update_lock:
            new_fl_ctx = FLContext()
            new_fl_ctx.set_model(copy.deepcopy(self.model))
            new_fl_ctx.props = copy.deepcopy(self.props)
            return new_fl_ctx

    def __str__(self):
        raw_list = [f'{k}: {type(v["value"])}' for k, v in self.props.items()]
        raw_list.append(f"model: {type(self.model)}")
        return " ".join(raw_list)
