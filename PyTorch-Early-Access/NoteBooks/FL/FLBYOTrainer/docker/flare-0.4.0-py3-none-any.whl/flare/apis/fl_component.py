import logging
import traceback

from .fl_context import FLContext


class FLComponent(object):
    def __init__(self):
        self._name = self.__class__.__name__
        self.logger = logging.getLogger(self._name)

    def handle_event(self, event_type: str, fl_ctx: FLContext):
        """
            perform the handler process based on the event_type.

        Args:
            event_type: evnt type fired by workflow
            fl_ctx: FLContext

        """
        pass


def fire_event(event: str, handlers: list, ctx: FLContext):
    """
    Fires the specified event and invokes the list of handlers.

    Args:
        event: the event to be fired
        handlers: handlers to be invoked
        ctx: context for cross-component data sharing

    Returns:

    """
    if handlers:
        for h in handlers:
            try:
                h.handle_event(event, ctx)
            except BaseException as ex:
                traceback.print_exc()
