class TrainConfigValidator(object):
    def validate(self, train_config_path: str) -> (str, {}):
        """
        Validate the content of specified folder.

        Args:
            train_config_path: path to the folder that contains training config file(s)

        Returns: error message if validate failed; otherwise an empty string. The returned
        dict contains authorization context info.

        """
        pass
