from abc import abstractmethod

from .fl_component import FLComponent
from .fl_context import FLContext
from .learnable import Learnable
from .shareable import Shareable


class ShareableGenerator(FLComponent):
    @abstractmethod
    def learnable_to_shareable(self, model: Learnable, fl_ctx: FLContext) -> Shareable:
        """
            generate the initial Shareable from the Learnable object.

        Args:
            model: model object
            fl_ctx: FLContext

        Returns:
            shareable

        """
        pass

    @abstractmethod
    def shareable_to_learnable(self, shareable: Shareable, fl_ctx: FLContext) -> Learnable:
        """
            construct the Learnable object from Shareable

        Args:
            shareable: shareable
            fl_ctx: FLContext

        Returns:
            model object

        """
        pass
