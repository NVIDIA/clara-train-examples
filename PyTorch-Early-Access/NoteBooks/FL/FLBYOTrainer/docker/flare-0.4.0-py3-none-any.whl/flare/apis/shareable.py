# from __future__ import annotations

import pickle

from flare.apis.fl_constant import ShareableKey, ShareableValue


class Shareable(dict):
    """The information communicated between server and client

    The shareable is a dictionary which has the following mandatory keys:

    ShareableKey.TYPE and ShareableKey.DATA_TYPE
    The value of TYPE can be
        ShareableValue.TYPE_WEIGHTS, ShareableValue.TYPE_WEIGHT_DIFF, ShareableValue.NONE
    When defining a new TYPE, trainer, filter, aggregator and handlers must be aware of such
    type to handle it properly.

    The value of DATA_TYPE can be
        DATA_TYPE_UNENCRYPTED, DATA_TYPE_ENCRYPTED, DATA_TYPE_MIXED
        all are defined in ShareableValue

    Based on the above information, shareable can have other keys and values.  The actual
    definition of those keys is determined by developers and users.

    Shareable can also have ShareableKey.META, whose value is a dictionary containing additional
    information set by clients.
    """

    def __init__(self):
        super().__init__()
        self[ShareableKey.TYPE] = None
        self[ShareableKey.DATA_TYPE] = ShareableValue.DATA_TYPE_UNENCRYPTED

    def to_bytes(self) -> bytes:
        """
            method to serialize the Model object into bytes.

        Returns:
            object serialized in bytes.

        """
        return pickle.dumps(self)

    @classmethod
    def from_bytes(cls, data: bytes):
        """
            method to convert the object bytes into Model object.

        Args:
            data: a bytes object

        Returns:
            an object loaded by pickle from data

        """
        return pickle.loads(data)
