from abc import abstractmethod

from flare.common.signal import Signal

from .fl_component import FLComponent
from .fl_context import FLContext
from .shareable import Shareable


class Validator(FLComponent):
    @abstractmethod
    def validate(self, shareable: Shareable, fl_ctx: FLContext, abort_signal: Signal):
        """
            use the validation dataset to validate the passed in shareable.

        Args:
            shareable: Shareable to run validation on.
            fl_ctx: FL Context
            abort_signal: Abort signal

        Returns:

        """
        pass
