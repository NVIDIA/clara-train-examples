# from __future__ import annotations

import pickle


class Learnable(dict):
    def __init__(self) -> None:
        super().__init__()

    def to_bytes(self) -> bytes:
        """
            method to serialize the Learnable object into bytes.

        Returns:
            object serialized in bytes.

        """
        return pickle.dumps(self)

    @classmethod
    def from_bytes(cls, data: bytes):
        """
            method to convert the object bytes into Learnable object.

        Args:
            data: a bytes object

        Returns:
            an object loaded by pickle from data

        """
        return pickle.loads(data)
