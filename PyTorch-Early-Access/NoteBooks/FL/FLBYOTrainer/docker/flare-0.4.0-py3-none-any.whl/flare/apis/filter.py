from .fl_component import FLComponent
from .fl_context import FLContext
from .shareable import Shareable


class Filter(FLComponent):
    def process(self, shareable: Shareable, fl_ctx: FLContext) -> Shareable:
        """
            filter process apply to the Shareable object.

        Args:
            shareable: shareable
            fl_ctx: FLContext

        Returns:
            a Shareable object

        """
        pass
