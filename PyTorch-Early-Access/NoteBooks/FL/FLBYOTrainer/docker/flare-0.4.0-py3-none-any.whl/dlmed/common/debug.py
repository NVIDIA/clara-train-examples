import time


_DEBUG = False


def debug(msg):
    if _DEBUG:
        print(time.time(), ': ', msg)
