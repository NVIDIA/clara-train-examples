class EndPoint(object):

    def __init__(self, get_func, put_func):
        self.get_func = get_func
        self.put_func = put_func

    def put(self, topic: str, data_bytes):
        self.put_func(topic=topic, data_bytes=data_bytes)

    def get(self, timeout=None):
        return self.get_func(timeout=timeout)


class Pipe(object):

    def __init__(self, name):
        self.name = name
        self.x = EndPoint(self.x_get, self.x_put)
        self.y = EndPoint(self.y_get, self.y_put)

    def clear(self):
        pass

    def x_put(self, topic: str, data_bytes):
        pass

    def x_get(self, timeout=None):
        pass

    def y_put(self, topic: str, data_bytes):
        pass

    def y_get(self, timeout=None):
        pass
