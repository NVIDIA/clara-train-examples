from dlmed.hci.conn import Connection
from dlmed.hci.reg import CommandRegister
from .constants import ConnProps
from dlmed.hci.cmd_arg_utils import split_to_args
import traceback


class CommandFilter(object):

    def pre_command(self, conn: Connection, args: [str]) -> bool:
        # returns whether to continue filter chain
        return True

    def post_command(self, conn: Connection, args: [str]) -> bool:
        pass

    def close(self):
        pass


class ServerCommandRegister(CommandRegister):

    def __init__(self, app_ctx):
        CommandRegister.__init__(self, app_ctx)
        self.filters = []
        self.closed = False

    def add_filter(self, cmd_filter: CommandFilter):
        assert isinstance(cmd_filter, CommandFilter), 'cmd_filter must be CommandFilter'
        self.filters.append(cmd_filter)

    def _do_command(self, conn: Connection, command: str):
        conn.app_ctx = self.app_ctx
        args = split_to_args(command)
        conn.args = args
        conn.command = command

        cmd_name = args[0]
        entries = self.get_command_entries(cmd_name)
        if len(entries) <= 0:
            conn.append_error('Unknown command "{}"'.format(cmd_name))
            return
        elif len(entries) == 1:
            conn.set_prop(ConnProps.CMD_ENTRY, entries[0])
            handler = entries[0].handler
        else:
            conn.append_error(
                'Command "{}" exists in multiple scopes. Please use full command name'.format(cmd_name))
            return

        if handler is None:
            conn.append_error('Unknown command "{}"'.format(cmd_name))
            return

        # invoke pre filters
        if len(self.filters) > 0:
            for f in self.filters:
                ok = f.pre_command(conn, args)
                if not ok:
                    return

        if handler is not None:
            handler(conn, args)
        else:
            conn.append_error('Unknown command "{}"'.format(command))
            return

        # invoke post filters
        if len(self.filters) > 0:
            for f in self.filters:
                f.post_command(conn, args)

    def process_command(self, conn: Connection, command: str):
        try:
            self._do_command(conn, command)
        except:
            traceback.print_exc()
            conn.append_error('Exception Occurred')

    def close(self):
        if self.closed:
            return

        for f in self.filters:
            f.close()

        for m in self.modules:
            m.close()

        self.closed = True
