import re
import io
import shlex
import argparse


def split_to_args(line: str) -> [str]:
    if '"' in line:
        return shlex.split(line)
    else:
        # return line.split() or the following
        line = re.sub(' +', ' ', line)
        return line.split(' ')  


def join_args(segs: [str]) -> str:
    result = ''
    sep = ''
    for a in segs:
        parts = a.split()
        if len(parts) < 2:
            p = parts[0]
        else:
            p = '"' + a + '"'
        result = result + sep + p
        sep = ' '

    return result


class ArgValidator(argparse.ArgumentParser):

    def __init__(self, name):
        argparse.ArgumentParser.__init__(self, prog=name, add_help=False)
        self.err = ""

    def error(self, message):
        self.err = message

    def validate(self, args):
        try:
            result = self.parse_args(args)
            return self.err, result
        except:
            return 'argument error; try "? cmdName to show supported usage for a command"', None

    def get_usage(self) -> str:
        buffer = io.StringIO()
        self.print_help(buffer)
        usage_output = buffer.getvalue().split('\n', 1)[1]
        buffer.close()
        return usage_output


if __name__ == "__main__":

    args = split_to_args('This   is  a " VERY GOOD  Case " !!! ')
    print('args: {}'.format(args))

    cmd = join_args(args)
    print('Cmd: {}'.format(cmd))

    parser = ArgValidator('test')

    parser.add_argument('-f', metavar='num', type=int, help='a number')
    parser.add_argument('-h', action='store_true')
    parser.add_argument('-g', action='store_true')
    parser.add_argument('file', metavar='file', type=str, help='a file name')
    err, result = parser.validate(['-f', '22', '-hg', 'xyz.log'])
    print('error: ', err)
    if result:
        print('f: {}'.format(result.f))
        print('g: {}'.format(result.g))
        print('h: {}'.format(result.h))
    print('Usage: {}'.format(parser.get_usage()))
