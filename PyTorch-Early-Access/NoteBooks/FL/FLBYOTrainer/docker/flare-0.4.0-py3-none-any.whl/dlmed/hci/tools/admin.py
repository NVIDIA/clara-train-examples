from dlmed.hci.client.lib import AdminClient
from dlmed.hci.client.file_transfer import FileTransferModule
import argparse


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--host', default='localhost')
    parser.add_argument('--port', type=int, default=55550)
    parser.add_argument('--prompt', type=str, default='> ')
    parser.add_argument('--with_file_transfer', action='store_true')
    parser.add_argument('--upload_folder_cmd_name', type=str, default='upload_folder')
    parser.add_argument('--upload_dir', type=str, default='')
    parser.add_argument('--download_dir', type=str, default='')
    parser.add_argument('--with_shell', action='store_true')
    parser.add_argument('--with_login', action='store_true')
    parser.add_argument('--cred_type', default='password')
    parser.add_argument('--with_ssl', action='store_true')
    parser.add_argument('--ca_cert', type=str, default='')
    parser.add_argument('--client_cert', type=str, default='')
    parser.add_argument('--client_key', type=str, default='')
    parser.add_argument('--with_debug', action='store_true')

    args = parser.parse_args()

    modules = []

    if args.with_file_transfer:
        modules.append(FileTransferModule(
            upload_dir=args.upload_dir,
            download_dir=args.download_dir,
            upload_folder_cmd_name=args.upload_folder_cmd_name
        ))

    ca_cert = args.ca_cert
    client_cert = args.client_cert
    client_key = args.client_key

    if args.with_ssl:
        if len(ca_cert) <= 0:
            print('missing CA Cert file name')
            return

        if len(client_cert) <= 0:
            print('missing Client Cert file name')
            return

        if len(client_key) <= 0:
            print('missing Client Key file name')
            return
    else:
        ca_cert = None
        client_key = None
        client_cert = None

    if args.with_debug:
        print('SSL: {}'.format(args.with_ssl))
        print('User Login: {}'.format(args.with_login))
        print('File Transfer: {}'.format(args.with_file_transfer))

        if args.with_file_transfer:
            print('  Upload Dir: {}'.format(args.upload_dir))
            print('  Download Dir: {}'.format(args.download_dir))

    print('Admin Server: {} on port {}'.format(args.host, args.port))

    client = AdminClient(
        host=args.host,
        port=args.port,
        prompt=args.prompt,
        cmd_modules=modules,
        ca_cert=ca_cert,
        client_cert=client_cert,
        client_key=client_key,
        require_login=args.with_login,
        credential_type=args.cred_type,
        debug=args.with_debug
    )

    client.run()


if __name__ == "__main__":
    main()