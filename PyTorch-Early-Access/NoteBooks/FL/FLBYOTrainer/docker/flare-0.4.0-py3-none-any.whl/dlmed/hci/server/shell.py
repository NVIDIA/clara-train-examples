from dlmed.hci.reg import CommandModule, CommandSpec, CommandModuleSpec
from dlmed.hci.conn import Connection
from dlmed.hci.cmd_arg_utils import join_args
import subprocess


class ShellCommandModule(CommandModule):

    def __init__(self, allowed_commands=None):
        if allowed_commands is None:
            allowed_commands = ['pwd', 'ls', 'cat', 'head', 'tail', 'grep', 'env']
        else:
            assert isinstance(allowed_commands, list), 'allowed_commands must be a str list'
            assert all(isinstance(x, str) for x in allowed_commands), \
                'allowed_commands must be a str list'
        self.allowed_commands = allowed_commands

    def get_spec(self):
        return CommandModuleSpec(
            name='utils',
            cmd_specs=[
                CommandSpec(
                    name='sh',
                    description='execute a shell command on server',
                    usage='sh cmd ...',
                    handler_func=self.do_shell_command,
                    visible=True
                )
            ]
        )

    def do_shell_command(self, conn: Connection, args: [str]):
        if len(args) < 2:
            conn.append_error("syntax error: missing shell command")
            return

        sh_cmd_name = args[1]
        if self.allowed_commands:
            if sh_cmd_name not in self.allowed_commands:
                conn.append_error('this command is not allowed')
                return

        sh_cmd = join_args(args[1:])
        # print('shell cmd: {}'.format(sh_cmd_name))
        output = subprocess.getoutput(sh_cmd)
        conn.append_string(output)
