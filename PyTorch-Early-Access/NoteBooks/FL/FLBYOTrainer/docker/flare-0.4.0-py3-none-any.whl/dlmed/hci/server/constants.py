class ConnProps(object):

    EVENT_ID = '_eventId'
    USER_NAME = '_userName'
    TOKEN = '_sessionToken'
    SESSION = '_session'
    CMD_ENTRY = '_cmdEntry'
    AUTHZ_CTX = '_authztx'
