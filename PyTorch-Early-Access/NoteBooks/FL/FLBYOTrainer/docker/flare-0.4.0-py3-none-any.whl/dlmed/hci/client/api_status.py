class APIStatus:
    SUCCESS = "SUCCESS"                    # command issues successfully
    PARTIAL_SUCCESS = "PARTIAL_SUCCESS"   # command + clients, some client return / some does not
    ERROR_PROTOCOL = "ERROR_PROTOCOL"     # the payload/data is not following the correct format/protocol expected by the server
    ERROR_CERT = "ERROR_CERT"                # key or certs are incorrect
    ERROR_AUTHORIZATION = "ERROR_AUTHORIZATION"   # authorization failed
    ERROR_COMMAND_SYNTAX = "ERROR_COMMAND_SYNTAX"   # command syntax incorrect
    ERROR_RUNTIME = "ERROR_RUNTIME"     # various errors, for example permission (file creation) / file not found => we might want to put those exception (stack trace?) into the details / server training has not started / did not set run number before deploy / MMAR missing
    ERROR_INVALID_CLIENT = "ERROR_INVALID_CLIENT"   # wrong/invalid client names exists in command
