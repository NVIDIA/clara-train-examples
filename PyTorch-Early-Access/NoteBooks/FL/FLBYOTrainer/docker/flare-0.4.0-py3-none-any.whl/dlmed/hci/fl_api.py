class Transformer(object):

    def transform(self, data_ctx, app_ctx):
        """
        Called to perform data transformation
        :param data_ctx: the context that contains the data points transformed/generated
        :param app_ctx: the overall app context (e.g. current phase, round, task, ...)
        :return:
        """
        pass

    def abort(self, app_ctx):
        """
        Called to abort its work immediately
        :param app_ctx:
        :return:
        """
        pass


class Handler(object):

    def handle_event(self, event_name, app_ctx):
        """
        Called to handle the specified event
        :param event_name: name of the event (startFL, endFL, startPhase, endPhase, ...)
        :param app_ctx: the overall app context
        :return:
        """
        pass
