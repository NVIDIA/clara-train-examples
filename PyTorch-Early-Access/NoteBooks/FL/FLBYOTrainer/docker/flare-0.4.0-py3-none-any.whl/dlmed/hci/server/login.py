from dlmed.hci.conn import Connection
from .reg import CommandFilter
from .sess import SessionManager
from dlmed.hci.server.constants import ConnProps
from dlmed.hci.reg import CommandSpec, CommandModuleSpec, CommandModule
from dlmed.hci.security import verify_password


LOGIN_CMD_NAME = '_login'
CERT_LOGIN_CMD_NAME = '_cert_login'


class Authenticator(object):

    def authenticate(self, user_name: str, credential: str, credential_type: str) -> bool:
        """
        Authenticate a specified user with the provided credential

        Args:
            user_name: user login name
            credential: provided credential
            credential_type: type of credential

        Returns: True if successful, False otherwise

        """
        pass


class SimpleAuthenticator(Authenticator):

    def __init__(self, users):
        self.users = users

    def authenticate_password(self, user_name: str, pwd: str):
        pwd_hash = self.users.get(user_name)
        if pwd_hash is None:
            return False

        return verify_password(pwd_hash, user_name + pwd)

    def authenticate_cn(self, user_name: str, cn):
        return user_name == cn

    def authenticate(self,
                     user_name: str,
                     credential,
                     credential_type):
        if credential_type == 'password':
            return self.authenticate_password(user_name, credential)
        elif credential_type == 'cn':
            return self.authenticate_cn(user_name, credential)
        else:
            return False


class LoginModule(CommandModule, CommandFilter):

    def __init__(self, authenticator: Authenticator, sess_mgr: SessionManager):
        if authenticator:
            assert isinstance(authenticator, Authenticator), 'authenticator must be Authenticator'

        assert isinstance(sess_mgr, SessionManager), 'sess_mgr must be SessionManager'

        self.authenticator = authenticator
        self.session_mgr = sess_mgr

    def get_spec(self):
        return CommandModuleSpec(
            name='login',
            cmd_specs=[
                CommandSpec(
                    name=LOGIN_CMD_NAME,
                    description='login to server',
                    usage='login userName password',
                    handler_func=self.handle_login,
                    visible=False
                ),
                CommandSpec(
                    name=CERT_LOGIN_CMD_NAME,
                    description='login to server with SSL cert',
                    usage='login userName',
                    handler_func=self.handle_cert_login,
                    visible=False
                ),
                CommandSpec(
                    name='_logout',
                    description='logout from server',
                    usage='logout',
                    handler_func=self.handle_logout,
                    visible=False
                )
            ]
        )

    def handle_login(self, conn: Connection, args: [str]):
        if not self.authenticator:
            conn.append_string('OK')
            return

        if len(args) != 3:
            conn.append_string('REJECT')
            return

        user_name = args[1]
        pwd = args[2]

        ok = self.authenticator.authenticate(user_name, pwd, 'password')
        if not ok:
            conn.append_string('REJECT')
            return

        session = self.session_mgr.create_session(user_name)
        conn.append_string('OK')
        conn.append_token(session.token)

    def handle_cert_login(self, conn: Connection, args: [str]):
        if not self.authenticator:
            conn.append_string('OK')
            return

        if len(args) != 2:
            conn.append_string('REJECT')
            return

        cn = conn.get_prop('_client_cn', None)
        if cn is None:
            conn.append_string('REJECT')
            return

        user_name = args[1]

        ok = self.authenticator.authenticate(user_name, cn, 'cn')
        if not ok:
            conn.append_string('REJECT')
            return

        session = self.session_mgr.create_session(user_name)
        conn.append_string('OK')
        conn.append_token(session.token)

    def handle_logout(self, conn: Connection, args: [str]):
        if self.authenticator and self.session_mgr:
            token = conn.get_prop(ConnProps.TOKEN)
            if token:
                self.session_mgr.end_session(token)
        conn.append_string('OK')

    def pre_command(self, conn: Connection, args: [str]):
        if args[0] in [LOGIN_CMD_NAME, CERT_LOGIN_CMD_NAME]:
            # skip login command
            return True

        # validate token
        req_json = conn.request
        token = None
        data = req_json['data']
        for item in data:
            it = item['type']
            if it == 'token':
                token = item['data']
                break

        if token is None:
            conn.append_error('not authenticated - no token')
            return False

        sess = self.session_mgr.get_session(token)
        if sess:
            sess.mark_active()
            conn.set_prop(ConnProps.SESSION, sess)
            conn.set_prop(ConnProps.USER_NAME, sess.user_name)
            conn.set_prop(ConnProps.TOKEN, token)
            return True
        else:
            conn.append_error('not authenticated - no user')
            return False
