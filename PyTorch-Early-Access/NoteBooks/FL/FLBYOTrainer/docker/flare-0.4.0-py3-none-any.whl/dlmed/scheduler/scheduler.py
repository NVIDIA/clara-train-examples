from dlmed.utils.comm import Queue
import threading
import time
from dlmed.common.debug import debug
import traceback


class JobStatus(object):

    OK = 0
    ERROR = -1
    EXCEPTION = -2
    UNFINISHED = -3
    ABORTED = -4
    TIMEOUT = -5


class Job(object):

    def __init__(self, task, scheduler):
        self.task = task
        self.scheduler = scheduler
        self.seq_no = None
        self.status = JobStatus.OK
        self.resource = None
        self.start_time = None
        self.worker_seq_no = None
        self.worker_name = None


class Scheduler(object):

    def __init__(self,
                 name: str,
                 worker_resources,
                 poll_interval=0.1,
                 worker_interval=0.1,
                 max_job_run_time=None):
        assert isinstance(worker_resources, list), 'worker_resources must be list'
        assert len(worker_resources) > 0, 'there must be at least 1 worker resource'

        self.name = name
        self.worker_resources = worker_resources
        self.workers = []
        self.job_queue = Queue('jobs')
        self.poll_interval = poll_interval
        self.worker_interval = worker_interval
        self.asked_to_stop = False
        self.runner = None
        self.max_job_run_time = max_job_run_time
        self.worker_map = {}  # name => worker

    def get_workers(self):
        return self.workers

    def get_worker(self, name):
        return self.worker_map.get(name)

    def pre_job_check(self):
        pass

    def after_job_check(self):
        pass

    def abort_job(self, job: Job):
        pass

    def do_job(self, job: Job):
        pass

    def add_task(self, task):
        # called from main thread
        job = Job(
            task=task,
            scheduler=self)
        job.seq_no = self.job_queue.append(job)
        return job

    def get_next_job(self):
        return self.job_queue.pop(default=None)

    def start(self):
        if self.runner is None:
            self.runner = threading.Thread(target=_start_scheduler, args=(self,))

        # called from the main thread
        if self.runner.is_alive():
            # already started
            return

        self.runner.start()
        debug('Scheduler {} started'.format(self.name))

    def shutdown(self):
        # called from the main thread!
        self.asked_to_stop = True
        if self.runner and self.runner.is_alive():
            self.runner.join()

    def abort(self):
        self.asked_to_stop = True
        for worker in self.workers:
            worker.abort(JobStatus.ABORTED)

    def _run(self):
        # running in its own method
        # create workers
        for i in range(len(self.worker_resources)):
            if len(self.name) > 0:
                worker_name = '{}.W{}'.format(self.name, i+1)
            else:
                worker_name = 'W{}'.format(i+1)

            worker = Worker(
                name=worker_name,
                resource=self.worker_resources[i],
                scheduler=self)

            self.workers.append(worker)
            self.worker_map[worker_name] = worker

        # start workers
        for worker in self.workers:
            worker.start()

        while True:
            if self.asked_to_stop:
                break

            # check whether there is any pending job
            self.pre_job_check()

            err = None
            try:
                job = self.job_queue.get(default=None)
                if job:
                    debug('Scheduler {}: got a job'.format(self.name))
                    healthy_workers = 0
                    for worker in self.workers:
                        accepted = worker.accept_job(job)
                        if accepted != Worker.REJECTED_DEAD:
                            healthy_workers += 1

                        if accepted == Worker.ACCEPTED:
                            self.job_queue.pop()
                            break

                    if healthy_workers == 0:
                        # all workers are dead
                        debug('Scheduler {} is dead: all workers are dead!'.format(self.name))
                        self.abort()
                        break
                else:
                    debug('Scheduler {}: no job'.format(self.name))
            except BaseException as ex:
                err = ex

            if err:
                raise err

            # check job running time
            if self.max_job_run_time and self.max_job_run_time > 0:
                for worker in self.workers:
                    job, running_time = worker.get_job_running_time()
                    if job is not None and job != worker.aborted_job \
                            and running_time > self.max_job_run_time:
                        worker.abort(JobStatus.TIMEOUT)
                        worker.aborted_job = job

            self.after_job_check()

            time.sleep(self.poll_interval)

        # wait for all workers to finish
        for worker in self.workers:
            worker.shutdown()


def _start_scheduler(scheduler: Scheduler):
    scheduler._run()


class Worker(object):

    STATE_IDLE = 0
    STATE_BUSY = 1
    STATE_DEAD = 2
    STATE_SUSPENDED = 3

    ACCEPTED = 0
    REJECTED_BUSY = 1
    REJECTED_DEAD = 2
    REJECTED_SUSPENDED = 3

    STATE_NAMES = {
        STATE_IDLE: "idle",
        STATE_BUSY: "busy",
        STATE_DEAD: "dead",
        STATE_SUSPENDED: "suspended"
    }

    def __init__(self,
                 name: str,
                 resource,
                 scheduler: Scheduler):
        self.name = name
        self.resource = resource
        self.scheduler = scheduler
        self.state = Worker.STATE_IDLE
        self.job = None
        self.asked_to_stop = False
        self.job_count = 0
        self._state_update_lock = threading.Lock()
        self.runner = None
        self.aborted_job = None

    def start(self):
        # called from the scheduler
        if self.runner is None:
            self.runner = threading.Thread(target=_start_worker, args=(self,))

        if not self.runner.is_alive():
            self.runner.start()

        debug("Worker {} started".format(self.name))

    def shutdown(self):
        # called from the scheduler
        self.asked_to_stop = True
        if self.runner.is_alive():
            self.runner.join()
        debug("Worker {} stopped".format(self.name))

    def abort(self, reason: JobStatus):
        self.asked_to_stop = True
        if self.job:
            self.job.status = reason
            self.scheduler.abort_job(self.job)
        debug("Worker {} aborted with reason {}".format(self.name, reason))

    def abort_current_job(self, reason: JobStatus):
        with self._state_update_lock:
            job = self.job
            if job:
                self.job.status = reason
                self.scheduler.abort_job(job)

    def suspend(self):
        with self._state_update_lock:
            self.state = Worker.STATE_SUSPENDED

    def resume(self):
        with self._state_update_lock:
            if self.state == Worker.STATE_SUSPENDED:
                if self.job:
                    self.state = Worker.STATE_BUSY
                else:
                    self.state = Worker.STATE_IDLE
            return self.state

    def get_job_running_time(self):
        job = None
        result = 0
        with self._state_update_lock:
            try:
                if self.job:
                    job = self.job
                    if job.start_time is not None:
                        result = time.time() - self.job.start_time
            except:
                pass

        return job, result

    def _prepare_job(self, job):
        self.job_count += 1
        job.worker_seq_no = self.job_count
        job.resource = self.resource
        job.worker_name = self.name

    def accept_job(self, job: Job) -> int:
        # asked by the scheduler to accept a job
        # return whether the job can be accepted

        # use the lock to prevent this method is called in quick succession!
        with self._state_update_lock:
            try:
                if self.state == Worker.STATE_IDLE:
                    self.state = Worker.STATE_BUSY
                    self._prepare_job(job)
                    self.job = job
                    accepted = Worker.ACCEPTED
                elif self.state == Worker.STATE_BUSY:
                    accepted = Worker.REJECTED_BUSY
                elif self.state == Worker.STATE_SUSPENDED:
                    accepted = Worker.REJECTED_SUSPENDED
                else:
                    accepted = Worker.REJECTED_DEAD
            except:
                traceback.print_exc()
                self.state = Worker.REJECTED_DEAD
                accepted = Worker.REJECTED_DEAD

        debug('Worker {} accepted job status: {}'.format(self.name, accepted))

        return accepted

    def _do_job(self):
        job = self.job
        job.start_time = time.time()
        job.status = JobStatus.UNFINISHED
        try:
            debug('Worker {}: got job'.format(self.name))
            self.scheduler.do_job(job)
        except:
            traceback.print_exc()
            job.status = JobStatus.EXCEPTION

    def _run(self):
        # run the worker thread
        while True:
            if self.asked_to_stop:
                break

            try:
                job = None
                with self._state_update_lock:
                    job = self.job

                if job:
                    # got a job to do!
                    self._do_job()
                    self.job = None

                    with self._state_update_lock:
                        if self.state == Worker.STATE_BUSY:
                            # only if the state stays BUSY
                            # it could have been changed to SUSPENDED!
                            job = self.scheduler.get_next_job()
                            if job:
                                self._prepare_job(job)
                                self.job = job
                            else:
                                self.state = Worker.STATE_IDLE
                        elif self.state != Worker.STATE_SUSPENDED:
                            self.state = Worker.STATE_IDLE
                else:
                    time.sleep(self.scheduler.worker_interval)
            except:
                traceback.print_exc()
                self.state = Worker.STATE_DEAD
                break


def _start_worker(worker: Worker):
    worker._run()
